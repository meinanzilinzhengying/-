# 云内流量监测系统 - Agent 探针端（离线部署）

## 部署流程

### 第一步：在有网络的机器上准备离线镜像

```bash
cd cloud-flow-agent-deploy
chmod +x prepare.sh start.sh stop.sh
./prepare.sh
```

### 第二步：传输到离线服务器

将整个 `cloud-flow-agent-deploy/` 目录传输到离线服务器。

### 第三步：在离线服务器上配置并启动

```bash
cd cloud-flow-agent-deploy

# 修改配置（必须修改 EDGE_ADDR 和 API Key）
vi .env

# 一键启动
./start.sh
```

## 配置说明

| 配置项 | 说明 | 示例 |
|--------|------|------|
| EDGE_ADDR | Server 端 Edge gRPC 地址 | 192.168.1.100:10001 |
| CLOUD_FLOW_API_KEY | 与 Server 端一致的密钥 | （见 Server 端 .env） |
| COLLECT_CPU | 采集 CPU | true |
| COLLECT_MEMORY | 采集内存 | true |
| COLLECT_NETWORK | 采集网络 | true |
| COLLECT_DISK | 采集磁盘 | false |
| COLLECT_INTERVAL | 采集间隔（秒） | 10 |

## 前置要求

- Docker 20.10+
- Linux 内核 4.15+（eBPF 支持）
- 特权模式（Docker --privileged）

## 注意事项

- Agent 使用 `network_mode: host` 直接采集主机指标
- Agent 需要 SYS_ADMIN 能力加载 eBPF 程序
- 确保 Server 端已启动且网络可达

## 常用命令

```bash
./start.sh              # 启动 Agent
./stop.sh               # 停止 Agent
docker compose logs -f  # 查看日志
```
