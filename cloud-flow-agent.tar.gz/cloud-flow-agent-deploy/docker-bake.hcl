// Docker Buildx bake configuration
// Usage: docker buildx bake

variable "TAG" {
    default = "latest"
}

variable "REGISTRY" {
    default = ""
}

variable "GOPROXY" {
    default = "https://proxy.golang.org,direct"
}

group "default" {
    targets = ["agent"]
}

target "agent" {
    dockerfile = "Dockerfile"
    tags = [
        "${REGISTRY}cloud-flow-agent:${TAG}",
        "${REGISTRY}cloud-flow-agent:latest",
    ]
    args = {
        GOPROXY = GOPROXY
    }
    platforms = ["linux/amd64", "linux/arm64"]
    cache-from = [
        "type=gha",  // GitHub Actions cache
        "type=local,src=/tmp/.buildx-cache",
    ]
    cache-to = [
        "type=gha,mode=max",
        "type=local,dest=/tmp/.buildx-cache-new,mode=max",
    ]
    output = ["type=docker"]
}

target "agent-slim" {
    inherits = ["agent"]
    dockerfile = "Dockerfile.slim"  // 更精简版本
    tags = [
        "${REGISTRY}cloud-flow-agent:${TAG}-slim",
    ]
}
