#!/bin/bash
set -e

# =============================================================================
# 云内流量监测系统 - Agent 探针端离线一键启动脚本
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo "============================================"
echo "  云内流量监测系统 - Agent 探针端（离线部署）"
echo "============================================"
echo ""

# ── 1. 检查 Docker ──
echo -e "${YELLOW}[1/5] 检查 Docker 环境...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}错误: 未安装 Docker${NC}"
    exit 1
fi
if ! docker info &> /dev/null; then
    echo -e "${RED}错误: Docker 服务未运行${NC}"
    exit 1
fi
echo -e "${GREEN}  ✓ Docker 环境正常${NC}"

# ── 2. 检查配置 ──
echo -e "${YELLOW}[2/5] 检查配置...${NC}"
if [ ! -f .env ]; then
    echo -e "${RED}错误: 缺少 .env 配置文件${NC}"
    exit 1
fi

EDGE_ADDR=$(grep "^EDGE_ADDR=" .env 2>/dev/null | cut -d'=' -f2)
if [ -z "$EDGE_ADDR" ]; then
    echo -e "${RED}错误: EDGE_ADDR 未配置${NC}"
    echo "  请在 .env 中设置 Server 端 Edge 地址，例如:"
    echo "  EDGE_ADDR=192.168.1.100:10001"
    exit 1
fi

API_KEY=$(grep "^CLOUD_FLOW_API_KEY=" .env 2>/dev/null | cut -d'=' -f2)
if [ -z "$API_KEY" ] || echo "$API_KEY" | grep -q "change-me"; then
    echo -e "${YELLOW}  ⚠ 警告: API Key 使用默认值，请修改为与 Server 端一致${NC}"
fi
echo -e "${GREEN}  ✓ 配置文件就绪${NC}"
echo -e "    EDGE_ADDR = $EDGE_ADDR"

# ── 3. 导入离线镜像 ──
echo -e "${YELLOW}[3/5] 导入离线 Docker 镜像...${NC}"
IMAGES_DIR="$SCRIPT_DIR/images"
LOADED=0
OFFLINE_MODE=false
if [ -d "$IMAGES_DIR" ] && ls "$IMAGES_DIR"/*.tar 1> /dev/null 2>&1; then
    OFFLINE_MODE=true
    for img_tar in "$IMAGES_DIR"/*.tar; do
        img_name=$(basename "$img_tar" .tar)
        echo -e "  ${CYAN}导入: $img_name${NC}"
        docker load -i "$img_tar" 2>&1 || true
        LOADED=$((LOADED + 1))
    done
    echo -e "${GREEN}  ✓ 已导入 $LOADED 个镜像（离线模式）${NC}"
else
    echo -e "${YELLOW}  ⚠ 未找到离线镜像文件（images/*.tar）${NC}"
    echo -e "${YELLOW}    将尝试在线构建，如果服务器无网络则会失败${NC}"
    echo -e "${YELLOW}    建议在有网络的机器上先运行 prepare.sh 生成离线镜像${NC}"
fi

# ── 4. 启动 Agent ──
echo -e "${YELLOW}[4/5] 启动 Agent...${NC}"
COMPOSE_CMD="docker compose"
if ! docker compose version &> /dev/null 2>&1; then
    COMPOSE_CMD="docker-compose"
fi

if [ "$OFFLINE_MODE" = true ]; then
    echo -e "  ${CYAN}离线模式: 跳过构建，直接使用预构建镜像${NC}"
    $COMPOSE_CMD up -d --no-build 2>&1
else
    $COMPOSE_CMD up -d --build 2>&1
fi
echo -e "${GREEN}  ✓ Agent 启动完成${NC}"

# ── 5. 显示状态 ──
echo -e "${YELLOW}[5/5] 检查状态...${NC}"
sleep 3

echo ""
$COMPOSE_CMD ps 2>&1

echo ""
echo "============================================"
echo -e "  ${GREEN}Agent 部署完成！${NC}"
echo "============================================"
echo ""
echo "  查看日志: $COMPOSE_CMD logs -f"
echo "  停止Agent: ./stop.sh"
echo "============================================"
