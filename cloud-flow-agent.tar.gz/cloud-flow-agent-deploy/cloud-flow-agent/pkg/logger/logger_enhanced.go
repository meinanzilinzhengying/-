package logger

import (
	"context"
	"os"

	"go.opentelemetry.io/otel/trace"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

// Config holds logger configuration
type Config struct {
	Level       string
	Format      string // "json" or "console"
	Output      string // "stdout", "stderr", or file path
	Development bool
}

// NewLogger creates a new zap logger
func NewLogger(cfg Config) (*zap.Logger, error) {
	var level zapcore.Level
	if err := level.UnmarshalText([]byte(cfg.Level)); err != nil {
		level = zapcore.InfoLevel
	}

	var encoder zapcore.Encoder
	encoderConfig := zap.NewProductionEncoderConfig()
	if cfg.Development {
		encoderConfig = zap.NewDevelopmentEncoderConfig()
	}
	encoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder

	if cfg.Format == "console" {
		encoder = zapcore.NewConsoleEncoder(encoderConfig)
	} else {
		encoder = zapcore.NewJSONEncoder(encoderConfig)
	}

	var writer zapcore.WriteSyncer
	switch cfg.Output {
	case "stdout":
		writer = zapcore.AddSync(os.Stdout)
	case "stderr":
		writer = zapcore.AddSync(os.Stderr)
	default:
		file, err := os.OpenFile(cfg.Output, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			return nil, err
		}
		writer = zapcore.AddSync(file)
	}

	core := zapcore.NewCore(encoder, writer, level)
	return zap.New(core, zap.AddCaller(), zap.AddCallerSkip(1)), nil
}

// WithTrace adds trace context to logger
func WithTrace(ctx context.Context, logger *zap.Logger) *zap.Logger {
	span := trace.SpanFromContext(ctx)
	if !span.SpanContext().IsValid() {
		return logger
	}

	return logger.With(
		zap.String("trace_id", span.SpanContext().TraceID().String()),
		zap.String("span_id", span.SpanContext().SpanID().String()),
	)
}

// Fields for common log attributes
var (
	FieldProbeID   = zap.String("probe_id", "")
	FieldSrcIP     = zap.String("src_ip", "")
	FieldDstIP     = zap.String("dst_ip", "")
	FieldProtocol  = zap.String("protocol", "")
	FieldBytes     = zap.Int64("bytes", 0)
	FieldPackets   = zap.Int64("packets", 0)
	FieldDuration  = zap.Duration("duration", 0)
	FieldError     = zap.Error(nil)
	FieldComponent = zap.String("component", "")
	FieldMethod    = zap.String("method", "")
	FieldStatus    = zap.String("status", "")
)

// LogContext holds context for structured logging
type LogContext struct {
	fields []zap.Field
}

// NewLogContext creates a new log context
func NewLogContext() *LogContext {
	return &LogContext{fields: make([]zap.Field, 0, 8)}
}

// WithProbeID adds probe ID
func (lc *LogContext) WithProbeID(id string) *LogContext {
	lc.fields = append(lc.fields, zap.String("probe_id", id))
	return lc
}

// WithIPs adds source and destination IPs
func (lc *LogContext) WithIPs(src, dst string) *LogContext {
	lc.fields = append(lc.fields, zap.String("src_ip", src), zap.String("dst_ip", dst))
	return lc
}

// WithPorts adds source and destination ports
func (lc *LogContext) WithPorts(src, dst int32) *LogContext {
	lc.fields = append(lc.fields, zap.Int32("src_port", src), zap.Int32("dst_port", dst))
	return lc
}

// WithProtocol adds protocol
func (lc *LogContext) WithProtocol(proto string) *LogContext {
	lc.fields = append(lc.fields, zap.String("protocol", proto))
	return lc
}

// WithBytes adds bytes
func (lc *LogContext) WithBytes(b int64) *LogContext {
	lc.fields = append(lc.fields, zap.Int64("bytes", b))
	return lc
}

// WithError adds error
func (lc *LogContext) WithError(err error) *LogContext {
	lc.fields = append(lc.fields, zap.Error(err))
	return lc
}

// Fields returns the accumulated fields
func (lc *LogContext) Fields() []zap.Field {
	return lc.fields
}

// Info logs at info level
func (lc *LogContext) Info(logger *zap.Logger, msg string) {
	logger.Info(msg, lc.fields...)
}

// Error logs at error level
func (lc *LogContext) Error(logger *zap.Logger, msg string) {
	logger.Error(msg, lc.fields...)
}

// Debug logs at debug level
func (lc *LogContext) Debug(logger *zap.Logger, msg string) {
	logger.Debug(msg, lc.fields...)
}
