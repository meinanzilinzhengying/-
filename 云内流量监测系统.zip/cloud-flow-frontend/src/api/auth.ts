import { apiRequest, setToken, removeToken, getToken } from './index';

export const authApi = {
  login: async (username: string, password: string, rememberMe: boolean = false) => {
    // 预获取 CSRF token（通过 GET 请求让后端设置 csrf_token cookie）
    try {
      await apiRequest('/csrf-token', { method: 'GET' }, 0);
    } catch {
      // 即使失败也继续尝试登录
    }
    // POST 登录（浏览器自动携带 csrf_token cookie）
    const response = await apiRequest<{ token: string; user: unknown }>('/users/login', {
      method: 'POST',
      body: { username, password },
    }, 0);
    if ((response as Record<string, unknown>).token) {
      setToken((response as Record<string, unknown>).token as string, rememberMe);
    }
    return response;
  },

  logout: () => {
    removeToken();
  },

  isAuthenticated: async () => {
    const token = getToken();
    if (!token) {
      return false;
    }

    try {
      await apiRequest('/users/verify');
      return true;
    } catch (e) {
      removeToken();
      return false;
    }
  },
};

export const userApi = {
  getUserInfo: () => apiRequest('/users/info'),

  updateUserInfo: (data: Record<string, unknown>) => apiRequest('/users/info', {
    method: 'PUT',
    body: data,
  }),

  changePassword: (data: {
    oldPassword: string;
    newPassword: string;
  }) => apiRequest('/users/password', {
    method: 'PUT',
    body: data,
  }),

  getUsers: (params?: {
    page?: number;
    pageSize?: number;
    role?: string;
    status?: string;
  }) => {
    const queryParams = new URLSearchParams();
    if (params) {
      if (params.page) queryParams.append('page', params.page.toString());
      if (params.pageSize) queryParams.append('page_size', params.pageSize.toString());
      if (params.role) queryParams.append('role', params.role);
      if (params.status) queryParams.append('status', params.status);
    }
    const query = queryParams.toString();
    return apiRequest(`/users${query ? `?${query}` : ''}`);
  },

  createUser: (data: Record<string, unknown>) => apiRequest('/users', {
    method: 'POST',
    body: data,
  }),

  updateUser: (id: string, data: Record<string, unknown>) => apiRequest(`/users/${id}`, {
    method: 'PUT',
    body: data,
  }),

  deleteUser: (id: string) => apiRequest(`/users/${id}`, {
    method: 'DELETE',
  }),
};
