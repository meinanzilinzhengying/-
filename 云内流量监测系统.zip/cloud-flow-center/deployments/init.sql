-- =============================================================================
-- 云内流量监测系统 (Cloud Flow Center) - 数据库初始化脚本
-- =============================================================================
-- 本脚本用于初始化云内流量监测系统的所有数据库表结构。
-- 数据库引擎: TiDB (兼容 MySQL 协议)
-- 字符集: utf8mb4
-- 分区策略: 按 RANGE COLUMNS 按天分区，便于数据生命周期管理
-- =============================================================================

CREATE DATABASE IF NOT EXISTS cloud_flow
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_bin;

USE cloud_flow;

-- ---------------------------------------------------------------------------
-- 1. users 表 - 用户管理
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- 2. metrics 表 - 指标数据（网络流量、CPU、内存、磁盘等）
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS metrics (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    probe_id VARCHAR(64) NOT NULL,
    ts TIMESTAMP NOT NULL,
    src_ip VARCHAR(45),
    dst_ip VARCHAR(45),
    src_port INT,
    dst_port INT,
    protocol VARCHAR(20),
    bytes BIGINT DEFAULT 0,
    packets INT DEFAULT 0,
    latency BIGINT DEFAULT 0,
    cpu_usage DOUBLE DEFAULT 0,
    memory_usage DOUBLE DEFAULT 0,
    disk_usage DOUBLE DEFAULT 0,
    INDEX idx_probe_id (probe_id),
    INDEX idx_ts (ts),
    INDEX idx_protocol (protocol),
    INDEX idx_src_ip (src_ip),
    INDEX idx_dst_ip (dst_ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
PARTITION BY RANGE COLUMNS (ts) (
    PARTITION p_default VALUES LESS THAN ('2027-01-01')
);

-- ---------------------------------------------------------------------------
-- 3. traces 表 - 链路追踪数据
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS traces (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    probe_id VARCHAR(64) NOT NULL,
    ts TIMESTAMP NOT NULL,
    payload JSON,
    span_id VARCHAR(128),
    INDEX idx_probe_id (probe_id),
    INDEX idx_ts (ts),
    INDEX idx_span_id (span_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
PARTITION BY RANGE COLUMNS (ts) (
    PARTITION p_default VALUES LESS THAN ('2027-01-01')
);

-- ---------------------------------------------------------------------------
-- 4. profiling 表 - 性能分析数据
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS profiling (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    probe_id VARCHAR(64) NOT NULL,
    ts TIMESTAMP NOT NULL,
    payload JSON,
    type VARCHAR(50),
    INDEX idx_probe_id (probe_id),
    INDEX idx_ts (ts),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
PARTITION BY RANGE COLUMNS (ts) (
    PARTITION p_default VALUES LESS THAN ('2027-01-01')
);

-- ---------------------------------------------------------------------------
-- 5. probes 表 - 探针（边缘节点）信息
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS probes (
    edge_node_id VARCHAR(128) PRIMARY KEY,
    payload JSON,
    updated_at BIGINT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- 6. alert_history 表 - 告警历史记录
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alert_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    alert_id VARCHAR(128) NOT NULL,
    rule_id VARCHAR(128) NOT NULL,
    rule_name VARCHAR(255),
    severity VARCHAR(20),
    message TEXT,
    labels JSON,
    value DOUBLE,
    threshold DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP NULL,
    INDEX idx_rule_id (rule_id),
    INDEX idx_severity (severity),
    INDEX idx_resolved (resolved),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
PARTITION BY RANGE COLUMNS (created_at) (
    PARTITION p_default VALUES LESS THAN ('2027-01-01')
);
