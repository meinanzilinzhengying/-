# Cloud Flow - 快速部署包

## 包含内容

- ✅ frontend-dist/ - 已编译的前端静态文件
- ✅ monitoring/ - Prometheus/Grafana/Alertmanager/Loki 配置
- ✅ docker-compose.yml - Docker Compose 部署配置
- ✅ .env.example - 环境变量模板

## 系统要求

- Linux x86_64 (CentOS 7+/Ubuntu 18.04+/Kylin V10)
- Docker 20.10+
- Docker Compose v2+
- 8GB+ 内存

## 快速开始

### 1. 配置环境变量

```bash
cp .env.example .env
vi .env
```

修改以下必填项：
```env
CLOUD_FLOW_JWT_SECRET=your-secret-key-at-least-32-characters
CLOUD_FLOW_ADMIN_PASSWORD=your-admin-password
REDIS_PASSWORD=your-redis-password
```

### 2. 启动基础设施

```bash
docker-compose up -d tidb redis prometheus grafana alertmanager node-exporter
```

### 3. 部署前端

```bash
# 安装 Nginx
yum install -y nginx  # CentOS/Kylin
apt install -y nginx  # Ubuntu/Debian

# 复制配置文件
cp nginx-cloud-flow.conf /etc/nginx/conf.d/

# 复制前端文件
cp -r frontend-dist/* /usr/share/nginx/html/

# 启动 Nginx
nginx
```

### 4. 访问服务

| 服务 | 地址 | 账号 |
|------|------|------|
| 前端 | http://服务器IP:8888 | admin / (配置的密码) |
| Grafana | http://服务器IP:3001 | admin / admin |
| Prometheus | http://服务器IP:9091 | - |

## 完整服务部署（需要自行编译后端）

后端服务 (center/agent/edge) 需要 Go 1.22+ 编译：

```bash
# 安装 Go
curl -fsSL https://go.dev/dl/go1.22.4.linux-amd64.tar.gz | tar -C /usr/local -xzf -
export PATH=$PATH:/usr/local/go/bin

# 编译 Center
cd cloud-flow-center
go build -o bin/center ./cmd/main.go

# 编译 Agent
cd cloud-flow-agent
go build -o bin/agent ./cmd/main.go

# 编译 Edge
cd cloud-flow-edge
go build -o bin/edge ./cmd/main.go
```

## 目录结构

```
cloud-flow-release/
├── frontend-dist/      # 前端静态文件
├── monitoring/         # 监控配置
│   ├── prometheus/
│   ├── grafana/
│   ├── alertmanager/
│   └── loki/
├── docker-compose.yml  # Docker Compose 配置
├── .env.example        # 环境变量模板
└── README-部署说明.md  # 本文件
```

## 常见问题

### 1. Docker 镜像拉取失败

配置镜像加速器：
```bash
cat > /etc/docker/daemon.json << 'EOF'
{
  "registry-mirrors": [
    "https://docker.1ms.run",
    "https://docker.xuanyuan.me"
  ]
}
EOF
systemctl restart docker
```

### 2. 端口冲突

修改 docker-compose.yml 中的端口映射：
```yaml
ports:
  - "8889:8888"  # 改为其他端口
```

### 3. 防火墙问题

```bash
# 开放端口
firewall-cmd --permanent --add-port=8888/tcp
firewall-cmd --permanent --add-port=3001/tcp
firewall-cmd --reload
```

## 许可证

MIT
