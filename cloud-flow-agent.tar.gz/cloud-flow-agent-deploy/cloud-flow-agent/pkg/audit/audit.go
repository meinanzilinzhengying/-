package audit

import (
	"context"
	"encoding/json"
	"os"
	"sync"
	"time"

	"go.uber.org/zap"
)

// Event represents an audit event
type Event struct {
	Timestamp  time.Time              `json:"timestamp"`
	EventType  string                 `json:"event_type"`
	UserID     string                 `json:"user_id,omitempty"`
	Action     string                 `json:"action"`
	Resource   string                 `json:"resource"`
	ResourceID string                 `json:"resource_id,omitempty"`
	SourceIP   string                 `json:"source_ip,omitempty"`
	UserAgent  string                 `json:"user_agent,omitempty"`
	Success    bool                   `json:"success"`
	Error      string                 `json:"error,omitempty"`
	Metadata   map[string]interface{} `json:"metadata,omitempty"`
	Duration   time.Duration          `json:"duration,omitempty"`
}

// Logger handles audit logging
type Logger struct {
	logger *zap.Logger
	file   *os.File
	mu     sync.Mutex
}

// NewLogger creates a new audit logger
func NewLogger(filePath string) (*Logger, error) {
	var file *os.File
	var err error

	if filePath != "" {
		file, err = os.OpenFile(filePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0640)
		if err != nil {
			return nil, err
		}
	}

	return &Logger{
		logger: zap.L().Named("audit"),
		file:   file,
	}, nil
}

// Log records an audit event
func (l *Logger) Log(ctx context.Context, event *Event) error {
	event.Timestamp = time.Now()

	l.mu.Lock()
	defer l.mu.Unlock()

	// Log to zap
	l.logger.Info("audit event",
		zap.String("type", event.EventType),
		zap.String("action", event.Action),
		zap.String("resource", event.Resource),
		zap.Bool("success", event.Success),
	)

	// Log to file if configured
	if l.file != nil {
		data, err := json.Marshal(event)
		if err != nil {
			return err
		}
		l.file.Write(append(data, '\n'))
	}

	return nil
}

// LogAuth records authentication events
func (l *Logger) LogAuth(ctx context.Context, userID, action, sourceIP string, success bool, err error) {
	event := &Event{
		EventType: "auth",
		UserID:    userID,
		Action:    action,
		SourceIP:  sourceIP,
		Success:   success,
	}
	if err != nil {
		event.Error = err.Error()
	}
	l.Log(ctx, event)
}

// LogAPI records API access events
func (l *Logger) LogAPI(ctx context.Context, userID, action, resource, resourceID string, duration time.Duration, success bool) {
	l.Log(ctx, &Event{
		EventType:  "api",
		UserID:     userID,
		Action:     action,
		Resource:   resource,
		ResourceID: resourceID,
		Duration:   duration,
		Success:    success,
	})
}

// Close closes the audit logger
func (l *Logger) Close() error {
	if l.file != nil {
		return l.file.Close()
	}
	return nil
}
