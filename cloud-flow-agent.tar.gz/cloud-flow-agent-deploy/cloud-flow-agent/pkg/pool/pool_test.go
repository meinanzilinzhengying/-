package pool

import (
	"testing"

	edge "cloud-flow/proto"
)

func TestMetricDataPool(t *testing.T) {
	// Get from pool
	m := GetMetricData()
	if m == nil {
		t.Fatal("GetMetricData returned nil")
	}

	// Set some values
	m.SrcIp = "10.0.0.1"
	m.DstIp = "10.0.0.2"
	m.Tags["key"] = "value"

	// Return to pool
	PutMetricData(m)

	// Get again - should be reset
	m2 := GetMetricData()
	if m2.SrcIp != "" {
		t.Errorf("SrcIp should be empty after reset, got %q", m2.SrcIp)
	}
	if len(m2.Tags) != 0 {
		t.Errorf("Tags should be empty after reset, got %d", len(m2.Tags))
	}
}

func TestByteSlicePool(t *testing.T) {
	b := GetByteSlice()
	if b == nil || len(*b) != 4096 {
		t.Fatalf("GetByteSlice returned invalid slice")
	}

	PutByteSlice(b)

	b2 := GetByteSlice()
	if cap(*b2) < 4096 {
		t.Errorf("Byte slice capacity should be >= 4096, got %d", cap(*b2))
	}
}

func BenchmarkMetricDataPool(b *testing.B) {
	for i := 0; i < b.N; i++ {
		m := GetMetricData()
		m.SrcIp = "10.0.0.1"
		PutMetricData(m)
	}
}

func BenchmarkMetricDataAlloc(b *testing.B) {
	for i := 0; i < b.N; i++ {
		m := &edge.MetricData{
			Tags: make(map[string]string, 8),
		}
		m.SrcIp = "10.0.0.1"
		_ = m
	}
}
