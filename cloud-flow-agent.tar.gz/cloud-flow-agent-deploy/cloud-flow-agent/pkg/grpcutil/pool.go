package grpcutil

import (
	"context"
	"sync"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/connectivity"
	"google.golang.org/grpc/keepalive"
)

// ConnectionPool manages gRPC connections
type ConnectionPool struct {
	mu          sync.RWMutex
	connections map[string]*grpc.ClientConn
	maxConns    int
	idleTimeout time.Duration
}

// NewConnectionPool creates a new connection pool
func NewConnectionPool(maxConns int, idleTimeout time.Duration) *ConnectionPool {
	return &ConnectionPool{
		connections: make(map[string]*grpc.ClientConn),
		maxConns:    maxConns,
		idleTimeout: idleTimeout,
	}
}

// Get retrieves or creates a connection
func (p *ConnectionPool) Get(ctx context.Context, addr string, opts ...grpc.DialOption) (*grpc.ClientConn, error) {
	p.mu.RLock()
	conn, exists := p.connections[addr]
	p.mu.RUnlock()

	if exists && conn.GetState() == connectivity.Ready {
		return conn, nil
	}

	p.mu.Lock()
	defer p.mu.Unlock()

	// Double check
	if conn, exists := p.connections[addr]; exists {
		if conn.GetState() == connectivity.Ready {
			return conn, nil
		}
		conn.Close()
		delete(p.connections, addr)
	}

	// Create new connection with default keepalive parameters
	defaultOpts := []grpc.DialOption{
		grpc.WithKeepaliveParams(keepalive.ClientParameters{
			Time:                10 * time.Second,
			Timeout:             3 * time.Second,
			PermitWithoutStream: true,
		}),
	}
	opts = append(defaultOpts, opts...)

	conn, err := grpc.DialContext(ctx, addr, opts...)
	if err != nil {
		return nil, err
	}

	p.connections[addr] = conn
	return conn, nil
}

// Close closes all connections
func (p *ConnectionPool) Close() error {
	p.mu.Lock()
	defer p.mu.Unlock()

	var lastErr error
	for addr, conn := range p.connections {
		if err := conn.Close(); err != nil {
			lastErr = err
		}
		delete(p.connections, addr)
	}
	return lastErr
}
