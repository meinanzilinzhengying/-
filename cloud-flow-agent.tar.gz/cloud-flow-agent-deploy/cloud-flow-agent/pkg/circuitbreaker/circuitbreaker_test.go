package circuitbreaker

import (
	"errors"
	"testing"
	"time"
)

func TestCircuitBreaker_Closed(t *testing.T) {
	cb := New(Config{
		FailureThreshold: 3,
		Timeout:          time.Second,
	})

	if cb.State() != StateClosed {
		t.Errorf("initial state = %v, want %v", cb.State(), StateClosed)
	}

	// Successful calls should keep it closed
	for i := 0; i < 5; i++ {
		err := cb.Execute(nil, func() error { return nil })
		if err != nil {
			t.Errorf("unexpected error: %v", err)
		}
	}

	if cb.State() != StateClosed {
		t.Errorf("state after successes = %v, want %v", cb.State(), StateClosed)
	}
}

func TestCircuitBreaker_Open(t *testing.T) {
	cb := New(Config{
		FailureThreshold: 2,
		Timeout:          100 * time.Millisecond,
	})

	testErr := errors.New("test error")

	// Trigger failures
	for i := 0; i < 2; i++ {
		cb.Execute(nil, func() error { return testErr })
	}

	if cb.State() != StateOpen {
		t.Errorf("state after failures = %v, want %v", cb.State(), StateOpen)
	}

	// Should reject calls when open
	err := cb.Execute(nil, func() error { return nil })
	if err != ErrCircuitOpen {
		t.Errorf("error when open = %v, want %v", err, ErrCircuitOpen)
	}
}

func TestCircuitBreaker_HalfOpen(t *testing.T) {
	cb := New(Config{
		FailureThreshold: 1,
		SuccessThreshold: 2,
		Timeout:          50 * time.Millisecond,
	})

	// Open the circuit
	cb.Execute(nil, func() error { return errors.New("fail") })

	// Wait for timeout
	time.Sleep(60 * time.Millisecond)

	// Make a call to trigger transition from Open to HalfOpen
	// The state transitions happen in beforeCall(), so we need to make a call first
	cb.Execute(nil, func() error { return nil })

	// Should be half-open now (or closed if success threshold is 1)
	// Since we made one successful call and SuccessThreshold is 2, it should be half-open
	if cb.State() != StateHalfOpen {
		t.Errorf("state after first success in half-open = %v, want %v", cb.State(), StateHalfOpen)
	}

	// Succeed one more time to close (need 2 total successes)
	cb.Execute(nil, func() error { return nil })

	if cb.State() != StateClosed {
		t.Errorf("state after successes = %v, want %v", cb.State(), StateClosed)
	}
}
