#!/bin/bash
# =============================================================================
# Docker 构建脚本
# 支持多平台构建、缓存优化、安全扫描
# =============================================================================

set -e

# 配置
IMAGE_NAME="cloud-flow-agent"
REGISTRY="${REGISTRY:-}"
TAG="${TAG:-latest}"
PLATFORMS="${PLATFORMS:-linux/amd64}"
GOPROXY="${GOPROXY:-https://proxy.golang.org,direct}"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_deps() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker not found"
        exit 1
    fi
}

# 显示镜像信息
show_image_info() {
    local image="$1"
    log_info "Image info:"
    docker images "$image" --format "  Size: {{.Size}}\n  Created: {{.CreatedAt}}"
    
    log_info "Image layers:"
    docker history "$image" --format "  {{.Size}}\t{{.CreatedBy}}" | head -10
}

# 标准构建
build_standard() {
    log_info "Building standard image..."
    
    docker build \
        --build-arg GOPROXY="$GOPROXY" \
        -t "${REGISTRY}${IMAGE_NAME}:${TAG}" \
        -t "${REGISTRY}${IMAGE_NAME}:latest" \
        -f Dockerfile \
        .
    
    show_image_info "${REGISTRY}${IMAGE_NAME}:${TAG}"
}

# 多平台构建（需要 buildx）
build_multiplatform() {
    log_info "Building multi-platform images..."
    log_info "Platforms: $PLATFORMS"
    
    # 检查 buildx
    if ! docker buildx version &> /dev/null; then
        log_error "Docker buildx not available"
        exit 1
    fi
    
    # 创建 builder（如果不存在）
    if ! docker buildx inspect cloud-flow-builder &> /dev/null; then
        docker buildx create --name cloud-flow-builder --use
    fi
    
    docker buildx build \
        --platform "$PLATFORMS" \
        --build-arg GOPROXY="$GOPROXY" \
        -t "${REGISTRY}${IMAGE_NAME}:${TAG}" \
        -t "${REGISTRY}${IMAGE_NAME}:latest" \
        --push \
        -f Dockerfile \
        .
}

# 安全扫描
scan_image() {
    log_info "Scanning image for vulnerabilities..."
    
    if command -v trivy &> /dev/null; then
        trivy image --severity HIGH,CRITICAL "${REGISTRY}${IMAGE_NAME}:${TAG}"
    elif docker run --rm aquasec/trivy image --help &> /dev/null; then
        docker run --rm \
            -v /var/run/docker.sock:/var/run/docker.sock \
            aquasec/trivy:latest image \
            --severity HIGH,CRITICAL \
            "${REGISTRY}${IMAGE_NAME}:${TAG}"
    else
        log_warn "Trivy not found, skipping scan"
    fi
}

# 测试运行
test_run() {
    log_info "Testing container startup..."
    
    docker run --rm \
        --privileged \
        --network host \
        -v /proc:/host/proc:ro \
        -v /sys:/host/sys:ro \
        "${REGISTRY}${IMAGE_NAME}:${TAG}" \
        --version || true
}

# 清理
cleanup() {
    log_info "Cleaning up..."
    docker system prune -f
}

# 主函数
main() {
    check_deps
    
    case "${1:-build}" in
        build)
            build_standard
            ;;
        multi)
            build_multiplatform
            ;;
        scan)
            scan_image
            ;;
        test)
            test_run
            ;;
        all)
            build_standard
            scan_image
            test_run
            ;;
        clean)
            cleanup
            ;;
        *)
            echo "Usage: $0 {build|multi|scan|test|all|clean}"
            echo ""
            echo "Commands:"
            echo "  build  - Build standard image"
            echo "  multi  - Build multi-platform image (requires buildx)"
            echo "  scan   - Scan image for vulnerabilities"
            echo "  test   - Test container startup"
            echo "  all    - Build, scan, and test"
            echo "  clean  - Clean up Docker resources"
            exit 1
            ;;
    esac
}

main "$@"
