// SPDX-License-Identifier: GPL-2.0
#ifndef __CONNTRACK_H__
#define __CONNTRACK_H__

#include "maps.h"
#include "common.h"

// TCP flags
#define TCP_FLAG_SYN 0x02
#define TCP_FLAG_ACK 0x10
#define TCP_FLAG_FIN 0x01
#define TCP_FLAG_RST 0x04

// CT timeouts (in seconds)
#define CT_TIMEOUT_TCP_NEW       120
#define CT_TIMEOUT_TCP_ESTABLISHED 86400  // 24 hours
#define CT_TIMEOUT_TCP_CLOSE     10
#define CT_TIMEOUT_UDP_DEFAULT   30
#define CT_TIMEOUT_ICMP_DEFAULT  30

// Create reverse key for reply lookup
static __always_inline void ct_make_reverse_key(ct_key_t *rev, const ct_key_t *orig)
{
    rev->saddr = orig->daddr;
    rev->daddr = orig->saddr;
    rev->sport = orig->dport;
    rev->dport = orig->sport;
    rev->protocol = orig->protocol;
    rev->pad[0] = rev->pad[1] = rev->pad[2] = 0;
}

// Check if keys are equal
static __always_inline int ct_key_equal(const ct_key_t *a, const ct_key_t *b)
{
    return (a->saddr == b->saddr && a->daddr == b->daddr &&
            a->sport == b->sport && a->dport == b->dport &&
            a->protocol == b->protocol);
}

// Update TCP state machine
static __always_inline __u8 ct_update_tcp_state(__u8 current_state, __u8 tcp_flags, int is_reply)
{
    if (tcp_flags & TCP_FLAG_RST) {
        return TCP_STATE_CLOSE;
    }
    
    switch (current_state) {
    case TCP_STATE_NONE:
        if (tcp_flags & TCP_FLAG_SYN) {
            return is_reply ? TCP_STATE_SYN_RECV : TCP_STATE_SYN_SENT;
        }
        break;
    case TCP_STATE_SYN_SENT:
        if ((tcp_flags & (TCP_FLAG_SYN | TCP_FLAG_ACK)) == (TCP_FLAG_SYN | TCP_FLAG_ACK)) {
            return TCP_STATE_ESTABLISHED;
        }
        break;
    case TCP_STATE_SYN_RECV:
        if (tcp_flags & TCP_FLAG_ACK) {
            return TCP_STATE_ESTABLISHED;
        }
        break;
    case TCP_STATE_ESTABLISHED:
        if (tcp_flags & TCP_FLAG_FIN) {
            return is_reply ? TCP_STATE_CLOSE_WAIT : TCP_STATE_FIN_WAIT;
        }
        break;
    case TCP_STATE_FIN_WAIT:
        if (tcp_flags & TCP_FLAG_FIN) {
            return TCP_STATE_LAST_ACK;
        }
        break;
    case TCP_STATE_CLOSE_WAIT:
        if (tcp_flags & TCP_FLAG_FIN) {
            return TCP_STATE_LAST_ACK;
        }
        break;
    case TCP_STATE_LAST_ACK:
        if (tcp_flags & TCP_FLAG_ACK) {
            return TCP_STATE_TIME_WAIT;
        }
        break;
    case TCP_STATE_TIME_WAIT:
        // Stay in TIME_WAIT until timeout
        break;
    }
    
    return current_state;
}

// Get timeout based on protocol and state
static __always_inline __u32 ct_get_timeout(__u8 protocol, __u8 tcp_state, __u8 ct_state)
{
    if (protocol == PROTO_TCP) {
        if (tcp_state == TCP_STATE_ESTABLISHED) {
            return CT_TIMEOUT_TCP_ESTABLISHED;
        } else if (tcp_state == TCP_STATE_CLOSE || tcp_state == TCP_STATE_TIME_WAIT) {
            return CT_TIMEOUT_TCP_CLOSE;
        }
        return CT_TIMEOUT_TCP_NEW;
    } else if (protocol == PROTO_UDP) {
        return CT_TIMEOUT_UDP_DEFAULT;
    } else {
        return CT_TIMEOUT_ICMP_DEFAULT;
    }
}

// Main CT lookup/create function
static __always_inline ct_entry_t *ct_lookup(struct __sk_buff *skb, ct_key_t *key, 
                                              __u8 tcp_flags, int *is_new)
{
    ct_entry_t *entry;
    __u64 now = bpf_ktime_get_ns();
    
    // Try to find existing entry
    entry = bpf_map_lookup_elem(&ct_map, key);
    if (entry) {
        *is_new = 0;
        
        // Update TCP state if applicable
        if (key->protocol == PROTO_TCP) {
            entry->tcp_state = ct_update_tcp_state(entry->tcp_state, tcp_flags, 0);
        }
        
        // Update state based on TCP state
        if (entry->tcp_state == TCP_STATE_ESTABLISHED) {
            entry->state = CT_ESTABLISHED;
        }
        
        // Update timeout
        entry->lifetime = ct_get_timeout(key->protocol, entry->tcp_state, entry->state);
        entry->last_seen = now;
        
        return entry;
    }
    
    // Try reverse direction (reply flow)
    ct_key_t rev_key;
    ct_make_reverse_key(&rev_key, key);
    
    entry = bpf_map_lookup_elem(&ct_map, &rev_key);
    if (entry) {
        *is_new = 0;
        
        // This is a reply packet
        entry->state = CT_REPLY;
        
        if (key->protocol == PROTO_TCP) {
            entry->tcp_state = ct_update_tcp_state(entry->tcp_state, tcp_flags, 1);
        }
        
        entry->lifetime = ct_get_timeout(key->protocol, entry->tcp_state, entry->state);
        entry->last_seen = now;
        
        return entry;
    }
    
    // Create new entry
    ct_entry_t new_entry = {
        .rx_packets = 0,
        .tx_packets = 0,
        .rx_bytes = 0,
        .tx_bytes = 0,
        .last_seen = now,
        .lifetime = ct_get_timeout(key->protocol, TCP_STATE_NONE, CT_NEW),
        .state = CT_NEW,
        .tcp_state = TCP_STATE_NONE,
        .seen_flags = tcp_flags,
    };
    
    if (key->protocol == PROTO_TCP) {
        new_entry.tcp_state = ct_update_tcp_state(TCP_STATE_NONE, tcp_flags, 0);
    }
    
    bpf_map_update_elem(&ct_map, key, &new_entry, BPF_ANY);
    
    entry = bpf_map_lookup_elem(&ct_map, key);
    *is_new = 1;
    
    return entry;
}

// Update entry statistics
static __always_inline void ct_update_stats(ct_entry_t *entry, __u32 bytes, int is_reply)
{
    if (is_reply) {
        entry->tx_packets++;
        entry->tx_bytes += bytes;
    } else {
        entry->rx_packets++;
        entry->rx_bytes += bytes;
    }
}

#endif
