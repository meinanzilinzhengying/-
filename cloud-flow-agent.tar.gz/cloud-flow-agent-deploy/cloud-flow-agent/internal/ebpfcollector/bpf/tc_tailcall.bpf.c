// SPDX-License-Identifier: GPL-2.0
// Copyright (c) 2024 Cloud Flow Agent Contributors
//
// TC program with tail call modularization

#include "vmlinux.h"
#include "common.h"
#include "maps.h"
#include "conntrack.h"
#include "tailcall.h"
#include "core.h"

// Helper function to update stats and send event
static __always_inline void update_stats_and_send_event(
    struct __sk_buff *skb, __u32 flow_hash,
    __u32 src_ip, __u32 dst_ip, __u16 src_port, __u16 dst_port,
    __u8 protocol, __u32 data_len, int is_new, ct_entry_t *entry);

// Main TC entry point - dispatches to protocol handlers via tail calls
SEC("tc")
int tc_entry(struct __sk_buff *skb) {
    void *data = (void *)(unsigned long)skb->data;
    void *data_end = (void *)(unsigned long)skb->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip;
    
    if (data + sizeof(*eth) > data_end)
        return TC_ACT_OK;
    
    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return TC_ACT_OK;
    
    ip = data + sizeof(*eth);
    if ((void *)ip + sizeof(*ip) > data_end)
        return TC_ACT_OK;
    
    // Store context in per-cpu map for tail calls to access
    // (tail calls don't preserve stack)
    
    // Dispatch based on protocol
    switch (ip->protocol) {
    case PROTO_TCP:
        tail_call_tcp(skb);
        break;
    case PROTO_UDP:
        tail_call_udp(skb);
        break;
    case PROTO_ICMP:
        tail_call_icmp(skb);
        break;
    }
    
    // If tail call fails, fall through to generic processing
    return TC_ACT_OK;
}

// TCP processing tail call
SEC("tc/tcp")
int tc_tcp(struct __sk_buff *skb) {
    void *data = (void *)(unsigned long)skb->data;
    void *data_end = (void *)(unsigned long)skb->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip = data + sizeof(*eth);
    struct tcphdr *tcp;
    
    tcp = (void *)ip + (ip->ihl * 4);
    if ((void *)tcp + sizeof(*tcp) > data_end)
        return TC_ACT_OK;
    
    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u16 src_port = tcp->source;
    __u16 dst_port = tcp->dest;
    __u8 tcp_flags = tcp->fin | (tcp->syn << 1) | (tcp->rst << 2) |
                     (tcp->psh << 3) | (tcp->ack << 4) | (tcp->urg << 5);
    __u32 data_len = bpf_ntohs(ip->tot_len) - (ip->ihl * 4) - (tcp->doff * 4);
    
    // Build CT key
    ct_key_t key = {
        .saddr = src_ip,
        .daddr = dst_ip,
        .sport = src_port,
        .dport = dst_port,
        .protocol = PROTO_TCP,
    };
    
    int is_new = 0;
    ct_entry_t *entry = ct_lookup(skb, &key, tcp_flags, &is_new);
    if (entry) {
        int is_reply = (entry->state == CT_REPLY);
        ct_update_stats(entry, data_len, is_reply);
    }
    
    // Send event
    __u32 flow_hash = hash_flow(src_ip, dst_ip, src_port, dst_port, PROTO_TCP);
    update_stats_and_send_event(skb, flow_hash, src_ip, dst_ip, src_port, dst_port,
                                 PROTO_TCP, data_len, is_new, entry);
    
    return TC_ACT_OK;
}

// UDP processing tail call
SEC("tc/udp")
int tc_udp(struct __sk_buff *skb) {
    void *data = (void *)(unsigned long)skb->data;
    void *data_end = (void *)(unsigned long)skb->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip = data + sizeof(*eth);
    struct udphdr *udp;
    
    udp = (void *)ip + (ip->ihl * 4);
    if ((void *)udp + sizeof(*udp) > data_end)
        return TC_ACT_OK;
    
    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u16 src_port = udp->source;
    __u16 dst_port = udp->dest;
    __u32 data_len = bpf_ntohs(ip->tot_len) - (ip->ihl * 4) - sizeof(*udp);
    
    ct_key_t key = {
        .saddr = src_ip,
        .daddr = dst_ip,
        .sport = src_port,
        .dport = dst_port,
        .protocol = PROTO_UDP,
    };
    
    int is_new = 0;
    ct_entry_t *entry = ct_lookup(skb, &key, 0, &is_new);
    if (entry) {
        ct_update_stats(entry, data_len, 0);
    }
    
    __u32 flow_hash = hash_flow(src_ip, dst_ip, src_port, dst_port, PROTO_UDP);
    update_stats_and_send_event(skb, flow_hash, src_ip, dst_ip, src_port, dst_port,
                                 PROTO_UDP, data_len, is_new, entry);
    
    return TC_ACT_OK;
}

// ICMP processing tail call
SEC("tc/icmp")
int tc_icmp(struct __sk_buff *skb) {
    void *data = (void *)(unsigned long)skb->data;
    struct ethhdr *eth = data;
    struct iphdr *ip = data + sizeof(*eth);
    
    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u32 data_len = bpf_ntohs(ip->tot_len) - (ip->ihl * 4);
    
    ct_key_t key = {
        .saddr = src_ip,
        .daddr = dst_ip,
        .sport = 0,
        .dport = 0,
        .protocol = PROTO_ICMP,
    };
    
    int is_new = 0;
    ct_entry_t *entry = ct_lookup(skb, &key, 0, &is_new);
    if (entry) {
        ct_update_stats(entry, data_len, 0);
    }
    
    __u32 flow_hash = hash_flow(src_ip, dst_ip, 0, 0, PROTO_ICMP);
    update_stats_and_send_event(skb, flow_hash, src_ip, dst_ip, 0, 0,
                                 PROTO_ICMP, data_len, is_new, entry);
    
    return TC_ACT_OK;
}

// Helper function to update stats and send event
static __always_inline void update_stats_and_send_event(
    struct __sk_buff *skb, __u32 flow_hash,
    __u32 src_ip, __u32 dst_ip, __u16 src_port, __u16 dst_port,
    __u8 protocol, __u32 data_len, int is_new, ct_entry_t *entry)
{
    // Update PERCPU counters
    __u64 *pkt_count = bpf_map_lookup_elem(&pkt_count_map, &flow_hash);
    if (pkt_count) {
        (*pkt_count)++;
    } else {
        __u64 init_count = 1;
        bpf_map_update_elem(&pkt_count_map, &flow_hash, &init_count, BPF_ANY);
    }
    
    __u64 *byte_count = bpf_map_lookup_elem(&byte_count_map, &flow_hash);
    if (byte_count) {
        (*byte_count) += data_len;
    } else {
        bpf_map_update_elem(&byte_count_map, &flow_hash, &data_len, BPF_ANY);
    }
    
    // Send Ring Buffer event
    flow_event_t *event = bpf_ringbuf_reserve(&events, sizeof(*event), 0);
    if (event) {
        event->src_ip = src_ip;
        event->dst_ip = dst_ip;
        event->src_port = src_port;
        event->dst_port = dst_port;
        event->protocol = protocol;
        event->event_type = is_new ? EVENT_TYPE_FLOW_NEW : EVENT_TYPE_FLOW_UPDATE;
        event->ct_state = entry ? entry->state : CT_NEW;
        event->tcp_state = entry ? entry->tcp_state : TCP_STATE_NONE;
        event->bytes = data_len;
        event->packets = 1;
        event->timestamp = bpf_ktime_get_ns();
        event->cpu_id = bpf_get_smp_processor_id();
        event->lifetime = entry ? entry->lifetime : 0;
        bpf_ringbuf_submit(event, 0);
    }
}

char _license[] SEC("license") = "GPL";
