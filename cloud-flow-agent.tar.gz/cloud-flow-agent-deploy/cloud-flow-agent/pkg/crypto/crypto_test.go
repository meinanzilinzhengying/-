package crypto

import (
	"testing"
)

func TestEncryptDecrypt(t *testing.T) {
	enc, err := NewEncryptor("test-secret-key")
	if err != nil {
		t.Fatalf("NewEncryptor failed: %v", err)
	}

	plaintext := "sensitive-data-123"

	ciphertext, err := enc.Encrypt(plaintext)
	if err != nil {
		t.Fatalf("Encrypt failed: %v", err)
	}

	if ciphertext == plaintext {
		t.Error("Ciphertext should not equal plaintext")
	}

	decrypted, err := enc.Decrypt(ciphertext)
	if err != nil {
		t.Fatalf("Decrypt failed: %v", err)
	}

	if decrypted != plaintext {
		t.Errorf("Decrypt() = %q, want %q", decrypted, plaintext)
	}
}

func TestDecryptInvalidCiphertext(t *testing.T) {
	enc, _ := NewEncryptor("test-key")

	_, err := enc.Decrypt("invalid-base64!!!")
	if err == nil {
		t.Error("Decrypt should fail with invalid base64")
	}

	_, err = enc.Decrypt("dG9vIHNob3J0") // "too short" in base64
	if err == nil {
		t.Error("Decrypt should fail with too short ciphertext")
	}
}
