// 分页响应通用类型（与后端 API 返回的分页结构一致）
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page?: number;
  page_size?: number;
}

export * from './user';
export * from './system';
export * from './asset';
export * from './network';
export * from './business';
export * from './service';
