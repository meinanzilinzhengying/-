#!/bin/bash
set -e

# =============================================================================
# 云内流量监测系统 - Agent 探针端离线镜像准备脚本
# =============================================================================
# 在有网络的机器上运行，构建 Agent 镜像并导出为 tar 文件

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo "============================================"
echo "  准备 Agent 离线镜像"
echo "============================================"
echo ""

mkdir -p images

# ── 1. 拉取基础镜像 ──
echo -e "${YELLOW}[1/3] 拉取基础镜像...${NC}"
echo -e "  ${CYAN}拉取: golang:1.22-alpine${NC}"
docker pull golang:1.22-alpine 2>&1
echo -e "  ${CYAN}拉取: alpine:3.20${NC}"
docker pull alpine:3.20 2>&1
echo -e "${GREEN}  ✓ 基础镜像拉取完成${NC}"

# ── 2. 构建 Agent 镜像 ──
echo -e "${YELLOW}[2/3] 构建 Agent 镜像...${NC}"
docker build -t cloud-flow-agent:latest . 2>&1
echo -e "${GREEN}  ✓ Agent 镜像构建完成${NC}"

# ── 3. 导出镜像 ──
echo -e "${YELLOW}[3/3] 导出镜像...${NC}"
echo -e "  ${CYAN}导出: cloud-flow-agent:latest -> images/cloud-flow-agent.tar${NC}"
docker save cloud-flow-agent:latest -o images/cloud-flow-agent.tar 2>&1

echo ""
echo "============================================"
echo -e "  ${GREEN}离线镜像准备完成！${NC}"
echo "============================================"
echo ""
echo "  镜像文件:"
ls -lh images/
echo ""
echo "  总大小:"
du -sh images/
echo ""
echo "  下一步: 将整个 cloud-flow-agent-deploy/ 目录传输到离线服务器"
echo "  然后在离线服务器上执行: ./start.sh"
echo "============================================"
