package bpf

import _ "embed"

//go:embed xdp.bpf.o
var BuiltInXDP []byte
