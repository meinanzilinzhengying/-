#!/bin/bash
set -e

# =============================================================================
# 云内流量监测系统 - Server 端离线镜像准备脚本
# =============================================================================
# 此脚本在有网络的机器上运行，构建镜像并导出为 tar 文件
# 导出的镜像文件放在 images/ 目录下，随部署包一起传输到离线服务器

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo "============================================"
echo "  准备离线 Docker 镜像"
echo "============================================"
echo ""

mkdir -p images

# 检查 .env 文件
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        echo -e "${YELLOW}  未找到 .env，从 .env.example 复制...${NC}"
        cp .env.example .env
    else
        echo -e "${RED}错误: 缺少 .env 和 .env.example 文件${NC}"
        exit 1
    fi
fi

COMPOSE_CMD="docker compose"
if ! docker compose version &> /dev/null 2>&1; then
    COMPOSE_CMD="docker-compose"
fi

# ── 1. 拉取基础镜像 ──
echo -e "${YELLOW}[1/3] 拉取基础镜像...${NC}"
BASE_IMAGES=(
    "pingcap/tidb:v8.4.0"
    "redis:7-alpine"
    "node:20-alpine"
    "nginx:alpine"
    "golang:1.22-alpine"
    "alpine:3.20"
)

for img in "${BASE_IMAGES[@]}"; do
    echo -e "  ${CYAN}拉取: $img${NC}"
    docker pull "$img" 2>&1 || true
done
echo -e "${GREEN}  ✓ 基础镜像拉取完成${NC}"

# ── 2. 构建项目镜像 ──
echo -e "${YELLOW}[2/3] 构建项目镜像...${NC}"
$COMPOSE_CMD build 2>&1
echo -e "${GREEN}  ✓ 项目镜像构建完成${NC}"

# ── 3. 导出所有镜像 ──
echo -e "${YELLOW}[3/3] 导出镜像到 images/ 目录...${NC}"

# 获取项目使用的所有镜像名称
PROJECT_IMAGES=$($COMPOSE_CMD config --images 2>/dev/null | tr -d '[]",' | tr ' ' '\n' | sort -u || echo "")

# 导出项目镜像
for img in $PROJECT_IMAGES; do
    if [ -n "$img" ]; then
        safe_name=$(echo "$img" | tr '/:' '_')
        echo -e "  ${CYAN}导出: $img -> images/${safe_name}.tar${NC}"
        docker save "$img" -o "images/${safe_name}.tar" 2>&1
    fi
done

# 导出基础镜像
echo -e "  ${CYAN}导出: pingcap/tidb:v8.4.0 -> images/pingcap_tidb_v8.4.0.tar${NC}"
docker save pingcap/tidb:v8.4.0 -o images/pingcap_tidb_v8.4.0.tar 2>&1

echo -e "  ${CYAN}导出: redis:7-alpine -> images/redis_7-alpine.tar${NC}"
docker save redis:7-alpine -o images/redis_7-alpine.tar 2>&1

echo ""
echo "============================================"
echo -e "  ${GREEN}离线镜像准备完成！${NC}"
echo "============================================"
echo ""
echo "  镜像文件列表:"
ls -lh images/
echo ""
echo "  总大小:"
du -sh images/
echo ""
echo "  下一步: 将整个 cloud-flow-server/ 目录传输到离线服务器"
echo "  然后在离线服务器上执行: ./start.sh"
echo "============================================"
