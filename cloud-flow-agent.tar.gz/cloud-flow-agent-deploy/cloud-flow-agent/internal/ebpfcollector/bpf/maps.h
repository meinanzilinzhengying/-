// SPDX-License-Identifier: GPL-2.0
#ifndef __MAPS_H__
#define __MAPS_H__

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>

// Event types
#define EVENT_TYPE_FLOW_NEW       1
#define EVENT_TYPE_FLOW_UPDATE    2
#define EVENT_TYPE_FLOW_CLOSE     3
#define EVENT_TYPE_FLOW_ESTABLISHED 4

// CT States (matching Cilium's design)
#define CT_NEW         0
#define CT_ESTABLISHED 1
#define CT_RELATED     2
#define CT_REPLY       3
#define CT_INVALID     4

// TCP states for connection tracking
#define TCP_STATE_NONE      0
#define TCP_STATE_SYN_SENT  1
#define TCP_STATE_SYN_RECV  2
#define TCP_STATE_ESTABLISHED 3
#define TCP_STATE_FIN_WAIT  4
#define TCP_STATE_CLOSE_WAIT 5
#define TCP_STATE_LAST_ACK  6
#define TCP_STATE_TIME_WAIT 7
#define TCP_STATE_CLOSE     8

// Flow event structure for Ring Buffer
typedef struct {
    __u32 src_ip;
    __u32 dst_ip;
    __u16 src_port;
    __u16 dst_port;
    __u8  protocol;
    __u8  event_type;      // NEW/UPDATE/CLOSE/ESTABLISHED
    __u8  ct_state;        // CT_NEW/ESTABLISHED/RELATED/REPLY
    __u8  tcp_state;       // TCP state (for TCP flows)
    __u64 bytes;
    __u64 packets;
    __u64 timestamp;
    __u32 cpu_id;
    __u32 lifetime;        // Remaining lifetime in seconds
} flow_event_t;

// CT entry structure - stored in CT map
typedef struct {
    __u64 rx_packets;      // Packets received (ingress)
    __u64 tx_packets;      // Packets transmitted (egress)
    __u64 rx_bytes;        // Bytes received
    __u64 tx_bytes;        // Bytes transmitted
    __u64 last_seen;       // Last seen timestamp (ns)
    __u32 lifetime;        // Entry timeout
    __u8  state;           // CT state
    __u8  tcp_state;       // TCP state (if applicable)
    __u8  seen_flags;      // TCP flags seen (SYN, ACK, FIN, etc)
    __u8  pad;
} ct_entry_t;

// Flow key for CT lookup
typedef struct {
    __u32 saddr;
    __u32 daddr;
    __u16 sport;
    __u16 dport;
    __u8  protocol;
    __u8  pad[3];
} __attribute__((packed)) ct_key_t;

// Connection tracking map - pinned for persistence across restarts
struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 100000);  // 100K concurrent flows
    __type(key, ct_key_t);
    __type(value, ct_entry_t);
} ct_map SEC(".maps");

// Reverse CT map for reply direction lookup
struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 100000);
    __type(key, ct_key_t);      // Reverse key (dst->src)
    __type(value, __u32);       // Index to main ct_map entry
} ct_reverse_map SEC(".maps");

// Per-CPU packet statistics - pinned for monitoring tools
struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_HASH);
    __uint(max_entries, 65536);
    __type(key, __u32);      // flow hash
    __type(value, __u64);    // packet count
} pkt_count_map SEC(".maps");

// Per-CPU byte statistics - pinned for monitoring tools
struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_HASH);
    __uint(max_entries, 65536);
    __type(key, __u32);      // flow hash
    __type(value, __u64);    // byte count
} byte_count_map SEC(".maps");

// Ring Buffer for real-time events
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);  // 256KB ring buffer
} events SEC(".maps");

// Configuration map - pinned for external configuration
struct config {
    __u32 sampling_rate;     // Packet sampling rate (1/N)
    __u32 max_flows;         // Max flows to track
    __u32 enable_ringbuf;    // Enable ring buffer events
    __u32 tcp_timeout;       // TCP flow timeout (seconds)
    __u32 udp_timeout;       // UDP flow timeout (seconds)
    __u32 icmp_timeout;      // ICMP flow timeout (seconds)
};

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, struct config);
} config_map SEC(".maps");

#endif
