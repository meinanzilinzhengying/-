package ebpfcollector

import (
	"bufio"
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/features"
)

// KernelFeatures holds detected kernel capabilities
type KernelFeatures struct {
	Version       string
	Major, Minor  int
	HasRingbuf    bool
	HasPercpuHash bool
	HasLRUHash    bool
	HasXDP        bool
	HasTC         bool
	HasSockops    bool
	HasCgroupSKB  bool
	HasBTF        bool
	HasBPFLink    bool
	HasMapPinning bool
}

// DetectKernelFeatures probes the kernel for eBPF capabilities
func DetectKernelFeatures() (*KernelFeatures, error) {
	kf := &KernelFeatures{}

	// Get kernel version
	if err := detectKernelVersion(kf); err != nil {
		return nil, fmt.Errorf("detect kernel version: %w", err)
	}

	// Detect map types
	kf.HasRingbuf = detectMapType(ebpf.RingBuf)
	kf.HasPercpuHash = detectMapType(ebpf.PerCPUHash)
	kf.HasLRUHash = detectMapType(ebpf.LRUHash)

	// Detect program types
	kf.HasXDP = detectProgramType(ebpf.XDP)
	kf.HasTC = detectProgramType(ebpf.SchedCLS)
	kf.HasSockops = detectProgramType(ebpf.SockOps)
	kf.HasCgroupSKB = detectProgramType(ebpf.CGroupSKB)

	// BTF support
	kf.HasBTF = detectBTF()

	// bpf_link support (kernel 5.7+)
	kf.HasBPFLink = kf.Major > 5 || (kf.Major == 5 && kf.Minor >= 7)

	// Map pinning support
	kf.HasMapPinning = kf.Major >= 4 || (kf.Major == 4 && kf.Minor >= 4)

	return kf, nil
}

func detectKernelVersion(kf *KernelFeatures) error {
	file, err := os.Open("/proc/version")
	if err != nil {
		return err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	if !scanner.Scan() {
		return fmt.Errorf("empty /proc/version")
	}

	line := scanner.Text()
	// Parse "Linux version 5.15.0-..."
	re := regexp.MustCompile(`Linux version (\d+)\.(\d+)`)
	matches := re.FindStringSubmatch(line)
	if len(matches) >= 3 {
		kf.Major, _ = strconv.Atoi(matches[1])
		kf.Minor, _ = strconv.Atoi(matches[2])
		kf.Version = fmt.Sprintf("%d.%d", kf.Major, kf.Minor)
	}

	return nil
}

func detectMapType(mt ebpf.MapType) bool {
	// Use features package to probe
	err := features.MapType(mt)
	return err == nil
}

func detectProgramType(pt ebpf.ProgramType) bool {
	err := features.ProgramType(pt)
	return err == nil
}

func detectBTF() bool {
	// Check if BTF is available
	_, err := os.Stat("/sys/kernel/btf/vmlinux")
	return err == nil
}

// String returns a human-readable summary
func (kf *KernelFeatures) String() string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Kernel: %s\n", kf.Version))
	sb.WriteString(fmt.Sprintf("  Ringbuf: %v\n", kf.HasRingbuf))
	sb.WriteString(fmt.Sprintf("  PERCPU Hash: %v\n", kf.HasPercpuHash))
	sb.WriteString(fmt.Sprintf("  LRU Hash: %v\n", kf.HasLRUHash))
	sb.WriteString(fmt.Sprintf("  XDP: %v\n", kf.HasXDP))
	sb.WriteString(fmt.Sprintf("  TC: %v\n", kf.HasTC))
	sb.WriteString(fmt.Sprintf("  BTF: %v\n", kf.HasBTF))
	sb.WriteString(fmt.Sprintf("  bpf_link: %v\n", kf.HasBPFLink))
	return sb.String()
}

// CheckRequirements verifies minimum requirements for eBPF collector
func (kf *KernelFeatures) CheckRequirements() error {
	if !kf.HasTC {
		return fmt.Errorf("TC BPF program type not supported")
	}
	if !kf.HasLRUHash {
		return fmt.Errorf("LRU Hash map type not supported (kernel 4.10+ required)")
	}
	if kf.Major < 4 || (kf.Major == 4 && kf.Minor < 10) {
		return fmt.Errorf("kernel version %s too old, 4.10+ required", kf.Version)
	}
	return nil
}
