// Package ebpfcollector 提供基于 eBPF 的网络流量采集功能
package ebpfcollector

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"syscall"
	"time"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
	"github.com/cilium/ebpf/ringbuf"
	"github.com/cilium/ebpf/rlimit"

	"cloud-flow-agent/internal/ebpfcollector/bpf"
	"cloud-flow-agent/internal/ebpfcollector/parser"
	edge "cloud-flow/proto"
)

// Collector eBPF collector with Ring Buffer support
type Collector struct {
	objs      *bpf.Objects
	links     []link.Link
	reader    *ringbuf.Reader
	stopCh    chan struct{}
	collectCh chan []*edge.MetricData
	pinMgr    *PinManager
}

// New creates eBPF collector with Ring Buffer
func New() (*Collector, error) {
	// Remove memlock for kernel < 5.11
	kf, _ := DetectKernelFeatures()
	if kf == nil || kf.Major < 5 || (kf.Major == 5 && kf.Minor < 11) {
		if err := rlimit.RemoveMemlock(); err != nil {
			return nil, fmt.Errorf("remove memlock limit: %w", err)
		}
	}

	// Create pin manager
	pinMgr := NewPinManager("")

	// Check for existing pinned maps (from previous run)
	if pinMgr.IsPinned("ct_map") {
		log.Printf("Found existing pinned maps, attempting to reuse...")
		// Could load existing maps here if needed
	}

	objs, err := loadBPFObjects()
	if err != nil {
		return nil, fmt.Errorf("load eBPF objects: %w", err)
	}

	// Pin maps for persistence
	if err := pinMgr.PinMap("ct_map", objs.CtMap); err != nil {
		log.Printf("Warning: failed to pin ct_map: %v", err)
	}
	if err := pinMgr.PinMap("pkt_count_map", objs.PktCountMap); err != nil {
		log.Printf("Warning: failed to pin pkt_count_map: %v", err)
	}
	if err := pinMgr.PinMap("byte_count_map", objs.ByteCountMap); err != nil {
		log.Printf("Warning: failed to pin byte_count_map: %v", err)
	}
	if err := pinMgr.PinMap("config_map", objs.ConfigMap); err != nil {
		log.Printf("Warning: failed to pin config_map: %v", err)
	}

	links, err := attachProgram(objs.TCProg)
	if err != nil {
		objs.Close()
		return nil, fmt.Errorf("attach eBPF program: %w", err)
	}

	// Create Ring Buffer reader
	reader, err := ringbuf.NewReader(objs.Events)
	if err != nil {
		linksCleanup(links)
		objs.Close()
		return nil, fmt.Errorf("create ringbuf reader: %w", err)
	}

	if err := dropPrivileges(); err != nil {
		log.Printf("Warning: cannot drop privileges: %v", err)
	}

	return &Collector{
		objs:      objs,
		links:     links,
		reader:    reader,
		stopCh:    make(chan struct{}),
		collectCh: make(chan []*edge.MetricData, 100),
		pinMgr:    pinMgr,
	}, nil
}

// NewWithFeatureDetection creates eBPF collector with feature detection
func NewWithFeatureDetection() (*Collector, *KernelFeatures, error) {
	// Detect kernel features first
	kf, err := DetectKernelFeatures()
	if err != nil {
		return nil, nil, fmt.Errorf("kernel feature detection failed: %w", err)
	}

	log.Printf("Kernel features detected:\n%s", kf.String())

	// Check minimum requirements
	if err := kf.CheckRequirements(); err != nil {
		return nil, kf, fmt.Errorf("kernel requirements not met: %w", err)
	}

	// Warn about missing optional features
	if !kf.HasRingbuf {
		log.Printf("Warning: Ring Buffer not available, falling back to map polling")
	}
	if !kf.HasBTF {
		log.Printf("Warning: BTF not available, CO-RE disabled")
	}

	// Create collector
	c, err := New()
	if err != nil {
		return nil, kf, err
	}

	return c, kf, nil
}

func linksCleanup(links []link.Link) {
	for _, l := range links {
		l.Close()
	}
}

// Start starts the collector with Ring Buffer event loop
func (c *Collector) Start() {
	go c.ringBufferLoop()
	go c.percpuStatsLoop()
}

// ringBufferLoop reads events from Ring Buffer (high performance)
func (c *Collector) ringBufferLoop() {
	for {
		select {
		case <-c.stopCh:
			return
		default:
		}

		record, err := c.reader.Read()
		if err != nil {
			if errors.Is(err, ringbuf.ErrClosed) {
				return
			}
			log.Printf("Ring buffer read error: %v", err)
			continue
		}

		// Parse event
		var event bpf.FlowEvent
		if err := binary.Read(bytes.NewReader(record.RawSample), binary.LittleEndian, &event); err != nil {
			log.Printf("Failed to parse event: %v", err)
			continue
		}

		metric := c.eventToMetric(&event)
		select {
		case c.collectCh <- []*edge.MetricData{metric}:
		default:
			// Channel full, drop event (or buffer)
		}
	}
}

// percpuStatsLoop aggregates PERCPU stats periodically
func (c *Collector) percpuStatsLoop() {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			metrics := c.aggregatePerCPUStats()
			if len(metrics) > 0 {
				select {
				case c.collectCh <- metrics:
				default:
				}
			}
		case <-c.stopCh:
			return
		}
	}
}

// eventToMetric converts Ring Buffer event to MetricData
func (c *Collector) eventToMetric(event *bpf.FlowEvent) *edge.MetricData {
	srcIP := net.IPv4(
		byte(event.SrcIP>>24), byte(event.SrcIP>>16),
		byte(event.SrcIP>>8), byte(event.SrcIP),
	).String()
	dstIP := net.IPv4(
		byte(event.DstIP>>24), byte(event.DstIP>>16),
		byte(event.DstIP>>8), byte(event.DstIP),
	).String()

	var protocol string
	switch event.Protocol {
	case 6:
		protocol = "tcp"
	case 17:
		protocol = "udp"
	case 1:
		protocol = "icmp"
	default:
		protocol = "unknown"
	}

	metric := parser.ParseNetworkData(srcIP, dstIP, event.SrcPort, event.DstPort, protocol, nil)
	metric.Timestamp = int64(event.Timestamp / 1000000000) // ns to s
	metric.Bytes = int64(event.Bytes)
	metric.Packets = int64(event.Packets)

	// Add CT state tags
	metric.Tags["cpu_id"] = fmt.Sprintf("%d", event.CpuID)
	metric.Tags["event_type"] = eventTypeToString(event.EventType)
	metric.Tags["ct_state"] = ctStateToString(event.CTState)
	if event.Protocol == 6 { // TCP
		metric.Tags["tcp_state"] = tcpStateToString(event.TCPState)
	}
	metric.Tags["lifetime"] = fmt.Sprintf("%d", event.Lifetime)

	return metric
}

func eventTypeToString(t uint8) string {
	switch t {
	case 1:
		return "NEW"
	case 2:
		return "UPDATE"
	case 3:
		return "CLOSE"
	case 4:
		return "ESTABLISHED"
	default:
		return "UNKNOWN"
	}
}

func ctStateToString(s uint8) string {
	switch s {
	case bpf.CTNew:
		return "NEW"
	case bpf.CTEstablished:
		return "ESTABLISHED"
	case bpf.CTRelated:
		return "RELATED"
	case bpf.CTReply:
		return "REPLY"
	case bpf.CTInvalid:
		return "INVALID"
	default:
		return "UNKNOWN"
	}
}

func tcpStateToString(s uint8) string {
	switch s {
	case bpf.TCPStateNone:
		return "NONE"
	case bpf.TCPStateSynSent:
		return "SYN_SENT"
	case bpf.TCPStateSynRecv:
		return "SYN_RECV"
	case bpf.TCPStateEstablished:
		return "ESTABLISHED"
	case bpf.TCPStateFinWait:
		return "FIN_WAIT"
	case bpf.TCPStateCloseWait:
		return "CLOSE_WAIT"
	case bpf.TCPStateLastAck:
		return "LAST_ACK"
	case bpf.TCPStateTimeWait:
		return "TIME_WAIT"
	case bpf.TCPStateClose:
		return "CLOSE"
	default:
		return "UNKNOWN"
	}
}

// aggregatePerCPUStats aggregates statistics from PERCPU maps
func (c *Collector) aggregatePerCPUStats() []*edge.MetricData {
	// This would iterate over PERCPU maps and aggregate counts
	// Implementation depends on how you want to expose these stats
	return nil
}

// Stop stops the collector
func (c *Collector) Stop() {
	close(c.stopCh)
	c.reader.Close()
	for _, l := range c.links {
		l.Close()
	}

	// Maps are closed by objs.Close()
	// Pins are preserved for next run (LRU map keeps state)
	c.objs.Close()
}

// StopWithCleanup stops and removes all pins
func (c *Collector) StopWithCleanup() error {
	c.Stop()
	return c.pinMgr.Cleanup()
}

// GetPinManager returns the pin manager for external access
func (c *Collector) GetPinManager() *PinManager {
	return c.pinMgr
}

// Collect returns collected metrics
func (c *Collector) Collect() []*edge.MetricData {
	select {
	case metrics := <-c.collectCh:
		return metrics
	case <-time.After(1 * time.Second):
		return nil
	}
}

// dropPrivileges 降权为普通用户
func dropPrivileges() error {
	// 尝试使用 "cloud-flow" 用户，如果不存在则使用 "nobody"
	targetUsers := []string{"cloud-flow", "nobody"}
	var pwd syscall.Passwd
	bufSize := 4096
	buf := make([]byte, bufSize)
	var targetUser string
	var err error
	var ptr *syscall.Passwd

	// 尝试获取用户信息
	for _, user := range targetUsers {
		ptr, err = syscall.Getpwnam_r(user, &pwd, buf, int32(len(buf)))
		if err == syscall.ERANGE {
			// 缓冲区不够大，增大后重试
			bufSize *= 2
			buf = make([]byte, bufSize)
			ptr, err = syscall.Getpwnam_r(user, &pwd, buf, int32(len(buf)))
		}
		if err == nil && ptr != nil {
			targetUser = user
			break
		}
	}

	if ptr == nil {
		log.Printf("Warning: target users %v do not exist, eBPF collector will run as current user", targetUsers)
		return nil
	}

	// 先设置组 ID
	if err := syscall.Setgid(int(pwd.Gid)); err != nil {
		return fmt.Errorf("set gid failed: %w", err)
	}

	// 再设置用户 ID
	if err := syscall.Setuid(int(pwd.Uid)); err != nil {
		return fmt.Errorf("set uid failed: %w", err)
	}

	// 验证权限是否已降
	if syscall.Getuid() != int(pwd.Uid) || syscall.Getgid() != int(pwd.Gid) {
		return fmt.Errorf("privilege drop verification failed")
	}

	// 验证是否能够读取 /proc 目录
	if _, err := os.ReadDir("/proc"); err != nil {
		log.Printf("Warning: cannot read /proc after dropping privileges: %v", err)
	}

	log.Printf("Successfully dropped privileges to user %s (UID: %d, GID: %d)", targetUser, pwd.Uid, pwd.Gid)
	return nil
}

// loadBPFObjects loads eBPF objects
func loadBPFObjects() (*bpf.Objects, error) {
	ebpfFile := findEBPFFile()
	if ebpfFile != "" {
		spec, err := ebpf.LoadCollectionSpec(ebpfFile)
		if err == nil {
			var objs bpf.Objects
			if err := spec.LoadAndAssign(&objs, nil); err == nil {
				log.Printf("Loaded eBPF objects from file: %s", ebpfFile)
				return &objs, nil
			}
			log.Printf("Failed to load from file: %v, trying embedded", err)
		}
	}

	objs, err := bpf.Load(nil)
	if err != nil {
		return nil, fmt.Errorf("load embedded eBPF: %w", err)
	}
	log.Printf("Loaded embedded eBPF objects")
	return objs, nil
}

// findEBPFFile 查找 eBPF 目标文件
func findEBPFFile() string {
	searchPaths := []string{
		"bpf/tc.bpf.o",
		"internal/ebpfcollector/bpf/tc.bpf.o",
		"/etc/cloud-flow-agent/bpf/tc.bpf.o",
		"/usr/share/cloud-flow-agent/bpf/tc.bpf.o",
	}

	for _, path := range searchPaths {
		if _, err := os.Stat(path); err == nil {
			return path
		}
	}

	execPath, err := os.Executable()
	if err == nil {
		dir := filepath.Dir(execPath)
		ebpfFile := filepath.Join(dir, "bpf", "tc.bpf.o")
		if _, err := os.Stat(ebpfFile); err == nil {
			return ebpfFile
		}
	}

	return ""
}

// attachProgram 附加 eBPF 程序到网络设备
func attachProgram(prog *ebpf.Program) ([]link.Link, error) {
	devices, err := net.Interfaces()
	if err != nil {
		return nil, fmt.Errorf("get network interfaces failed: %w", err)
	}

	var links []link.Link
	for _, dev := range devices {
		if dev.Name == "lo" {
			continue
		}

		// 检查设备是否有有效的索引
		if dev.Index <= 0 {
			log.Printf("Device %s has invalid index: %d", dev.Name, dev.Index)
			continue
		}

		// 尝试附加到设备的入站方向
		l, err := link.AttachTC(link.TCOptions{
			Interface: dev.Index,
			Direction: link.TCIngress,
			Program:   prog,
		})
		if err != nil {
			log.Printf("Attach to device %s ingress failed: %v", dev.Name, err)
			continue
		}
		links = append(links, l)

		// 尝试附加到设备的出站方向
		l, err = link.AttachTC(link.TCOptions{
			Interface: dev.Index,
			Direction: link.TCEgress,
			Program:   prog,
		})
		if err != nil {
			log.Printf("Attach to device %s egress failed: %v", dev.Name, err)
			continue
		}
		links = append(links, l)
	}

	if len(links) == 0 {
		log.Printf("Warning: failed to attach to any network device")
	}

	return links, nil
}

// IsAvailable 检查 eBPF 采集器是否可用
func (c *Collector) IsAvailable() bool {
	return c != nil && c.objs != nil && c.objs.Events != nil
}

// GetMap 获取指定的 eBPF map
func (c *Collector) GetMap(name string) *ebpf.Map {
	switch name {
	case "events":
		return c.objs.Events
	case "ct_map":
		return c.objs.CtMap
	case "ct_reverse_map":
		return c.objs.CtReverseMap
	case "pkt_count_map":
		return c.objs.PktCountMap
	case "byte_count_map":
		return c.objs.ByteCountMap
	case "config_map":
		return c.objs.ConfigMap
	default:
		return nil
	}
}

// NewWithFallback 创建一个采集器，如果 eBPF 不可用则使用回退方案
func NewWithFallback() (*Collector, error) {
	collector, err := New()
	if err != nil {
		log.Printf("eBPF collector initialization failed: %v, will use traditional collector as fallback", err)
		return nil, err
	}
	return collector, nil
}
