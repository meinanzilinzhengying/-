<template>

  <div class="metrics-center">

 <!-- 指标中心 -->

    <el-card class="mb-4">

      <template #header>

        <div class="card-header">

          <h2>{{ currentPageTitle }}</h2>

        </div>

      </template>

      

 <!-- 主机页面 -->

      <div v-if="currentPage === 'host'">

 <!-- 搜索和筛选-->

        <div class="search-filter mb-4">

          <el-form :inline="true" :model="searchForm" class="demo-form-inline">

            <el-form-item label="时间范围">

              <el-input v-model="searchForm.keyword" placeholder="输入主机名或IP" style="width: 300px;" />

            </el-form-item>

            <el-form-item>

              <el-button type="primary" @click="handleSearch">搜索</el-button>

            </el-form-item>

          </el-form>

        </div>

        

 <!-- 主机列表 -->

        <div class="host-list">

          <el-table 

            :data="hosts" 

            style="width: 100%"

            @row-click="handleRowClick"

          >

            <el-table-column prop="name" label="主机名称" width="200" />

            <el-table-column prop="ip" label="实例IP" width="150" />

            <el-table-column prop="os" label="操作系统" width="150" />

            <el-table-column prop="cpuUsage" label="CPU使用率" width="180">

              <template #default="scope">

                <div class="progress-container">

                  <el-progress 

                    :percentage="scope.row.cpuUsage" 

                    :color="getProgressColor(scope.row.cpuUsage)"

                    :stroke-width="10"

                  />

                  <span class="progress-text">{{ scope.row.cpuUsage }}%</span>

                </div>

              </template>

            </el-table-column>

            <el-table-column prop="memUsage" label="MEM使用率" width="180">

              <template #default="scope">

                <div class="progress-container">

                  <el-progress 

                    :percentage="scope.row.memUsage" 

                    :color="getProgressColor(scope.row.memUsage)"

                    :stroke-width="10"

                  />

                  <span class="progress-text">{{ scope.row.memUsage }}%</span>

                </div>

              </template>

            </el-table-column>

            <el-table-column prop="load" label="系统负载" width="100" />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" type="primary" @click="handleRowClick(scope.row)">

                  查看详情

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 右滑框查看历史指标 -->

          <el-drawer

            v-model="drawerVisible"

            direction="rtl"

            :title="`${selectedHost?.name} (${selectedHost?.ip})`"

            size="70%"

          >

            <div class="host-detail">

              <div class="detail-header">

                <el-descriptions :column="3">

                  <el-descriptions-item label="主机名称">{{ selectedHost?.name }}</el-descriptions-item>

                  <el-descriptions-item label="实例IP">{{ selectedHost?.ip }}</el-descriptions-item>

                  <el-descriptions-item label="操作系统">{{ selectedHost?.os }}</el-descriptions-item>

                  <el-descriptions-item label="CPU使用">{{ selectedHost?.cpuUsage }}%</el-descriptions-item>

                  <el-descriptions-item label="MEM使用">{{ selectedHost?.memUsage }}%</el-descriptions-item>

                  <el-descriptions-item label="系统负载">{{ selectedHost?.load }}</el-descriptions-item>

                </el-descriptions>

              </div>

              

 <!-- 时间范围选择 -->

              <div class="time-range-select mb-4">

                <el-select v-model="historyTimeRange" placeholder="最近小时" style="margin-right: 10px;">

                  <el-option label="最近1小时" value="1h" />

                  <el-option label="最近6小时" value="6h" />

                  <el-option label="最近12小时" value="12h" />

                  <el-option label="最近24小时" value="24h" />

                  <el-option label="最近7天" value="7d" />

                </el-select>

                <el-button type="primary" @click="refreshHistory">

                  <el-icon><Refresh /></el-icon> 刷新

                </el-button>

              </div>

              

 <!-- 历史指标图表 -->

              <div class="history-charts">

                <el-row :gutter="20">

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>CPU使用率</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar cpu-bar" :style="{ height: cpuHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>内存使用率</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar mem-bar" :style="{ height: memHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>网络入流量</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar net-in-bar" :style="{ height: netInHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>网络出流量</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar net-out-bar" :style="{ height: netOutHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>磁盘使用率</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar disk-bar" :style="{ height: diskHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>系统负载</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar load-bar" :style="{ height: loadHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                </el-row>

              </div>

            </div>

          </el-drawer>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ hostTotal }} 台主机

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="hostTotal"

              :page-size="pageSize"

              :current-page="hostCurrentPage"

              @current-change="handleCurrentChange"

            />

          </div>

        </div>

      </div>

      

 <!-- 页面布局 -->

      <div v-else-if="currentPage === 'container'">

 <!-- 搜索和筛选-->

        <div class="search-filter mb-4">

          <el-form :inline="true" :model="containerSearchForm" class="demo-form-inline">

            <el-form-item label="时间范围">

              <el-input v-model="containerSearchForm.keyword" placeholder="输入容器名称、命名空间或IP" style="width: 300px;" />

            </el-form-item>

            <el-form-item label="命名空间">

              <el-select v-model="containerSearchForm.namespace" placeholder="全部" style="width: 150px;">

                <el-option label="全部" value="all" />

                <el-option label="default" value="default" />

                <el-option label="kube-system" value="kube-system" />

                <el-option label="app" value="app" />

              </el-select>

            </el-form-item>

            <el-form-item>

              <el-button type="primary" @click="handleContainerSearch">搜索</el-button>

            </el-form-item>

          </el-form>

        </div>

        

 <!-- 容器列表 -->

        <div class="container-list">

          <el-table 

            :data="containers" 

            style="width: 100%"

            @row-click="handleContainerRowClick"

          >

            <el-table-column prop="podName" label="POD策略" width="200" />

            <el-table-column prop="ip" label="实例IP" width="150" />

            <el-table-column prop="node" label="所属Node" width="180" />

            <el-table-column prop="namespace" label="所在命名空间" width="150" />

            <el-table-column prop="restartCount" label="重启次数" width="100" />

            <el-table-column prop="status" label="状态" width="100">

              <template #default="scope">

                <el-tag :type="scope.row.status === '运行中' ? 'success' : 'danger'">

                  {{ scope.row.status }}

                </el-tag>

              </template>

            </el-table-column>

            <el-table-column prop="runTime" label="总运行时长" width="150" />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" type="primary" @click="handleContainerRowClick(scope.row)">

                  查看详情

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 右滑框查看历史指标 -->

          <el-drawer

            v-model="containerDrawerVisible"

            direction="rtl"

            :title="selectedContainer?.podName"

            size="70%"

          >

            <div class="container-detail">

              <div class="detail-header">

                <el-descriptions :column="3">

                  <el-descriptions-item label="POD策略">{{ selectedContainer?.podName }}</el-descriptions-item>

                  <el-descriptions-item label="实例IP">{{ selectedContainer?.ip }}</el-descriptions-item>

                  <el-descriptions-item label="所属Node">{{ selectedContainer?.node }}</el-descriptions-item>

                  <el-descriptions-item label="所在命名空间">{{ selectedContainer?.namespace }}</el-descriptions-item>

                  <el-descriptions-item label="重启次数">{{ selectedContainer?.restartCount }}</el-descriptions-item>

                  <el-descriptions-item label="状态">{{ selectedContainer?.status }}</el-descriptions-item>

                  <el-descriptions-item label="总运行时长">{{ selectedContainer?.runTime }}</el-descriptions-item>

                </el-descriptions>

                

 <!-- Container 切换下拉菜单 -->

                <div class="container-select mt-4">

                  <el-form :inline="true" :model="containerForm" class="demo-form-inline">

                    <el-form-item label="切换 container:">

                      <el-select v-model="containerForm.selectedContainer" placeholder="选择容器" style="width: 300px;">

                        <el-option 

                          v-for="container in selectedContainer?.containers" 

                          :key="container.id" 

                          :label="container.name" 

                          :value="container.id"

                        />

                      </el-select>

                    </el-form-item>

                  </el-form>

                </div>

              </div>

              

 <!-- 时间范围选择 -->

              <div class="time-range-select mb-4">

                <el-select v-model="containerHistoryTimeRange" placeholder="最近小时" style="margin-right: 10px;">

                  <el-option label="最近1小时" value="1h" />

                  <el-option label="最近6小时" value="6h" />

                  <el-option label="最近12小时" value="12h" />

                  <el-option label="最近24小时" value="24h" />

                  <el-option label="最近7天" value="7d" />

                </el-select>

                <el-button type="primary" @click="refreshContainerHistory">

                  <el-icon><Refresh /></el-icon> 刷新

                </el-button>

              </div>

              

 <!-- 历史指标图表 -->

              <div class="history-charts">

                <el-row :gutter="20">

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>CPU使用率</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar cpu-bar" :style="{ height: containerCpuHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>内存使用率</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar mem-bar" :style="{ height: containerMemHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>网络入流量</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar net-in-bar" :style="{ height: containerNetInHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                  <el-col :span="12">

                    <el-card class="mb-4">

                      <template #header>

                        <div class="chart-header">

                          <h3>网络出流量</h3>

                        </div>

                      </template>

                      <div class="chart-content">

                        <div class="mock-chart">

                          <div class="chart-bars">

                            <div v-for="i in 30" :key="i" class="chart-bar net-out-bar" :style="{ height: containerNetOutHistoryData[i-1] + '%' }"></div>

                          </div>

                          <div class="chart-x-axis">

                            <div v-for="i in 6" :key="i" class="x-axis-label">{{ 12 + i }}:00</div>

                          </div>

                        </div>

                      </div>

                    </el-card>

                  </el-col>

                </el-row>

              </div>

            </div>

          </el-drawer>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ containerTotal }} 个容器

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="containerTotal"

              :page-size="containerPageSize"

              :current-page="containerCurrentPage"

              @current-change="handleContainerCurrentChange"

            />

          </div>

        </div>

      </div>

      

 <!-- 指标查看页面 -->

      <div v-else-if="currentPage === 'view'">

        <div class="metrics-view-content">

 <!-- 顶部控制 -->
          <div class="metrics-view-header">

            <div class="time-range-selector">

              <el-select v-model="metricsTimeRange" placeholder="最近15分钟" style="margin-right: 10px;">

                <el-option label="最近15分钟" value="5m" />

                <el-option label="最近15分钟" value="15m" />

                <el-option label="最近30分钟" value="30m" />

                <el-option label="最近1小时" value="1h" />

                <el-option label="最近6小时" value="6h" />

                <el-option label="最近12小时" value="12h" />

                <el-option label="最近24小时" value="24h" />

                <el-option label="最近7天" value="7d" />

              </el-select>

              <el-button type="primary" @click="refreshMetrics">

                <el-icon><Refresh /></el-icon> 刷新

              </el-button>

              <el-button @click="autoRefresh = !autoRefresh">

                自动 ({{ autoRefresh ? '开' : '关' }})

              </el-button>

            </div>

          </div>

          

 <!-- 指标告警管理 -->

          <div class="metrics-config">

 <!-- 数据库表A -->

            <div class="metrics-table">

              <div class="table-header">

                <el-collapse v-model="tableACollapsed">

                  <el-collapse-item title="A 数据库" name="1">

                    <div class="table-controls">

                      <el-form :inline="true" :model="tableAForm" class="demo-form-inline">

                        <el-form-item label="应用">

                          <el-select v-model="tableAForm.application" placeholder="选择应用" style="width: 150px;">

                            <el-option label="应用1" value="app1" />

                            <el-option label="应用2" value="app2" />

                            <el-option label="应用3" value="app3" />

                          </el-select>

                        </el-form-item>

                        <el-form-item label="聚合间隔">

                          <el-select v-model="tableAForm.interval" placeholder="分钟" style="width: 150px;">

                            <el-option label="秒级" value="second" />

                            <el-option label="分钟" value="minute" />

                            <el-option label="小时" value="hour" />

                            <el-option label="天级" value="day" />

                          </el-select>

                        </el-form-item>

                        <el-form-item>

                          <el-button type="primary" @click="applyTableA">应用</el-button>

                        </el-form-item>

                        <el-form-item>

                          <el-button type="danger" @click="clearTableA">

                            <el-icon><Delete /></el-icon>

                          </el-button>

                        </el-form-item>

                      </el-form>

                      

 <!-- 搜索条件 -->

                      <div class="search-condition">

                        <el-input v-model="tableASearch" placeholder="输入搜索条件" style="width: 500px;" />

                        <el-select v-model="tableAGroupBy" placeholder="分组" style="margin-left: 10px; width: 120px;">

                          <el-option label="无" value="none" />

                          <el-option label="应用" value="app" />

                          <el-option label="主机" value="host" />

                        </el-select>

                        <el-select v-model="tableASubGroupBy" placeholder="子分组" style="margin-left: 10px; width: 120px;">

                          <el-option label="无" value="none" />

                          <el-option label="应用" value="app" />

                          <el-option label="主机" value="host" />

                        </el-select>

                      </div>

                    </div>

                  </el-collapse-item>

                </el-collapse>

              </div>

              

 <!-- 指标列表 -->

              <div class="metrics-list">

                <div v-for="(metric, index) in tableAMetrics" :key="index" class="metric-item">

                  <el-form :inline="true" :model="metric" class="demo-form-inline">

                    <el-form-item>

                      <el-select v-model="metric.name" placeholder="选择指标" style="width: 120px;">

                        <el-option label="请求" value="request" />

                        <el-option label="响应" value="response" />

                        <el-option label="错误" value="error" />

                      </el-select>

                    </el-form-item>

                    <el-form-item>

                      <el-select v-model="metric.aggregation" placeholder="选择聚合方式" style="width: 120px;">

                        <el-option label="Avg" value="avg" />

                        <el-option label="Sum" value="sum" />

                        <el-option label="Max" value="max" />

                        <el-option label="Min" value="min" />

                      </el-select>

                    </el-form-item>

                    <el-form-item>

                      <el-button @click="editMetric(index, 'A')">

                        <el-icon><Edit /></el-icon>

                      </el-button>

                    </el-form-item>

                    <el-form-item>

                      <el-switch v-model="metric.enabled" style="margin-right: 10px;" />

                    </el-form-item>

                    <el-form-item>

                      <el-button type="danger" @click="removeMetric(index, 'A')">

                        <el-icon><Delete /></el-icon>

                      </el-button>

                    </el-form-item>

                  </el-form>

                </div>

                

 <!-- 添加指标按钮 -->

                <div class="add-metric">

                  <el-button type="primary" @click="addMetric('A')">

                    <el-icon><Plus /></el-icon> 添加指标

                  </el-button>

                </div>

              </div>

            </div>

            

 <!-- 数据库表B -->

            <div class="metrics-table">

              <div class="table-header">

                <el-collapse v-model="tableBCollapsed">

                  <el-collapse-item title="B 数据库" name="1">

                    <div class="table-controls">

                      <el-form :inline="true" :model="tableBForm" class="demo-form-inline">

                        <el-form-item label="应用">

                          <el-select v-model="tableBForm.application" placeholder="选择应用" style="width: 150px;">

                            <el-option label="应用1" value="app1" />

                            <el-option label="应用2" value="app2" />

                            <el-option label="应用3" value="app3" />

                          </el-select>

                        </el-form-item>

                        <el-form-item label="日志类型">

                          <el-select v-model="tableBForm.logType" placeholder="端侧日志" style="width: 150px;">

                            <el-option label="端侧日志" value="client" />

                            <el-option label="服务端日" value="server" />

                            <el-option label="线程日志" value="system" />

                          </el-select>

                        </el-form-item>

                        <el-form-item>

                          <el-button type="primary" @click="applyTableB">应用</el-button>

                        </el-form-item>

                        <el-form-item>

                          <el-button type="danger" @click="clearTableB">

                            <el-icon><Delete /></el-icon>

                          </el-button>

                        </el-form-item>

                      </el-form>

                      

 <!-- 搜索条件 -->

                      <div class="search-condition">

                        <el-input v-model="tableBSearch" placeholder="输入搜索条件" style="width: 500px;" />

                        <el-select v-model="tableBGroupBy" placeholder="分组" style="margin-left: 10px; width: 120px;">

                          <el-option label="无" value="none" />

                          <el-option label="应用" value="app" />

                          <el-option label="主机" value="host" />

                        </el-select>

                        <el-select v-model="tableBSubGroupBy" placeholder="子分组" style="margin-left: 10px; width: 120px;">

                          <el-option label="无" value="none" />

                          <el-option label="应用" value="app" />

                          <el-option label="主机" value="host" />

                        </el-select>

                      </div>

                    </div>

                  </el-collapse-item>

                </el-collapse>

              </div>

              

 <!-- 指标列表 -->

              <div class="metrics-list">

                <div v-for="(metric, index) in tableBMetrics" :key="index" class="metric-item">

                  <el-form :inline="true" :model="metric" class="demo-form-inline">

                    <el-form-item>

                      <el-select v-model="metric.name" placeholder="选择指标" style="width: 120px;">

                        <el-option label="分组聚合详情" value="response_time" />

                        <el-option label="错误" value="error_rate" />

                        <el-option label="吞吐" value="throughput" />

                      </el-select>

                    </el-form-item>

                    <el-form-item>

                      <el-select v-model="metric.aggregation" placeholder="选择聚合方式" style="width: 120px;">

                        <el-option label="Avg" value="avg" />

                        <el-option label="Sum" value="sum" />

                        <el-option label="Max" value="max" />

                        <el-option label="Min" value="min" />

                      </el-select>

                    </el-form-item>

                    <el-form-item>

                      <el-button @click="editMetric(index, 'B')">

                        <el-icon><Edit /></el-icon>

                      </el-button>

                    </el-form-item>

                    <el-form-item>

                      <el-switch v-model="metric.enabled" style="margin-right: 10px;" />

                    </el-form-item>

                    <el-form-item>

                      <el-button type="danger" @click="removeMetric(index, 'B')">

                        <el-icon><Delete /></el-icon>

                      </el-button>

                    </el-form-item>

                  </el-form>

                </div>

                

 <!-- 添加指标按钮 -->

                <div class="add-metric">

                  <el-button type="primary" @click="addMetric('B')">

                    <el-icon><Plus /></el-icon> 添加指标

                  </el-button>

                </div>

              </div>

            </div>

            

 <!-- 添加查询按钮 -->

            <div class="add-query">

              <el-button type="success" @click="addQuery">

                <el-icon><Plus /></el-icon> 添加查询

              </el-button>

            </div>

          </div>

          

 <!-- 图表展示和布局管理 -->

          <div class="metrics-charts">

            <el-row :gutter="20">

              <el-col :span="8">

                <el-card class="mb-4">

                  <template #header>

                    <div class="chart-header">

                      <h3>Avg(请求)</h3>

                    </div>

                  </template>

                  <div class="chart-content">

                    <div class="mock-chart">

                      <div class="chart-bars">

                        <div v-for="(height, index) in cpuChartData" :key="index" class="chart-bar cpu-bar" :style="{ height: height + '%' }"></div>

                      </div>

                      <div class="chart-x-axis">

                        <div v-for="i in 6" :key="i" class="x-axis-label">{{ 17 + i }}:47</div>

                      </div>

                    </div>

                  </div>

                </el-card>

              </el-col>

              <el-col :span="8">

                <el-card class="mb-4">

                  <template #header>

                    <div class="chart-header">

                      <h3>Avg(响应)</h3>

                    </div>

                  </template>

                  <div class="chart-content">

                    <div class="mock-chart">

                      <div class="chart-bars">

                        <div v-for="(height, index) in memChartData" :key="index" class="chart-bar mem-bar" :style="{ height: height + '%' }"></div>

                      </div>

                      <div class="chart-x-axis">

                        <div v-for="i in 6" :key="i" class="x-axis-label">{{ 17 + i }}:47</div>

                      </div>

                    </div>

                  </div>

                </el-card>

              </el-col>

              <el-col :span="8">

                <el-card class="mb-4">

                  <template #header>

                    <div class="chart-header">

                      <h3>Avg(分组聚合详情)</h3>

                    </div>

                  </template>

                  <div class="chart-content">

                    <div class="mock-chart">

                      <div class="chart-bars">

                        <div v-for="(height, index) in netInChartData" :key="index" class="chart-bar net-in-bar" :style="{ height: height + '%' }"></div>

                      </div>

                      <div class="chart-x-axis">

                        <div v-for="i in 6" :key="i" class="x-axis-label">{{ 17 + i }}:47</div>

                      </div>

                    </div>

                  </div>

                </el-card>

              </el-col>

            </el-row>

          </div>

        </div>

      </div>

      

 <!-- 指标摘要页面 -->

      <div v-else-if="currentPage === 'summary'">

        <div class="metrics-summary-content">

 <!-- 顶部控制 -->
          <div class="summary-header">

            <div class="metrics-collection">

              <el-form :inline="true" :model="summaryForm" class="demo-form-inline">

                <el-form-item label="指标集合">

                  <el-select v-model="summaryForm.collection" placeholder="选择指标集合" style="width: 150px;">

                    <el-option label="网络" value="network" />

                    <el-option label="系统" value="system" />

                    <el-option label="应用" value="application" />

                    <el-option label="数据库" value="database" />

                  </el-select>

                </el-form-item>

                <el-form-item label="数据库">

                  <el-select v-model="summaryForm.table" placeholder="选择数据库" style="width: 150px;">

                    <el-option label="数据库表A" value="tableA" />

                    <el-option label="数据库表B" value="tableB" />

                    <el-option label="数据库表C" value="tableC" />

                  </el-select>

                </el-form-item>

                <el-form-item>

                  <el-button type="primary" @click="refreshSummary">

                    <el-icon><Refresh /></el-icon> 重新检索

                  </el-button>

                </el-form-item>

              </el-form>

            </div>

          </div>

          

 <!-- 标签页切换 -->

          <div class="summary-tabs">

            <el-tabs v-model="summaryActiveTab">

              <el-tab-pane label="METRICS" name="metrics">

 <!-- Metrics 表格 -->

                <div class="metrics-table">

                  <el-table :data="metricsData" style="width: 100%">

                    <el-table-column prop="name" label="name" width="120" />

                    <el-table-column prop="unit" label="unit" width="80" />

                    <el-table-column prop="type" label="Type" width="100" />

                    <el-table-column prop="displayName" label="display_name" width="120" />

                    <el-table-column prop="category" label="category" width="120" />

                    <el-table-column prop="description" label="响应时间" min-width="200" />

                  </el-table>

                  

 <!-- 数据库表 -->

                  <div class="pagination mt-4">

                    <div class="pagination-info">

                      共 {{ metricsTotal }} 条

                    </div>

                    <el-pagination

                      background

                      layout="prev, pager, next, jumper"

                      :total="metricsTotal"

                      :page-size="metricsPageSize"

                      :current-page="metricsCurrentPage"

                      @current-change="handleMetricsPageChange"

                    />

                  </div>

                </div>

              </el-tab-pane>

              <el-tab-pane label="TAG" name="tag">

 <!-- Tag 表格 -->

                <div class="tag-table">

                  <el-table :data="tagData" style="width: 100%">

                    <el-table-column prop="name" label="name" width="120" />

                    <el-table-column prop="description" label="响应时间" min-width="200" />

                    <el-table-column prop="type" label="类型" width="100" />

                    <el-table-column prop="example" label="示例" min-width="150" />

                  </el-table>

                  

 <!-- 数据库表 -->

                  <div class="pagination mt-4">

                    <div class="pagination-info">

                      共 {{ tagTotal }} 条

                    </div>

                    <el-pagination

                      background

                      layout="prev, pager, next, jumper"

                      :total="tagTotal"

                      :page-size="tagPageSize"

                      :current-page="tagCurrentPage"

                      @current-change="handleTagPageChange"

                    />

                  </div>

                </div>

              </el-tab-pane>

            </el-tabs>

          </div>

        </div>

      </div>

      

 <!-- 指标模板页面 -->

      <div v-else-if="currentPage === 'template'">

        <div class="metrics-template-content">

 <!-- 顶部控制 -->

          <div class="template-header">

            <el-button type="primary" @click="openCreateTemplateDialog">

              <el-icon><Plus /></el-icon> 新建模板

            </el-button>

            <div class="template-filters">

              <el-form :inline="true" :model="templateForm" class="demo-form-inline">

                <el-form-item label="数据库">

                  <el-select v-model="templateForm.table" placeholder="选择数据库" style="width: 150px;">

                    <el-option label="全部" value="all" />

                    <el-option label="网络" value="network" />

                    <el-option label="系统" value="system" />

                    <el-option label="应用" value="application" />

                    <el-option label="数据库" value="database" />

                  </el-select>

                </el-form-item>

                <el-form-item label="网络指标">

                  <el-select v-model="templateForm.service" placeholder="选择服务指标" style="width: 150px;">

                    <el-option label="全部" value="all" />

                    <el-option label="流量监控" value="traffic" />

                    <el-option label="性能监控" value="performance" />

                    <el-option label="错误监控" value="error" />

                  </el-select>

                </el-form-item>

                <el-form-item>

                  <el-input v-model="templateForm.search" placeholder="搜索关键词" style="width: 200px;" />

                </el-form-item>

                <el-form-item>

                  <el-button type="primary" @click="searchTemplates">

                    <el-icon><Search /></el-icon> 搜索

                  </el-button>

                </el-form-item>

              </el-form>

            </div>

          </div>

          

 <!-- 模板列表 -->

          <div class="template-list">

            <el-table :data="templates" style="width: 100%">

              <el-table-column type="expand">

                <template #default="scope">

                  <el-table :data="scope.row.metrics" style="width: 100%">

                    <el-table-column prop="name" label="指标策略" width="120" />

                    <el-table-column prop="alias" label="别名" width="120" />

                    <el-table-column prop="aggregation" label="聚合" width="80" />

                    <el-table-column prop="function" label="函数" width="100" />

                    <el-table-column prop="unit" label="单位" width="80" />

                    <el-table-column prop="threshold" label="阈值" width="80" />

                  </el-table>

                </template>

              </el-table-column>

              <el-table-column prop="name" label="名称" width="120" />

              <el-table-column prop="team" label="团队" width="120" />

              <el-table-column prop="database" label="数据库" width="120" />

              <el-table-column prop="metricsType" label="数据库类型" width="120" />

              <el-table-column prop="creator" label="创建人" width="100" />

              <el-table-column prop="lastUsed" label="最近使用时间" width="150" />

              <el-table-column label="操作" width="120" fixed="right">

                <template #default="scope">

                  <el-button 

                    size="small" 

                    type="primary" 

                    @click="editTemplate(scope.row)"

                    :disabled="scope.row.isDefault"

                  >

                    <el-icon><Edit /></el-icon> 编辑

                  </el-button>

                  <el-button 

                    size="small" 

                    type="danger" 

                    @click="deleteTemplate(scope.row)"

                    :disabled="scope.row.isDefault"

                  >

                    <el-icon><Delete /></el-icon> 删除

                  </el-button>

                </template>

              </el-table-column>

            </el-table>

            

 <!-- 数据库表 -->

            <div class="pagination mt-4">

              <div class="pagination-info">

                共 {{ templateTotal }} 条

              </div>

              <el-pagination

                background

                layout="prev, pager, next, jumper"

                :total="templateTotal"

                :page-size="templatePageSize"

                :current-page="templateCurrentPage"

                @current-change="handleTemplatePageChange"

              />

            </div>

          </div>

          

 <!-- 新建连接/编辑模板对话框-->

          <el-dialog

            v-model="templateDialogVisible"

            :title="isEditTemplate ? '编辑网络指标监控' : '新建网络指标监控'"

            width="800px"

          >

            <el-form :model="newTemplateForm" label-width="100px">

              <el-form-item label="模板策略" required>

                <el-input v-model="newTemplateForm.name" placeholder="请输入模板名" />

              </el-form-item>

              <el-form-item label="团队" required>

                <el-select v-model="newTemplateForm.team" placeholder="选择团队" style="width: 100%;">

                  <el-option label="Default团队" value="default" />

                  <el-option label="开发团队" value="dev" />

                  <el-option label="测试团队" value="test" />

                  <el-option label="运维团队" value="ops" />

                </el-select>

              </el-form-item>

              <el-form-item label="数据库" required>

                <el-select v-model="newTemplateForm.database" placeholder="选择数据库" style="width: 100%;">

                  <el-option label="应用" value="application" />

                  <el-option label="网络" value="network" />

                  <el-option label="系统" value="system" />

                  <el-option label="数据库" value="database" />

                </el-select>

              </el-form-item>

              <el-form-item label="网络指标" required>

                <el-select v-model="newTemplateForm.service" placeholder="选择服务指标" style="width: 100%;">

                  <el-option label="流量监控" value="traffic" />

                  <el-option label="性能监控" value="performance" />

                  <el-option label="错误监控" value="error" />

                </el-select>

              </el-form-item>

              

 <!-- 指标列表 -->

              <el-form-item label="指标">

                <div class="metrics-list">

                  <div v-for="(metric, index) in newTemplateForm.metrics" :key="index" class="metric-item">

                    <el-form :inline="true" :model="metric" class="demo-form-inline">

                      <el-form-item>

                        <el-select v-model="metric.name" placeholder="选择指标" style="width: 120px;">

                          <el-option label="请求" value="request" />

                          <el-option label="响应" value="response" />

                          <el-option label="错误" value="error" />

                          <el-option label="平均时延" value="avg_latency" />

                          <el-option label="异常" value="anomaly" />

                        </el-select>

                      </el-form-item>

                      <el-form-item>

                        <el-select v-model="metric.aggregation" placeholder="聚合" style="width: 80px;">

                          <el-option label="Avg" value="avg" />

                          <el-option label="Sum" value="sum" />

                          <el-option label="Max" value="max" />

                          <el-option label="Min" value="min" />

                        </el-select>

                      </el-form-item>

                      <el-form-item>

                        <el-select v-model="metric.function" placeholder="函数" style="width: 100px;">

                          <el-option label="PerSecond" value="per_second" />

                          <el-option label="PerMinute" value="per_minute" />

                          <el-option label="Raw" value="raw" />

                        </el-select>

                      </el-form-item>

                      <el-form-item>

                        <el-input v-model="metric.alias" placeholder="别名" style="width: 120px;" />

                      </el-form-item>

                      <el-form-item>

                        <el-input v-model="metric.unit" placeholder="单位" style="width: 80px;" />

                      </el-form-item>

                      <el-form-item>

                        <el-input v-model="metric.threshold" placeholder="阈值" style="width: 80px;" />

                      </el-form-item>

                      <el-form-item>

                        <el-switch v-model="metric.enabled" style="margin-right: 10px;" />

                      </el-form-item>

                      <el-form-item>

                        <el-button type="danger" @click="removeTemplateMetric(index)">

                          <el-icon><Delete /></el-icon>

                        </el-button>

                      </el-form-item>

                    </el-form>

                  </div>

                  

 <!-- 添加指标按钮 -->

                  <div class="add-metric">

                    <el-button type="primary" @click="addTemplateMetric">

                      <el-icon><Plus /></el-icon> 添加指标

                    </el-button>

                  </div>

                </div>

              </el-form-item>

            </el-form>

            <template #footer>

              <span class="dialog-footer">

                <el-button @click="templateDialogVisible = false">取消</el-button>

                <el-button type="primary" @click="saveTemplate">确定</el-button>

              </span>

            </template>

          </el-dialog>

        </div>

      </div>

    </el-card>

  </div>

</template>



<script setup lang="ts">

import { ref, computed, watch, onMounted } from 'vue'

// 生成模拟数据库（仅在组件挂载时调用一次，避免图表跳动）
const generateMockData = (max: number, min: number, count: number = 30) =>
  Array(count).fill(0).map(() => Math.random() * max + min)

import { useRoute } from 'vue-router'

import { Refresh } from '@element-plus/icons-vue'

import { api } from '../utils/api'



// 路由

const route = useRoute()



// 响应路由变化 - 响应路由变化

const currentPage = ref('host')



// 页面标题

const currentPageTitle = computed(() => {

  const pageTitles = {

    'host': '主机',

    'container': '容器',

    'view': '数据库视图',

    'summary': '指标摘要',

    'template': '指标模板'

  }

  return pageTitles[currentPage.value] || '指标中心'

})



// 加载状态

const loading = ref({

  hosts: false,

  containers: false,

  history: false,

  metrics: false

})



// 错误信息

const error = ref({

  hosts: '',

  containers: '',

  history: '',

  metrics: ''

})



// 根据路由设置当前页面

watch(() => route.path, (newPath) => {

  const pathSegments = newPath.split('/')

  if (pathSegments.length > 2 && pathSegments[1] === 'metrics-center') {

    currentPage.value = pathSegments[2]

  }

}, { immediate: true })



// 搜索表单

const searchForm = ref({

  keyword: ''

})



// 分页相关变量

const pageSize = ref(10)

const hostCurrentPage = ref(1)

const hostTotal = ref(2)



// 右滑框

const drawerVisible = ref(false)

const selectedHost = ref(null)



// 历史时间范围

const historyTimeRange = ref('1h')



// 主机数据库

const hosts = ref([])



// 图表数据 - 存储CPU、内存、网络等历史数据
const cpuChartData = ref([])
const memChartData = ref([])
const netInChartData = ref([])

// 历史数据库
const cpuHistoryData = ref([])

const memHistoryData = ref([])

const netInHistoryData = ref([])

const netOutHistoryData = ref([])

const diskHistoryData = ref([])

const loadHistoryData = ref([])



// 加载主机数据库

const loadHosts = async () => {

  loading.value.hosts = true

  error.value.hosts = ''

  try {

 // 这里应该调用实际的API

 // const response = await api.getNodes()

 // hosts.value = response.data

 // hostTotal.value = response.data.length

    

 // 使用模拟数据库作为 fallback

    hosts.value = [

      {

        id: '1',

        name: 'vm-CentOS7.6-127.0.0.36',

        ip: '127.0.0.36',

        os: 'CentOS 7.6',

        cpuUsage: 20.8,

        memUsage: 60.5,

        load: 2.19

      },

      {

        id: '2',

        name: 'vm-CentOS7.6-127.0.0.37',

        ip: '127.0.0.37',

        os: 'CentOS 7.6',

        cpuUsage: 5.4,

        memUsage: 80.2,

        load: 2.3

      }

    ]

    hostTotal.value = 2

  } catch (err) {

 // console.error('加载主机数据失败:', err)

    error.value.hosts = '加载主机数据库失败，请稍后重试'

 // 使用模拟数据库作为 fallback

    hosts.value = [

      {

        id: '1',

        name: 'vm-CentOS7.6-127.0.0.36',

        ip: '127.0.0.36',

        os: 'CentOS 7.6',

        cpuUsage: 20.8,

        memUsage: 60.5,

        load: 2.19

      },

      {

        id: '2',

        name: 'vm-CentOS7.6-127.0.0.37',

        ip: '127.0.0.37',

        os: 'CentOS 7.6',

        cpuUsage: 5.4,

        memUsage: 80.2,

        load: 2.3

      }

    ]

    hostTotal.value = 2

  } finally {

    loading.value.hosts = false

  }

}



// 搜索处理函数

const handleSearch = async () => {

  await loadHosts()

}



// 分页流程处理

const handleCurrentChange = async (page: number) => {

  hostCurrentPage.value = page

  await loadHosts()

}



// 获取进度条颜色

const getProgressColor = (value: number) => {

  if (value > 80) {

    return '#F56C6C'

  } else if (value > 60) {

    return '#E6A23C'

  } else {

    return '#67C23A'

  }

}



// 行点击事件

const handleRowClick = (row: any) => {

  selectedHost.value = row

  drawerVisible.value = true

  }



// 刷新历史数据

const refreshHistory = async () => {

  loading.value.history = true

  error.value.history = ''

  try {

 // 这里应该调用实际的API

 // const response = await api.getMetrics({ timeRange: historyTimeRange.value })

 // 更新历史数据库...

    

 // 使用模拟数据

    cpuHistoryData.value = generateMockData(50, 10)

    memHistoryData.value = generateMockData(30, 50)

    netInHistoryData.value = generateMockData(80, 10)

    netOutHistoryData.value = generateMockData(70, 15)

    diskHistoryData.value = generateMockData(20, 40)

    loadHistoryData.value = generateMockData(40, 30)

  } catch (err) {

 // console.error('刷新历史数据库失败:', err)

    error.value.history = '刷新历史数据库失败，请稍后重试'

  } finally {

    loading.value.history = false

  }

}



// 容器相关数据库



// 容器搜索表单

const containerSearchForm = ref({

  keyword: '',

  namespace: 'all'

})



// 容器分页相关变量

const containerPageSize = ref(10)

const containerCurrentPage = ref(1)

const containerTotal = ref(13)



// 容器右滑框

const containerDrawerVisible = ref(false)

const selectedContainer = ref(null)



// 容器表单

const containerForm = ref({

  selectedContainer: ''

})



// 容器历史时间范围

const containerHistoryTimeRange = ref('1h')



// 容器数据库

const containers = ref([

  {

    id: '1',

    podName: 'alertmanager-668557f55b-7glqg',

    ip: '10.244.2.166',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'kube-system',

    restartCount: 0,

    status: '运行中',

    runTime: '724h23m59s',

    containers: [

      { id: '1-1', name: 'alertmanager' },

      { id: '1-2', name: 'config-reloader' }

    ]

  },

  {

    id: '2',

    podName: 'calico-kube-controllers-7579554b48-2h5cf',

    ip: '10.244.2.165',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'kube-system',

    restartCount: 0,

    status: '运行中',

    runTime: '724h24m14s',

    containers: [

      { id: '2-1', name: 'calico-kube-controllers' }

    ]

  },

  {

    id: '3',

    podName: 'deepflow-server-7566f66859-2v52c',

    ip: '10.244.2.167',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'deepflow',

    restartCount: 0,

    status: '运行中',

    runTime: '472h24m14s',

    containers: [

      { id: '3-1', name: 'deepflow-server' },

      { id: '3-2', name: 'init-container' }

    ]

  },

  {

    id: '4',

    podName: 'deepflow-server-7566f66859-5v78c',

    ip: '10.244.2.168',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'deepflow',

    restartCount: 0,

    status: '运行中',

    runTime: '472h24m14s',

    containers: [

      { id: '4-1', name: 'deepflow-server' },

      { id: '4-2', name: 'init-container' }

    ]

  },

  {

    id: '5',

    podName: 'deepflow-talker-7566f66859-2v52c',

    ip: '10.244.2.169',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'deepflow',

    restartCount: 0,

    status: '运行中',

    runTime: '472h24m14s',

    containers: [

      { id: '5-1', name: 'deepflow-talker' }

    ]

  },

  {

    id: '6',

    podName: 'deepflow-statistics-7566f66859-2v52c',

    ip: '10.244.2.170',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'deepflow',

    restartCount: 0,

    status: '运行中',

    runTime: '472h24m14s',

    containers: [

      { id: '6-1', name: 'deepflow-statistics' }

    ]

  },

  {

    id: '7',

    podName: 'hw-analyzer-w770-7566f66859-2v52c',

    ip: '10.244.2.171',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'app',

    restartCount: 0,

    status: '运行中',

    runTime: '472h24m14s',

    containers: [

      { id: '7-1', name: 'hw-analyzer' }

    ]

  },

  {

    id: '8',

    podName: 'kube-proxy-7566f66859-2v52c',

    ip: '10.244.2.172',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'kube-system',

    restartCount: 0,

    status: '运行中',

    runTime: '724h24m14s',

    containers: [

      { id: '8-1', name: 'kube-proxy' }

    ]

  },

  {

    id: '9',

    podName: 'kube-state-metrics-7566f66859-2v52c',

    ip: '10.244.2.173',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'kube-system',

    restartCount: 0,

    status: '运行中',

    runTime: '724h24m14s',

    containers: [

      { id: '9-1', name: 'kube-state-metrics' }

    ]

  },

  {

    id: '10',

    podName: 'edge-service-ms-#67',

    ip: '10.244.2.174',

    node: 'cn-beijing72.127.0.0.36',

    namespace: 'app',

    restartCount: 0,

    status: '运行中',

    runTime: '472h24m14s',

    containers: [

      { id: '10-1', name: 'edge-service' },

      { id: '10-2', name: 'sidecar' }

    ]

  }

])



// 容器历史图表数据

const containerCpuHistoryData = ref([])

const containerMemHistoryData = ref([])

const containerNetInHistoryData = ref([])

const containerNetOutHistoryData = ref([])



// 加载容器数据库

const loadContainers = async () => {

  loading.value.containers = true

  error.value.containers = ''

  try {

 // 这里应该调用实际的API

 // const response = await api.getContainers()

 // containers.value = response.data

 // containerTotal.value = response.data.length

    

 // 使用模拟数据库作为 fallback

    containers.value = [

      {

        id: '1',

        podName: 'alertmanager-668557f55b-7glqg',

        ip: '10.244.2.166',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'kube-system',

        restartCount: 0,

        status: '运行中',

        runTime: '724h23m59s',

        containers: [

          { id: '1-1', name: 'alertmanager' },

          { id: '1-2', name: 'config-reloader' }

        ]

      },

      {

        id: '2',

        podName: 'calico-kube-controllers-7579554b48-2h5cf',

        ip: '10.244.2.165',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'kube-system',

        restartCount: 0,

        status: '运行中',

        runTime: '724h24m14s',

        containers: [

          { id: '2-1', name: 'calico-kube-controllers' }

        ]

      },

      {

        id: '3',

        podName: 'deepflow-server-7566f66859-2v52c',

        ip: '10.244.2.167',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'deepflow',

        restartCount: 0,

        status: '运行中',

        runTime: '472h24m14s',

        containers: [

          { id: '3-1', name: 'deepflow-server' },

          { id: '3-2', name: 'init-container' }

        ]

      },

      {

        id: '4',

        podName: 'deepflow-server-7566f66859-5v78c',

        ip: '10.244.2.168',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'deepflow',

        restartCount: 0,

        status: '运行中',

        runTime: '472h24m14s',

        containers: [

          { id: '4-1', name: 'deepflow-server' },

          { id: '4-2', name: 'init-container' }

        ]

      },

      {

        id: '5',

        podName: 'deepflow-talker-7566f66859-2v52c',

        ip: '10.244.2.169',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'deepflow',

        restartCount: 0,

        status: '运行中',

        runTime: '472h24m14s',

        containers: [

          { id: '5-1', name: 'deepflow-talker' }

        ]

      },

      {

        id: '6',

        podName: 'deepflow-statistics-7566f66859-2v52c',

        ip: '10.244.2.170',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'deepflow',

        restartCount: 0,

        status: '运行中',

        runTime: '472h24m14s',

        containers: [

          { id: '6-1', name: 'deepflow-statistics' }

        ]

      },

      {

        id: '7',

        podName: 'hw-analyzer-w770-7566f66859-2v52c',

        ip: '10.244.2.171',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'app',

        restartCount: 0,

        status: '运行中',

        runTime: '472h24m14s',

        containers: [

          { id: '7-1', name: 'hw-analyzer' }

        ]

      },

      {

        id: '8',

        podName: 'kube-proxy-7566f66859-2v52c',

        ip: '10.244.2.172',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'kube-system',

        restartCount: 0,

        status: '运行中',

        runTime: '724h24m14s',

        containers: [

          { id: '8-1', name: 'kube-proxy' }

        ]

      },

      {

        id: '9',

        podName: 'kube-state-metrics-7566f66859-2v52c',

        ip: '10.244.2.173',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'kube-system',

        restartCount: 0,

        status: '运行中',

        runTime: '724h24m14s',

        containers: [

          { id: '9-1', name: 'kube-state-metrics' }

        ]

      },

      {

        id: '10',

        podName: 'edge-service-ms-#67',

        ip: '10.244.2.174',

        node: 'cn-beijing72.127.0.0.36',

        namespace: 'app',

        restartCount: 0,

        status: '运行中',

        runTime: '472h24m14s',

        containers: [

          { id: '10-1', name: 'edge-service' }

        ]

      }

    ]

    containerTotal.value = 13

  } catch (err) {

 // console.error('获取容器数据失败:', err)

    error.value.containers = '加载容器数据库失败，请稍后重试'

  } finally {

    loading.value.containers = false

  }

}



// 容器搜索处理函数

const handleContainerSearch = async () => {

  await loadContainers()

}



// 容器分页处理函数

const handleContainerCurrentChange = async (page: number) => {

  containerCurrentPage.value = page

  await loadContainers()

}



// 容器行点击事件

const handleContainerRowClick = (row: any) => {

  selectedContainer.value = row

  containerForm.value.selectedContainer = row.containers[0].id

  containerDrawerVisible.value = true

  }



// 刷新容器历史数据库

const refreshContainerHistory = async () => {

  loading.value.history = true

  error.value.history = ''

  try {

 // 这里应该调用实际的API

 // const response = await api.getMetrics({ timeRange: containerHistoryTimeRange.value })

 // 更新历史数据库...

    

 // 使用模拟数据

    containerCpuHistoryData.value = generateMockData(50, 10)

    containerMemHistoryData.value = generateMockData(30, 50)

    containerNetInHistoryData.value = generateMockData(80, 10)

    containerNetOutHistoryData.value = generateMockData(70, 15)

  } catch (err) {

 // console.error('刷新容器历史数据库失败:', err)

    error.value.history = '刷新容器历史数据库失败，请稍后重试'

  } finally {

    loading.value.history = false

  }

}



// 视图模块和组件相关变量



// 搜索快照管理

const metricsTimeRange = ref('5m')



// 自动刷新

const autoRefresh = ref(false)



// 数据库表A折叠面板

const tableACollapsed = ref(false)



// 数据库表B折叠面板

const tableBCollapsed = ref(false)



// 数据库表A表单

const tableAForm = ref({

  application: '',

  interval: 'minute'

})



// 数据库表B表单

const tableBForm = ref({

  application: '',

  logType: 'client'

})



// 数据库表A搜索条件

const tableASearch = ref('')

const tableAGroupBy = ref('none')

const tableASubGroupBy = ref('none')



// 数据库表B搜索条件

const tableBSearch = ref('')

const tableBGroupBy = ref('none')

const tableBSubGroupBy = ref('none')



// 数据库表A指标

const tableAMetrics = ref([

  {

    name: 'request',

    aggregation: 'avg',

    enabled: true

  },

  {

    name: 'response',

    aggregation: 'avg',

    enabled: true

  }

])



// 数据库表B指标

const tableBMetrics = ref([

  {

    name: 'response_time',

    aggregation: 'avg',

    enabled: true

  }

])



// 刷新指标数据

const refreshMetrics = () => {

 // 使用模拟数据

}



// 应用数据库表A配置

const applyTableA = () => {

  }



// 清除数据库表A配置

const clearTableA = () => {

  tableAForm.value = {

    application: '',

    interval: 'minute'

  }

  tableASearch.value = ''

  tableAGroupBy.value = 'none'

  tableASubGroupBy.value = 'none'

  }



// 应用数据库表B配置

const applyTableB = () => {

  }



// 清除数据库表B配置

const clearTableB = () => {

  tableBForm.value = {

    application: '',

    logType: 'client'

  }

  tableBSearch.value = ''

  tableBGroupBy.value = 'none'

  tableBSubGroupBy.value = 'none'

  }



// 添加指标

const addMetric = (table: string) => {

  if (table === 'A') {

    tableAMetrics.value.push({

      name: 'request',

      aggregation: 'avg',

      enabled: true

    })

  } else if (table === 'B') {

    tableBMetrics.value.push({

      name: 'response_time',

      aggregation: 'avg',

      enabled: true

    })

  }

  }



// 编辑指标

const editMetric = (index: number, table: string) => {

  }



// 移除指标

const removeMetric = (index: number, table: string) => {

  if (table === 'A') {

    tableAMetrics.value.splice(index, 1)

  } else if (table === 'B') {

    tableBMetrics.value.splice(index, 1)

  }

  }



// 添加查询

const addQuery = () => {

 // 模拟添加查询

}



// 视图模块和组件相关变量



// 摘要表单

const summaryForm = ref({

  collection: 'network',

  table: 'tableA'

})



// 摘要标签页

const summaryActiveTab = ref('metrics')



// Metrics 数据库

const metricsData = ref([

  {

    name: 'name',

    unit: '字节',

    type: 'counter',

    displayName: '字节',

    category: 'L3 Throughput',

    description: '发送的字节数总和，包含 Ethernet 头的所有内容',

  },

  {

    name: 'byte_tx',

    unit: '字节',

    type: 'counter',

    displayName: '发送字节',

    category: 'L3 Throughput',

    description: '发送的字节数总和，包含 Ethernet 头的所有内容',

  },

  {

    name: 'byte_rx',

    unit: '字节',

    type: 'counter',

    displayName: '接收字节',

    category: 'L3 Throughput',

    description: '接收的字节数总和，包含 Ethernet 头的所有内容',

  },

  {

    name: 'packet_tx',

    unit: '个',

    type: 'counter',

    displayName: '发送包',

    category: 'L3 Throughput',

    description: '发送的总数据包数',

  },

  {

    name: 'packet_rx',

    unit: '个',

    type: 'counter',

    displayName: '接收包数',

    category: 'L3 Throughput',

    description: '接收的总数据库包',

  },

  {

    name: 'l3_byte_tx',

    unit: '字节',

    type: 'counter',

    displayName: '发送网络层字节',

    category: 'L3 Throughput',

    description: '发送的字节数总和，包含IP 头但无网络层字节',

  },

  {

    name: 'l3_byte_rx',

    unit: '字节',

    type: 'counter',

    displayName: '接收字节数总和',

    category: 'L3 Throughput',

    description: '接收的字节数总和，包含IP 头但无网络层字节',

  },

  {

    name: 'bps_tx',

    unit: '字节',

    type: 'gauge',

    displayName: '平均发送速率',

    category: 'L3 Throughput',

    description: '平均发送速率，单位：字节/秒（统计周期内），等于tx_byte / 统计周期（秒）',

  },

  {

    name: 'bps_rx',

    unit: '字节',

    type: 'gauge',

    displayName: '平均接收速率',

    category: 'L3 Throughput',

    description: '平均接收速率，单位：字节/秒（统计周期内），等于rx_byte / 统计周期（秒）',

  },

  {

    name: 'new_flow',

    unit: '个',

    type: 'counter',

    displayName: '新增流组',

    category: 'L4 Throughput',

    description: '在这个统计周期内的新增服务数量，重建流不计入',

  }

])



// Metrics 分页相关变量

const metricsPageSize = ref(10)

const metricsCurrentPage = ref(1)

const metricsTotal = ref(99)



// Tag 数据库

const tagData = ref([

  {

    name: 'src_ip',

    description: '源IP 地址',

    type: 'string',

    example: '192.168.1.1'

  },

  {

    name: 'dst_ip',

    description: '目标 IP 地址',

    type: 'string',

    example: '192.168.1.2'

  },

  {

    name: 'src_port',

    description: '源端口',

    type: 'integer',

    example: '8080'

  },

  {

    name: 'dst_port',

    description: '目标端口',

    type: 'integer',

    example: '80'

  },

  {

    name: 'protocol',

    description: '协议类型',

    type: 'string',

    example: 'TCP'

  },

  {

    name: 'application',

    description: '应用名称',

    type: 'string',

    example: 'nginx'

  },

  {

    name: 'host',

    description: '主机名称',

    type: 'string',

    example: 'server-01'

  },

  {

    name: 'region',

    description: '区域',

    type: 'string',

    example: 'cn-beijing'

  },

  {

    name: 'environment',

    description: '环境',

    type: 'string',

    example: 'production'

  },

  {

    name: 'service',

    description: '服务名称',

    type: 'string',

    example: 'api-gateway'

  }

])



// Tag 分页相关变量

const tagPageSize = ref(10)

const tagCurrentPage = ref(1)

const tagTotal = ref(50)



// 刷新摘要数据

const refreshSummary = () => {

 // 使用模拟数据

}



// Metrics 分页变化

const handleMetricsPageChange = (page: number) => {

  metricsCurrentPage.value = page

  }



// Tag 分页变化

const handleTagPageChange = (page: number) => {

  tagCurrentPage.value = page

  }



// 网络设备相关变量



// 模板表单

const templateForm = ref({

  table: 'all',

  service: 'all',

  search: ''

})



// 模板模拟数据

const templates = ref([

  {

    id: 1,

    name: '默认模板',

    team: '--',

    database: 'flow_metrics',

    metricsType: 'network',

    creator: 'admin',

    lastUsed: '--',

    isDefault: true,

    metrics: [

      {

        name: 'byte_tx',

        alias: '发送速率',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '字节/秒',

        threshold: '--',

        enabled: true

      },

      {

        name: 'byte_rx',

        alias: '接收速率',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '字节/秒',

        threshold: '--',

        enabled: true

      },

      {

        name: 'packet_tx',

        alias: '发送吞吐率',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '包/秒',

        threshold: '--',

        enabled: true

      },

      {

        name: 'packet_rx',

        alias: '接收吞吐率',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '包/秒',

        threshold: '--',

        enabled: true

      },

      {

        name: 'l4_byte_tx',

        alias: '发送传输层字节',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '字节/秒',

        threshold: '--',

        enabled: true

      },

      {

        name: 'l4_byte_rx',

        alias: '接收传输层字节',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '字节/秒',

        threshold: '--',

        enabled: true

      }

    ]

  },

  {

    id: 2,

    name: '流量盘点',

    team: 'Default团队',

    database: 'flow_metrics',

    metricsType: 'network',

    creator: 'admin',

    lastUsed: '2024-08-16 16:22:49',

    isDefault: false,

    metrics: [

      {

        name: 'byte_tx',

        alias: '发送速率',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '字节/秒',

        threshold: '--',

        enabled: true

      },

      {

        name: 'byte_rx',

        alias: '接收速率',

        aggregation: 'Avg',

        function: 'PerSecond',

        unit: '字节/秒',

        threshold: '--',

        enabled: true

      }

    ]

  },

  {

    id: 3,

    name: '网络延迟异常分析',

    team: 'Default团队',

    database: 'flow_metrics',

    metricsType: 'network',

    creator: 'liqian',

    lastUsed: '2024-08-16 16:22:49',

    isDefault: false,

    metrics: []

  },

  {

    id: 4,

    name: '网络延迟分析',

    team: 'Default团队',

    database: 'flow_metrics',

    metricsType: 'network',

    creator: 'admin',

    lastUsed: '2024-08-16 16:48:46',

    isDefault: false,

    metrics: []

  },

  {

    id: 5,

    name: '网络异常分析',

    team: 'Default团队',

    database: 'flow_metrics',

    metricsType: 'network',

    creator: 'admin',

    lastUsed: '2024-08-16 16:48:16',

    isDefault: false,

    metrics: []

  },

  {

    id: 6,

    name: 'Test',

    team: 'Default团队',

    database: 'flow_metrics',

    metricsType: 'network',

    creator: 'admin',

    lastUsed: '2024-08-16 16:48:16',

    isDefault: false,

    metrics: []

  }

])



// 模板分页

const templatePageSize = ref(10)

const templateCurrentPage = ref(1)

const templateTotal = ref(26)



// 模板对话框

const templateDialogVisible = ref(false)

const isEditTemplate = ref(false)



// 新建模板表单

const newTemplateForm = ref({

  name: '',

  team: 'default',

  database: 'application',

  service: 'traffic',

  metrics: [

    {

      name: 'request',

      aggregation: 'avg',

      function: 'per_second',

      alias: '',

      unit: '',

      threshold: '',

      enabled: true

    },

    {

      name: 'response',

      aggregation: 'avg',

      function: 'per_second',

      alias: '',

      unit: '',

      threshold: '',

      enabled: true

    },

    {

      name: 'avg_latency',

      aggregation: 'avg',

      function: 'per_second',

      alias: '',

      unit: '',

      threshold: '',

      enabled: true

    },

    {

      name: 'anomaly',

      aggregation: 'avg',

      function: 'per_second',

      alias: '',

      unit: '',

      threshold: '10',

      enabled: true

    }

  ]

})



// 打开新建模板窗口
const openCreateTemplateDialog = () => {

  isEditTemplate.value = false

  newTemplateForm.value = {

    name: '',

    team: 'default',

    database: 'application',

    service: 'traffic',

    metrics: [

      {

        name: 'request',

        aggregation: 'avg',

        function: 'per_second',

        alias: '',

        unit: '',

        threshold: '',

        enabled: true

      }

    ]

  }

  templateDialogVisible.value = true

}



// 搜索模板

const searchTemplates = () => {

 // 模拟搜索

}



// 编辑模板处理函数

const editTemplate = (template: any) => {

  isEditTemplate.value = true

  newTemplateForm.value = {

    name: template.name,

    team: template.team,

    database: template.database,

    service: template.service || 'traffic',

    metrics: template.metrics.map((metric: any) => ({

      name: metric.name,

      aggregation: metric.aggregation,

      function: metric.function,

      alias: metric.alias,

      unit: metric.unit,

      threshold: metric.threshold,

      enabled: metric.enabled

    }))

  }

  templateDialogVisible.value = true

  }



// 删除模板处理函数

const deleteTemplate = (template: any) => {

 // 模拟删除

}



// 保存模板

const saveTemplate = () => {

  templateDialogVisible.value = false

 // 模拟保存

}



// 添加模板指标

const addTemplateMetric = () => {

  newTemplateForm.value.metrics.push({

    name: 'request',

    aggregation: 'avg',

    function: 'per_second',

    alias: '',

    unit: '',

    threshold: '',

    enabled: true

  })

}



// 移除模板指标

const removeTemplateMetric = (index: number) => {

  newTemplateForm.value.metrics.splice(index, 1)

}



// 初始化网络流量监控数据

onMounted(() => {
  cpuChartData.value = generateMockData(150, 50, 30)
  memChartData.value = generateMockData(120, 30, 30)
  netInChartData.value = generateMockData(200, 20, 30)
  cpuHistoryData.value = generateMockData(50, 10, 30)
  memHistoryData.value = generateMockData(30, 50, 30)
  netInHistoryData.value = generateMockData(80, 10, 30)
  netOutHistoryData.value = generateMockData(70, 15, 30)
  diskHistoryData.value = generateMockData(20, 40, 30)
  loadHistoryData.value = generateMockData(40, 30, 30)
  containerCpuHistoryData.value = generateMockData(50, 10, 30)
  containerMemHistoryData.value = generateMockData(30, 50, 30)
  containerNetInHistoryData.value = generateMockData(80, 10, 30)
  containerNetOutHistoryData.value = generateMockData(70, 15, 30)

  loadHosts()

  loadContainers()

})



// 模板分页变化

const handleTemplatePageChange = (page: number) => {

  templateCurrentPage.value = page

  }



</script>



<style scoped>

.metrics-center {

  padding: 20px;

}



.card-header {

  display: flex;

  justify-content: space-between;

  align-items: center;

}



.search-filter {

  margin-bottom: 20px;

}



.host-list {

  background-color: white;

  border-radius: 4px;

  padding: 15px;

}



.progress-container {

  position: relative;

  padding-right: 60px;

}



.progress-text {

  position: absolute;

  right: 0;

  top: 50%;

  transform: translateY(-50%);

  font-size: 12px;

  color: #606266;

}



.pagination {

  margin-top: 20px;

  display: flex;

  justify-content: space-between;

  align-items: center;

}



.pagination-info {

  color: #909399;

  font-size: 14px;

}



.container-content,

.view-content,

.summary-content,

.template-content {

  padding: 20px;

  text-align: center;

  color: #909399;

}



/* 右滑框样式 */

.host-detail {

  padding: 20px;

}



.detail-header {

  margin-bottom: 20px;

}



.time-range-select {

  display: flex;

  align-items: center;

  margin-bottom: 20px;

}



.history-charts {

  margin-top: 20px;

}



.chart-header h3 {

  margin: 0 0 15px 0;

  font-size: 16px;

  font-weight: bold;

}



.mock-chart {

  background-color: #f5f7fa;

  padding: 20px;

  border-radius: 4px;

  height: 200px;

  display: flex;

  flex-direction: column;

}



.chart-bars {

  flex: 1;

  display: flex;

  align-items: flex-end;

  gap: 3px;

  margin-bottom: 10px;

}



.chart-bar {

  flex: 1;

  border-radius: 4px 4px 0 0;

  min-height: 10px;

}



.cpu-bar {

  background-color: #409eff;

}



.mem-bar {

  background-color: #67c23a;

}



.net-in-bar {

  background-color: #e6a23c;

}



.net-out-bar {

  background-color: #f56c6c;

}



.disk-bar {

  background-color: #909399;

}



.load-bar {

  background-color: #c0c4cc;

}



.chart-x-axis {

  display: flex;

  justify-content: space-between;

  font-size: 12px;

  color: #909399;

}



/* 数据库视图相关样式 */



.metrics-view-content {

  padding: 20px;

}



.metrics-view-header {

  margin-bottom: 20px;

  padding: 15px;

  background-color: #f5f7fa;

  border-radius: 4px;

}



.time-range-selector {

  display: flex;

  align-items: center;

}



.metrics-config {

  margin-bottom: 30px;

}



.metrics-table {

  margin-bottom: 20px;

  border: 1px solid #ebeef5;

  border-radius: 4px;

  background-color: white;

}



.table-header {

  border-bottom: 1px solid #ebeef5;

}



.table-controls {

  padding: 15px;

}



.search-condition {

  margin-top: 15px;

  display: flex;

  align-items: center;

}



.metrics-list {

  padding: 15px;

}



.metric-item {

  margin-bottom: 10px;

  padding: 10px;

  background-color: #f9f9f9;

  border-radius: 4px;

}



.add-metric {

  margin-top: 15px;

  text-align: right;

}



.add-query {

  margin-top: 20px;

  text-align: right;

}



.metrics-charts {

  margin-top: 30px;

}



/* 指标摘要页面样式 */



.metrics-summary-content {

  padding: 20px;

}



.summary-header {

  margin-bottom: 20px;

  padding: 15px;

  background-color: #f5f7fa;

  border-radius: 4px;

}



.metrics-collection {

  display: flex;

  align-items: center;

}



.summary-tabs {

  margin-top: 20px;

}



.metrics-table,

.tag-table {

  background-color: white;

  border-radius: 4px;

  padding: 15px;

}



/* 指标模板页面样式 */



.metrics-template-content {

  padding: 20px;

}



.template-header {

  margin-bottom: 20px;

  display: flex;

  justify-content: space-between;

  align-items: center;

}



.template-filters {

  display: flex;

  align-items: center;

}



.template-list {

  background-color: white;

  border-radius: 4px;

  padding: 15px;

}



.dialog-footer {

  display: flex;

  justify-content: flex-end;

  gap: 10px;

}



</style>
