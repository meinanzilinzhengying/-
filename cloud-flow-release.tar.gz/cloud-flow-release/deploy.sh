#!/bin/bash
# Cloud Flow 一键部署脚本

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Cloud Flow - 云内流量监测系统${NC}"
echo -e "${GREEN}  一键部署脚本${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# 检查 root 权限
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}错误: 请使用 root 权限运行此脚本${NC}"
    exit 1
fi

# 检查 Docker
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}Docker 未安装，正在安装...${NC}"
    yum install -y docker || apt-get install -y docker.io
    systemctl enable docker
    systemctl start docker
fi

# 检查 Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}Docker Compose 未安装，正在安装...${NC}"
    curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
fi

# 检查 Nginx
if ! command -v nginx &> /dev/null; then
    echo -e "${YELLOW}Nginx 未安装，正在安装...${NC}"
    yum install -y nginx || apt-get install -y nginx
fi

# 配置 Docker 镜像加速器
echo -e "${YELLOW}配置 Docker 镜像加速器...${NC}"
mkdir -p /etc/docker
cat > /etc/docker/daemon.json << 'EOF'
{
  "registry-mirrors": [
    "https://docker.1ms.run",
    "https://docker.xuanyuan.me"
  ]
}
EOF
systemctl daemon-reload
systemctl restart docker

# 配置环境变量
echo -e "${YELLOW}检查环境变量配置...${NC}"
if [ ! -f .env ]; then
    echo -e "${RED}错误: .env 文件不存在${NC}"
    echo -e "${YELLOW}请复制 .env.example 为 .env 并修改配置${NC}"
    echo "  cp .env.example .env"
    echo "  vi .env"
    exit 1
fi

# 启动基础设施
echo -e "${YELLOW}启动基础设施服务...${NC}"
docker-compose up -d tidb redis prometheus grafana alertmanager node-exporter

# 等待服务启动
echo -e "${YELLOW}等待服务启动 (30秒)...${NC}"
sleep 30

# 检查服务状态
echo -e "${YELLOW}检查服务状态...${NC}"
docker-compose ps

# 部署前端
echo -e "${YELLOW}部署前端...${NC}"
cp nginx-cloud-flow.conf /etc/nginx/conf.d/

# 创建前端目录
mkdir -p /usr/share/nginx/html
rm -rf /usr/share/nginx/html/*
cp -r frontend-dist/* /usr/share/nginx/html/

# 启动 Nginx
nginx -t && nginx

# 开放防火墙端口
echo -e "${YELLOW}配置防火墙...${NC}"
if command -v firewall-cmd &> /dev/null; then
    firewall-cmd --permanent --add-port=8888/tcp 2>/dev/null || true
    firewall-cmd --permanent --add-port=3001/tcp 2>/dev/null || true
    firewall-cmd --permanent --add-port=9091/tcp 2>/dev/null || true
    firewall-cmd --reload 2>/dev/null || true
fi

# 获取服务器 IP
SERVER_IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  部署完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "访问地址:"
echo -e "  ${GREEN}前端界面:${NC} http://${SERVER_IP}:8888"
echo -e "  ${GREEN}Grafana:${NC}  http://${SERVER_IP}:3001 (admin/admin)"
echo -e "  ${GREEN}Prometheus:${NC} http://${SERVER_IP}:9091"
echo ""
echo -e "${YELLOW}注意: 后端 API 服务 (Center) 需要单独编译部署${NC}"
echo -e "${YELLOW}详见 README-部署说明.md${NC}"
echo ""
