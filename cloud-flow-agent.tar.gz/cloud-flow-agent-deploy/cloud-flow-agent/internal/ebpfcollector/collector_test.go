package ebpfcollector

import (
	"testing"

	"cloud-flow-agent/internal/ebpfcollector/bpf"
)

func TestEventToMetric(t *testing.T) {
	event := &bpf.FlowEvent{
		SrcIP:     (10 << 24) | (0 << 16) | (0 << 8) | 1,  // 10.0.0.1
		DstIP:     (10 << 24) | (0 << 16) | (0 << 8) | 2,  // 10.0.0.2
		SrcPort:   12345,
		DstPort:   80,
		Protocol:  6,  // TCP
		EventType: 2,  // UPDATE
		Bytes:     1024,
		Packets:   10,
		Timestamp: 1700000000000000000,  // nanoseconds
		CpuID:     0,
	}

	c := &Collector{}
	metric := c.eventToMetric(event)

	if metric.SrcIp != "10.0.0.1" {
		t.Errorf("SrcIp = %q, want %q", metric.SrcIp, "10.0.0.1")
	}
	if metric.DstIp != "10.0.0.2" {
		t.Errorf("DstIp = %q, want %q", metric.DstIp, "10.0.0.2")
	}
	if metric.Protocol != "tcp" {
		t.Errorf("Protocol = %q, want %q", metric.Protocol, "tcp")
	}
	if metric.Bytes != 1024 {
		t.Errorf("Bytes = %d, want %d", metric.Bytes, 1024)
	}
}
