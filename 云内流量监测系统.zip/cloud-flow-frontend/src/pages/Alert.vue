<template>

  <div class="alert">

 <!-- 告警策略 -->

    <el-card v-if="currentModule === 'strategy'" class="mb-4">

      <template #header>

        <div class="card-header">

          <h2>告警策略</h2>

          <div class="header-actions">

            <el-button type="primary" @click="createAlertStrategy">新建告警策略</el-button>

          </div>

        </div>

      </template>

      

 <!-- 最近5分钟 -->

      <div class="search-filter mb-4">

        <el-form :inline="true" :model="searchForm" class="demo-form-inline">

          <el-form-item label="按名称搜索">

            <el-input v-model="searchForm.keyword" placeholder="按名称搜索" style="width: 300px;" />

          </el-form-item>

          <el-form-item>

            <el-button type="primary" @click="handleSearch">搜索</el-button>

          </el-form-item>

        </el-form>

      </div>

      

 <!-- 告警策略列表 -->

      <el-table :data="alertStrategies" style="width: 100%">

        <el-table-column prop="name" label="事件名称" min-width="150" />

        <el-table-column prop="team" label="团队" width="120" />

        <el-table-column prop="monitor" label="监控" width="100" />

        <el-table-column prop="rule" label="告警规则" min-width="200" />

        <el-table-column prop="tags" label="标签" min-width="100">

          <template #default="scope">

            <el-tag v-for="tag in scope.row.tags" :key="tag" size="small" style="margin-right: 5px;">{{ tag }}</el-tag>

          </template>

        </el-table-column>

        <el-table-column prop="level" label="策略等级" width="100" />

        <el-table-column prop="alertCount" label="告警数量" width="100">

          <template #default="scope">

            <el-button  @click="viewAlertEvents(scope.row)">{{ scope.row.alertCount }}</el-button>

          </template>

        </el-table-column>

        <el-table-column prop="createTime" label="创建时间" width="180" sortable />

        <el-table-column prop="status" label="启用/禁用" width="100">

          <template #default="scope">

            <el-switch v-model="scope.row.status" @change="toggleStatus(scope.row)" />

          </template>

        </el-table-column>

        <el-table-column prop="endpoint" label="推送端点" width="100" />

        <el-table-column label="操作" width="100" fixed="right">

          <template #default="scope">

            <el-button size="small" @click="editAlertStrategy(scope.row)">

              <el-icon><Edit /></el-icon>

            </el-button>

            <el-button size="small" type="danger" @click="deleteAlertStrategy(scope.row)">

              <el-icon><Delete /></el-icon>

            </el-button>

          </template>

        </el-table-column>

      </el-table>

      

 <!-- 数据库表 -->

      <div class="pagination mt-4">

        <div class="pagination-info">

          共 {{ alertStrategyTotal }} 条

        </div>

        <el-pagination

          background

          layout="prev, pager, next, jumper"

          :total="alertStrategyTotal"

          :page-size="pagination.strategy.pageSize"

          :current-page="pagination.strategy.currentPage"

          @current-change="(page) => handleCurrentChange(page, 'strategy')"

        />

      </div>

    </el-card>

    

 <!-- 推送端点-->

    <el-card v-if="currentModule === 'endpoint'" class="mb-4">

      <template #header>

        <div class="card-header">

          <h2>推送端点</h2>

        </div>

      </template>

      

 <!-- 标签页-->

      <el-tabs v-model="activeEndpointTab">

 <!-- Email 推送标签页 -->

        <el-tab-pane label="Email推送" name="email">

 <!-- 操作按钮 -->

          <div class="action-buttons mb-4">

            <el-button type="primary" @click="dialogVisible.email = true">新建连接Email推送</el-button>

          </div>

          

 <!-- 最近5分钟 -->

          <div class="search-filter mb-4">

            <el-form :inline="true" :model="searchForm" class="demo-form-inline">

              <el-form-item label="Email推送列表（最多8项）">

                <el-input v-model="searchForm.keyword" placeholder="搜索关键词" style="width: 300px;" />

              </el-form-item>

              <el-form-item>

                <el-button type="primary" @click="handleSearch">搜索</el-button>

              </el-form-item>

            </el-form>

          </div>

          

 <!-- Email 推送列表-->

          <el-table :data="emailEndpoints" style="width: 100%">

            <el-table-column prop="name" label="名称" min-width="150" sortable />

            <el-table-column prop="team" label="团队" width="120" />

            <el-table-column prop="email" label="推送邮箱" min-width="200" />

            <el-table-column prop="alertType" label="通知类型" width="150" />

            <el-table-column prop="alertCount" label="关联告警策略" width="120">

              <template #default="scope">

                <el-button  @click="viewAlertStrategies(scope.row)">{{ scope.row.alertCount }}</el-button>

              </template>

            </el-table-column>

            <el-table-column prop="sourceAccount" label="来源账号" width="150" />

            <el-table-column prop="updateTime" label="更新时间" width="180" sortable />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" @click="editEmailEndpoint(scope.row)">

                  <el-icon><Edit /></el-icon>

                </el-button>

                <el-button size="small" type="danger" @click="deleteEmailEndpoint(scope.row)">

                  <el-icon><Delete /></el-icon>

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ emailEndpointTotal }} 条

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="emailEndpointTotal"

              :page-size="pagination.endpoint.pageSize"

              :current-page="pagination.endpoint.currentPage"

              @current-change="(page) => handleCurrentChange(page, 'endpoint')"

            />

          </div>

        </el-tab-pane>

        

 <!-- HTTP 推送标签页 -->

        <el-tab-pane label="HTTP推送" name="http">

 <!-- 操作按钮 -->

          <div class="action-buttons mb-4">

            <el-button type="primary" @click="dialogVisible.http = true">新建连接HTTP推送</el-button>

          </div>

          

 <!-- 最近5分钟 -->

          <div class="search-filter mb-4">

            <el-form :inline="true" :model="searchForm" class="demo-form-inline">

              <el-form-item label="HTTP推送列表（最多10项）">

                <el-input v-model="searchForm.keyword" placeholder="搜索关键词" style="width: 300px;" />

              </el-form-item>

              <el-form-item>

                <el-button type="primary" @click="handleSearch">搜索</el-button>

              </el-form-item>

            </el-form>

          </div>

          

 <!-- HTTP 推送列表-->

          <el-table :data="httpEndpoints" style="width: 100%">

            <el-table-column prop="name" label="名称" min-width="150" sortable />

            <el-table-column prop="team" label="团队" width="120" />

            <el-table-column prop="method" label="推送方式" width="120" />

            <el-table-column prop="header" label="Header" width="150" />

            <el-table-column prop="url" label="推送URL" min-width="200" />

            <el-table-column prop="alertType" label="通知类型" width="150" />

            <el-table-column prop="alertCount" label="关联告警策略" width="120">

              <template #default="scope">

                <el-button  @click="viewAlertStrategies(scope.row)">{{ scope.row.alertCount }}</el-button>

              </template>

            </el-table-column>

            <el-table-column prop="sourceAccount" label="来源账号" width="150" />

            <el-table-column prop="updateTime" label="更新时间" width="180" sortable />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" @click="editHttpEndpoint(scope.row)">

                  <el-icon><Edit /></el-icon>

                </el-button>

                <el-button size="small" type="danger" @click="deleteHttpEndpoint(scope.row)">

                  <el-icon><Delete /></el-icon>

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ httpEndpointTotal }} 条

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="httpEndpointTotal"

              :page-size="pagination.endpoint.pageSize"

              :current-page="pagination.endpoint.currentPage"

              @current-change="(page) => handleCurrentChange(page, 'endpoint')"

            />

          </div>

        </el-tab-pane>

        

 <!-- Kafka 推送标签页 -->

        <el-tab-pane label="Kafka推送" name="kafka">

 <!-- 操作按钮 -->

          <div class="action-buttons mb-4">

            <el-button type="primary" @click="dialogVisible.kafka = true">新建连接Kafka推送</el-button>

          </div>

          

 <!-- 最近5分钟 -->

          <div class="search-filter mb-4">

            <el-form :inline="true" :model="searchForm" class="demo-form-inline">

              <el-form-item label="Kafka推送列表（最多10项）">

                <el-input v-model="searchForm.keyword" placeholder="搜索关键词" style="width: 300px;" />

              </el-form-item>

              <el-form-item>

                <el-button type="primary" @click="handleSearch">搜索</el-button>

              </el-form-item>

            </el-form>

          </div>

          

 <!-- Kafka 推送列表 -->

          <el-table :data="kafkaEndpoints" style="width: 100%">

            <el-table-column prop="name" label="名称" min-width="150" sortable />

            <el-table-column prop="team" label="团队" width="120" />

            <el-table-column prop="broker" label="Broker" min-width="200" />

            <el-table-column prop="topic" label="Topic" width="150" />

            <el-table-column prop="sasl" label="SASL" width="120" />

            <el-table-column prop="alertCount" label="关联告警策略" width="120">

              <template #default="scope">

                <el-button  @click="viewAlertStrategies(scope.row)">{{ scope.row.alertCount }}</el-button>

              </template>

            </el-table-column>

            <el-table-column prop="sourceAccount" label="来源账号" width="150" />

            <el-table-column prop="updateTime" label="更新时间" width="180" sortable />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" @click="editKafkaEndpoint(scope.row)">

                  <el-icon><Edit /></el-icon>

                </el-button>

                <el-button size="small" type="danger" @click="deleteKafkaEndpoint(scope.row)">

                  <el-icon><Delete /></el-icon>

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ kafkaEndpointTotal }} 条

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="kafkaEndpointTotal"

              :page-size="pagination.endpoint.pageSize"

              :current-page="pagination.endpoint.currentPage"

              @current-change="(page) => handleCurrentChange(page, 'endpoint')"

            />

          </div>

        </el-tab-pane>

        

 <!-- PCAP 策略标签页-->

        <el-tab-pane label="PCAP策略" name="pcap">

 <!-- 操作按钮 -->

          <div class="action-buttons mb-4">

            <el-button type="primary" @click="dialogVisible.pcap = true">新建连接PCAP策略</el-button>

          </div>

          

 <!-- 最近5分钟 -->

          <div class="search-filter mb-4">

            <el-form :inline="true" :model="searchForm" class="demo-form-inline">

              <el-form-item label="PCAP策略列表（共1项）">

                <el-input v-model="searchForm.keyword" placeholder="搜索关键词" style="width: 300px;" />

              </el-form-item>

              <el-form-item>

                <el-button type="primary" @click="handleSearch">搜索</el-button>

              </el-form-item>

            </el-form>

          </div>

          

 <!-- PCAP 策略列表 -->

          <el-table :data="pcapEndpoints" style="width: 100%">

            <el-table-column prop="name" label="名称" min-width="150" sortable />

            <el-table-column prop="team" label="团队" width="120" />

            <el-table-column prop="pcapPolicy" label="关联PCAP策略" min-width="200" />

            <el-table-column prop="alertCount" label="关联告警策略" width="120">

              <template #default="scope">

                <el-button  @click="viewAlertStrategies(scope.row)">{{ scope.row.alertCount }}</el-button>

              </template>

            </el-table-column>

            <el-table-column prop="sourceAccount" label="来源账号" width="150" />

            <el-table-column prop="updateTime" label="更新时间" width="180" sortable />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" @click="editPcapEndpoint(scope.row)">

                  <el-icon><Edit /></el-icon>

                </el-button>

                <el-button size="small" type="danger" @click="deletePcapEndpoint(scope.row)">

                  <el-icon><Delete /></el-icon>

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ pcapEndpointTotal }} 条

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="pcapEndpointTotal"

              :page-size="pagination.endpoint.pageSize"

              :current-page="pagination.endpoint.currentPage"

              @current-change="(page) => handleCurrentChange(page, 'endpoint')"

            />

          </div>

        </el-tab-pane>

        

 <!-- Syslog 推送标签页 -->

        <el-tab-pane label="Syslog推送" name="syslog">

 <!-- 操作按钮 -->

          <div class="action-buttons mb-4">

            <el-button type="primary" @click="dialogVisible.syslog = true">新建连接Syslog推送</el-button>

          </div>

          

 <!-- 最近5分钟 -->

          <div class="search-filter mb-4">

            <el-form :inline="true" :model="searchForm" class="demo-form-inline">

              <el-form-item label="Syslog推送列表（最多10项）">

                <el-input v-model="searchForm.keyword" placeholder="搜索关键词" style="width: 300px;" />

              </el-form-item>

              <el-form-item>

                <el-button type="primary" @click="handleSearch">搜索</el-button>

              </el-form-item>

            </el-form>

          </div>

          

 <!-- Syslog 推送列表 -->

          <el-table :data="syslogEndpoints" style="width: 100%">

            <el-table-column prop="name" label="名称" min-width="150" sortable />

            <el-table-column prop="team" label="团队" width="120" />

            <el-table-column prop="destination" label="推送目的端" min-width="200" />

            <el-table-column prop="alertType" label="通知类型" width="150" />

            <el-table-column prop="alertCount" label="关联告警策略" width="120">

              <template #default="scope">

                <el-button  @click="viewAlertStrategies(scope.row)">{{ scope.row.alertCount }}</el-button>

              </template>

            </el-table-column>

            <el-table-column prop="sourceAccount" label="来源账号" width="150" />

            <el-table-column prop="updateTime" label="更新时间" width="180" sortable />

            <el-table-column label="操作" width="100" fixed="right">

              <template #default="scope">

                <el-button size="small" @click="editSyslogEndpoint(scope.row)">

                  <el-icon><Edit /></el-icon>

                </el-button>

                <el-button size="small" type="danger" @click="deleteSyslogEndpoint(scope.row)">

                  <el-icon><Delete /></el-icon>

                </el-button>

              </template>

            </el-table-column>

          </el-table>

          

 <!-- 数据库表 -->

          <div class="pagination mt-4">

            <div class="pagination-info">

              共 {{ syslogEndpointTotal }} 条

            </div>

            <el-pagination

              background

              layout="prev, pager, next, jumper"

              :total="syslogEndpointTotal"

              :page-size="pagination.endpoint.pageSize"

              :current-page="pagination.endpoint.currentPage"

              @current-change="(page) => handleCurrentChange(page, 'endpoint')"

            />

          </div>

        </el-tab-pane>

      </el-tabs>

    </el-card>

    

 <!-- 告警事件 -->

    <el-card v-if="currentModule === 'event'" class="mb-4">

      <template #header>

        <div class="card-header">

          <h2>告警事件</h2>

          <div class="header-actions">

            <el-button @click="refreshAlertEvents">

              <el-icon><Refresh /></el-icon> 刷新

            </el-button>

          </div>

        </div>

      </template>

      

 <!-- 时间范围选择 -->

      <div class="time-range-select mb-4">

        <el-select v-model="timeRange" placeholder="最近一天" style="margin-right: 10px;">

          <el-option label="最近一天" value="1d" />

          <el-option label="最近一周" value="7d" />

          <el-option label="最近一个月" value="30d" />

          <el-option label="自定义" value="custom" />

        </el-select>

        <el-date-picker

          v-if="timeRange === 'custom'"

          v-model="dateRange"

          type="daterange"

          range-separator="至"

          start-placeholder="开始时间"

          end-placeholder="结束时间"

          format="YYYY-MM-DD HH:mm:ss"

          value-format="YYYY-MM-DD HH:mm:ss"

          style="margin-right: 10px;"

        />

        <el-button type="primary" @click="handleSearch">搜索</el-button>

      </div>

      

 <!-- 过滤面板 -->

      <div class="filter-panel mb-4">

        <div class="filter-section">

          <h3>过滤面板</h3>

          <div class="filter-content">

 <!-- 策略等级 -->

            <div class="filter-item">

              <h4>策略等级</h4>

              <el-checkbox-group v-model="filterForm.strategyLevel">

                <el-checkbox label="高">高</el-checkbox>

                <el-checkbox label="中">中</el-checkbox>

                <el-checkbox label="低">低</el-checkbox>

              </el-checkbox-group>

            </div>

            

 <!-- 事件等级 -->

            <div class="filter-item">

              <h4>事件等级</h4>

              <el-checkbox-group v-model="filterForm.eventLevel">

                <el-checkbox label="致命">致命</el-checkbox>

                <el-checkbox label="错误">错误</el-checkbox>

                <el-checkbox label="警告">警告</el-checkbox>

                <el-checkbox label="恢复">恢复</el-checkbox>

                <el-checkbox label="已通知">已通知</el-checkbox>

                <el-checkbox label="未确认">未确认</el-checkbox>

              </el-checkbox-group>

            </div>

            

 <!-- 监控对象 -->

            <div class="filter-item">

              <h4>监控对象</h4>

              <el-checkbox-group v-model="filterForm.monitorObject">

                <el-checkbox label="指标">指标</el-checkbox>

                <el-checkbox label="系统">系统</el-checkbox>

              </el-checkbox-group>

            </div>

            

 <!-- 区域 -->

            <div class="filter-item">

              <h4>区域</h4>

              <el-checkbox-group v-model="filterForm.region">

                <el-checkbox label="华北-北京">华北-北京</el-checkbox>

                <el-checkbox label="华中-上海">华中-上海</el-checkbox>

                <el-checkbox label="华南-广州">华南-广州</el-checkbox>

              </el-checkbox-group>

            </div>

            

 <!-- 创建标签-->

            <div class="filter-item">

              <h4>创建标签</h4>

              <el-checkbox-group v-model="filterForm.creator">

                <el-checkbox label="admin">admin</el-checkbox>

                <el-checkbox label="user1">user1</el-checkbox>

                <el-checkbox label="user2">user2</el-checkbox>

              </el-checkbox-group>

            </div>

          </div>

        </div>

      </div>

      

 <!-- 时间范围 -->

      <div class="search-box mb-4">

        <el-input

          v-model="searchKeyword"

          placeholder="输入查询条件，如 policy_id = 145 等..."

          style="width: 400px;"

        >

          <template #append>

            <el-button type="primary" @click="handleSearch">搜索</el-button>

          </template>

        </el-input>

      </div>

      

 <!-- 可用区数量 -->

      <div class="chart-container mb-4">

        <div class="chart-header">

          <h3>异常分析</h3>

          <div class="chart-controls">

            <el-select v-model="chartType" placeholder="选择维度" style="margin-right: 10px;">

              <el-option label="按小时" value="hour" />

              <el-option label="按天" value="day" />

              <el-option label="按周" value="week" />

            </el-select>

            <el-select v-model="chartRange" placeholder="查看范围管理" style="margin-right: 10px;">

              <el-option label="全部" value="all" />

              <el-option label="华北-北京" value="beijing" />

              <el-option label="华中-上海" value="shanghai" />

              <el-option label="华南-广州" value="guangzhou" />

            </el-select>

          </div>

        </div>

        <div class="chart-content">

 <!-- 处理事件函数 -->

          <div class="mock-chart">

            <div class="chart-title">告警事件趋势</div>

            <div class="chart-bars">

              <div v-for="(height, index) in alertEventChartData" :key="index" class="chart-bar" :style="{ height: height + '%' }"></div>

            </div>

            <div class="chart-x-axis">

              <div v-for="i in 6" :key="i" class="x-axis-label">{{ i * 2 }}:00</div>

            </div>

          </div>

        </div>

      </div>

      

 <!-- 告警事件列表 -->

      <div class="event-table">

        <div class="table-header">

          <div class="table-title">事件详情表（共27条数据库）</div>

          <div class="table-controls">

            <el-button type="primary" @click="exportEvents">导出</el-button>

            <el-button @click="toggleColumns">列选择</el-button>

          </div>

        </div>

        

        <el-table 

          :data="alertEvents" 

          style="width: 100%"

          @row-dblclick="viewEventDetail"

        >

          <el-table-column prop="startTime" label="开始时间" width="180" sortable />

          <el-table-column prop="name" label="事件名称" min-width="200" />

          <el-table-column prop="level" label="事件等级" width="100">

            <template #default="scope">

              <el-tag :type="getLevelType(scope.row.level)">{{ scope.row.level }}</el-tag>

            </template>

          </el-table-column>

          <el-table-column prop="monitorObject" label="监控对象" width="120" />

          <el-table-column prop="eventInfo" label="事件信息" min-width="300" />

          <el-table-column prop="creator" label="创建标签" width="100" />

        </el-table>

        

 <!-- 数据库表 -->

        <div class="pagination mt-4">

          <div class="pagination-info">

            共 {{ alertEventTotal }} 条

          </div>

          <el-pagination

            background

            layout="prev, pager, next, jumper"

            :total="alertEventTotal"

            :page-size="pagination.event.pageSize"

            :current-page="pagination.event.currentPage"

            @current-change="(page) => handleCurrentChange(page, 'event')"

          />

        </div>

      </div>

    </el-card>

    

 <!-- 事件详情弹窗 -->

    <el-dialog

      v-model="dialogVisible.eventDetail"

      title="告警事件详情"

      width="800px"

    >

      <div class="event-detail-content">

        <div class="detail-section">

          <h3>基本信息</h3>

          <el-descriptions :column="2">

            <el-descriptions-item label="事件ID">{{ selectedEvent?.id }}</el-descriptions-item>

            <el-descriptions-item label="事件等级">{{ selectedEvent?.level }}</el-descriptions-item>

            <el-descriptions-item label="事件名称">{{ selectedEvent?.name }}</el-descriptions-item>

            <el-descriptions-item label="监控对象">{{ selectedEvent?.monitorObject }}</el-descriptions-item>

            <el-descriptions-item label="开始时间">{{ selectedEvent?.startTime }}</el-descriptions-item>

            <el-descriptions-item label="结束时间">{{ selectedEvent?.endTime }}</el-descriptions-item>

            <el-descriptions-item label="创建标签">{{ selectedEvent?.creator }}</el-descriptions-item>

            <el-descriptions-item label="区域">{{ selectedEvent?.region }}</el-descriptions-item>

          </el-descriptions>

        </div>

        <div class="detail-section">

          <h3>事件信息</h3>

          <el-descriptions :column="1">

            <el-descriptions-item label="事件响应时间">{{ selectedEvent?.eventInfo }}</el-descriptions-item>

            <el-descriptions-item label="触发条件">{{ selectedEvent?.triggerCondition }}</el-descriptions-item>

            <el-descriptions-item label="处理建议">{{ selectedEvent?.suggestion }}</el-descriptions-item>

          </el-descriptions>

        </div>

      </div>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="dialogVisible.eventDetail = false">关闭</el-button>

        </span>

      </template>

    </el-dialog>

    

 <!-- 列选择弹窗 -->

    <el-dialog

      v-model="dialogVisible.columnSelect"

      title="列选择"

      width="500px"

    >

      <el-checkbox-group v-model="selectedColumns">

        <el-checkbox label="开始时间">开始时间</el-checkbox>

        <el-checkbox label="事件名称">事件名称</el-checkbox>

        <el-checkbox label="事件等级">事件等级</el-checkbox>

        <el-checkbox label="监控对象">监控对象</el-checkbox>

        <el-checkbox label="事件信息">事件信息</el-checkbox>

        <el-checkbox label="创建标签">创建标签</el-checkbox>

        <el-checkbox label="区域">区域</el-checkbox>

        <el-checkbox label="事件UID">事件UID</el-checkbox>

      </el-checkbox-group>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="dialogVisible.columnSelect = false">取消</el-button>

          <el-button type="primary" @click="confirmColumnSelect">确定</el-button>

        </span>

      </template>

    </el-dialog>

    

 <!-- 新建连接PCAP策略弹窗 -->

    <el-dialog

      v-model="dialogVisible.pcap"

      title="新建连接PCAP策略"

      width="500px"

    >

      <el-form :model="pcapForm" label-width="100px">

        <el-form-item label="* 策略">

          <el-input v-model="pcapForm.name" placeholder="请输入名称" />

        </el-form-item>

        <el-form-item label="* 团队">

          <el-select v-model="pcapForm.team" placeholder="请选择团队">

            <el-option label="Default团队" value="Default团队" />

          </el-select>

        </el-form-item>

        <el-form-item label="响应时间">

          <el-input v-model="pcapForm.description" placeholder="可输入55个任意字符" type="textarea" />

        </el-form-item>

        <el-form-item label="账号">

          <el-select v-model="pcapForm.account" placeholder="请选择">

            <el-option label="测试账号" value="test" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 关联PCAP策略">

          <el-select v-model="pcapForm.pcapPolicy" placeholder="请选择">

            <el-option label="PCAP策略1" value="PCAP策略1" />

            <el-option label="PCAP策略2" value="PCAP策略2" />

          </el-select>

        </el-form-item>

        <el-form-item label="启用PCAP策略">

          <el-select v-model="pcapForm.enablePcap" placeholder="请选择">

            <el-option label="致命, 错误, 警告" value="fatal,error,warning" />

          </el-select>

        </el-form-item>

        <el-form-item label="禁用PCAP策略">

          <el-select v-model="pcapForm.disablePcap" placeholder="请选择">

            <el-option label="恢复" value="recovery" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 推送周期">

          <el-select v-model="pcapForm.cycle" placeholder="请选择">

            <el-option label="15分钟" value="15min" />

            <el-option label="30分钟" value="30min" />

            <el-option label="1小时" value="1小时" />

          </el-select>

        </el-form-item>

        <el-form-item label="推送棰戠巼">

          <div class="frequency-control">

            <el-switch v-model="pcapForm.frequencyEnabled" />

            <el-input v-model="pcapForm.frequency" style="width: 80px; margin-left: 10px;" />

            <span style="margin-left: 10px;">秒</span>

          </div>

        </el-form-item>

      </el-form>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="dialogVisible.pcap = false">取消</el-button>

          <el-button type="primary" @click="confirmPcapForm">确定</el-button>

        </span>

      </template>

    </el-dialog>

    

 <!-- 新建连接Syslog推送弹窗-->

    <el-dialog

      v-model="dialogVisible.syslog"

      title="新建连接Syslog推送"

      width="500px"

    >

      <el-form :model="syslogForm" label-width="100px">

        <el-form-item label="* 策略">

          <el-input v-model="syslogForm.name" placeholder="请输入名称" />

        </el-form-item>

        <el-form-item label="* 团队">

          <el-select v-model="syslogForm.team" placeholder="请选择团队">

            <el-option label="Default团队" value="Default团队" />

          </el-select>

        </el-form-item>

        <el-form-item label="响应时间">

          <el-input v-model="syslogForm.description" placeholder="可输入55个任意字符" type="textarea" />

        </el-form-item>

        <el-form-item label="* 推送目的端">

          <el-input v-model="syslogForm.destination" placeholder="[webhook://[host]:[port]" />

        </el-form-item>

        <el-form-item label="Message">

          <el-input v-model="syslogForm.message" placeholder="支持Jinja模板渲染，默认推送内容参考参数说明" type="textarea" />

          <div class="form-help">

            <el-button  @click="showSyslogHelp">参数说明</el-button>

            <el-button  @click="previewSyslogMessage">预览</el-button>

          </div>

        </el-form-item>

        <el-form-item label="配置等级">

          <el-select v-model="syslogForm.level" placeholder="请选择">

            <el-option label="严重, 错误, 警告, 恢复, 未确认" value="fatal,error,warning,recovery,no_data" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 推送周期">

          <el-select v-model="syslogForm.cycle" placeholder="请选择">

            <el-option label="15分钟" value="15min" />

            <el-option label="30分钟" value="30min" />

            <el-option label="1小时" value="1小时" />

          </el-select>

        </el-form-item>

        <el-form-item label="推送棰戠巼">

          <div class="frequency-control">

            <el-switch v-model="syslogForm.frequencyEnabled" />

            <el-input v-model="syslogForm.frequency" style="width: 80px; margin-left: 10px;" />

            <span style="margin-left: 10px;">秒</span>

          </div>

        </el-form-item>

      </el-form>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="dialogVisible.syslog = false">取消</el-button>

          <el-button type="primary" @click="confirmSyslogForm">确定</el-button>

        </span>

      </template>

    </el-dialog>

    

 <!-- 新建连接Email推送弹窗-->

    <el-dialog

      v-model="dialogVisible.email"

      title="新建连接Email推送"

      width="500px"

    >

      <el-form :model="emailForm" label-width="100px">

        <el-form-item label="* 策略">

          <el-input v-model="emailForm.name" placeholder="请输入名称" />

        </el-form-item>

        <el-form-item label="* 团队">

          <el-select v-model="emailForm.team" placeholder="请选择团队">

            <el-option label="Default团队" value="Default团队" />

          </el-select>

        </el-form-item>

        <el-form-item label="响应时间">

          <el-input v-model="emailForm.description" placeholder="可输入55个任意字符" type="textarea" />

        </el-form-item>

        <el-form-item label="* 邮箱">

          <el-input v-model="emailForm.email" placeholder="请输入邮箱" />

        </el-form-item>

        <el-form-item label="推送标题">

          <el-input v-model="emailForm.subject" placeholder="请输入推送标题" />

        </el-form-item>

        <el-form-item label="配置等级">

          <el-select v-model="emailForm.level" placeholder="请选择">

            <el-option label="严重, 错误, 警告, 恢复, 未确认" value="fatal,error,warning,recovery,no_data" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 推送周期">

           <el-select v-model="emailForm.cycle" placeholder="请选择">

            <el-option label="15分钟" value="15min" />

            <el-option label="30分钟" value="30min" />

            <el-option label="1小时" value="1小时" />

          </el-select>

        </el-form-item>

        <el-form-item label="推送棰戠巼">

          <div class="frequency-control">

            <el-switch v-model="emailForm.frequencyEnabled" />

            <el-input v-model="emailForm.frequency" style="width: 80px; margin-left: 10px;" />

            <span style="margin-left: 10px;">秒</span>

          </div>

        </el-form-item>

      </el-form>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="testEmailForm">测试</el-button>

          <el-button @click="dialogVisible.email = false">取消</el-button>

          <el-button type="primary" @click="confirmEmailForm">确定</el-button>

        </span>

      </template>

    </el-dialog>

    

 <!-- 新建连接HTTP推送弹窗-->

    <el-dialog

      v-model="dialogVisible.http"

      title="新建连接HTTP推送"

      width="500px"

    >

      <el-form :model="httpForm" label-width="100px">

        <el-form-item label="* 策略">

          <el-input v-model="httpForm.name" placeholder="请输入名称" />

        </el-form-item>

        <el-form-item label="* 团队">

          <el-select v-model="httpForm.team" placeholder="请选择团队">

            <el-option label="Default团队" value="Default团队" />

          </el-select>

        </el-form-item>

        <el-form-item label="响应时间">

          <el-input v-model="httpForm.description" placeholder="可输入55个任意字符" type="textarea" />

        </el-form-item>

        <el-form-item label="* 推送方式">

          <el-select v-model="httpForm.method" placeholder="请选择">

            <el-option label="POST" value="POST" />

            <el-option label="PUT" value="PUT" />

            <el-option label="PATCH" value="PATCH" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 推送URL">

          <el-input v-model="httpForm.url" placeholder="支持HTTP、HTTPS协议，支持Jinja模板渲染" />

        </el-form-item>

        <el-form-item label="Header">

          <div class="header-control">

            <el-input v-model="httpForm.headerKey" placeholder="key" style="width: 120px;" />

            <span style="margin: 0 10px;">:</span>

            <el-input v-model="httpForm.headerValue" placeholder="value" style="width: 200px;" />

            <el-button type="primary" size="small" style="margin-left: 10px;">+</el-button>

          </div>

        </el-form-item>

        <el-form-item label="推送内容">

          <el-input v-model="httpForm.content" placeholder="支持Jinja模板渲染，默认推送内容参考参数说明" type="textarea" />

          <div class="form-help">

            <el-button  @click="showHttpHelp">参数说明</el-button>

            <el-button  @click="previewHttpContent">预览</el-button>

          </div>

        </el-form-item>

        <el-form-item label="配置等级">

          <el-select v-model="httpForm.level" placeholder="请选择">

            <el-option label="严重, 错误, 警告, 恢复, 未确认" value="fatal,error,warning,recovery,no_data" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 推送周期">

          <el-select v-model="httpForm.cycle" placeholder="请选择">

            <el-option label="15分钟" value="15min" />

            <el-option label="30分钟" value="30min" />

            <el-option label="1小时" value="1小时" />

          </el-select>

        </el-form-item>

        <el-form-item label="推送棰戠巼">

          <div class="frequency-control">

            <el-switch v-model="httpForm.frequencyEnabled" />

            <el-input v-model="httpForm.frequency" style="width: 80px; margin-left: 10px;" />

            <span style="margin-left: 10px;">秒</span>

          </div>

        </el-form-item>

      </el-form>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="testHttpForm">测试</el-button>

          <el-button @click="dialogVisible.http = false">取消</el-button>

          <el-button type="primary" @click="confirmHttpForm">确定</el-button>

        </span>

      </template>

    </el-dialog>

    

 <!-- 新建连接Kafka推送弹窗-->

    <el-dialog

      v-model="dialogVisible.kafka"

      title="新建连接Kafka推送"

      width="500px"

    >

      <el-form :model="kafkaForm" label-width="100px">

        <el-form-item label="* 策略">

          <el-input v-model="kafkaForm.name" placeholder="请输入名称" />

        </el-form-item>

        <el-form-item label="* 团队">

          <el-select v-model="kafkaForm.team" placeholder="请选择团队">

            <el-option label="Default团队" value="Default团队" />

          </el-select>

        </el-form-item>

        <el-form-item label="响应时间">

          <el-input v-model="kafkaForm.description" placeholder="可输入55个任意字符" type="textarea" />

        </el-form-item>

        <el-form-item label="* Broker地址">

          <el-input v-model="kafkaForm.broker" placeholder="[Broker地址]:[端口],[Broker地址]:[端口]" />

        </el-form-item>

        <el-form-item label="* Topic">

          <el-input v-model="kafkaForm.topic" placeholder="请输入Topic" />

        </el-form-item>

        <el-form-item label="SASL">

          <el-select v-model="kafkaForm.sasl" placeholder="请选择">

            <el-option label="None" value="none" />

            <el-option label="Plain" value="plain" />

          </el-select>

        </el-form-item>

        <el-form-item label="推送内容">

          <el-input v-model="kafkaForm.content" placeholder="支持Jinja模板渲染，默认推送内容参考参数说明" type="textarea" />

          <div class="form-help">

            <el-button  @click="showKafkaHelp">参数说明</el-button>

            <el-button  @click="previewKafkaContent">预览</el-button>

          </div>

        </el-form-item>

        <el-form-item label="配置等级">

          <el-select v-model="kafkaForm.level" placeholder="请选择">

            <el-option label="严重, 错误, 警告, 恢复, 未确认" value="fatal,error,warning,recovery,no_data" />

          </el-select>

        </el-form-item>

        <el-form-item label="* 推送周期">

          <el-select v-model="kafkaForm.cycle" placeholder="请选择">

            <el-option label="15分钟" value="15min" />

            <el-option label="30分钟" value="30min" />

            <el-option label="1小时" value="1小时" />

          </el-select>

        </el-form-item>

        <el-form-item label="推送棰戠巼">

          <div class="frequency-control">

            <el-switch v-model="kafkaForm.frequencyEnabled" />

            <el-input v-model="kafkaForm.frequency" style="width: 80px; margin-left: 10px;" />

            <span style="margin-left: 10px;">秒</span>

          </div>

        </el-form-item>

      </el-form>

      <template #footer>

        <span class="dialog-footer">

          <el-button @click="testKafkaForm">测试</el-button>

          <el-button @click="dialogVisible.kafka = false">取消</el-button>

          <el-button type="primary" @click="confirmKafkaForm">确定</el-button>

        </span>

      </template>

    </el-dialog>

  </div>

</template>



<script setup lang="ts">

// 生成模拟数据库（仅在组件挂载时调用一次，避免图表跳动）
const generateMockData = (max: number, min: number, count: number = 30) =>
  Array(count).fill(0).map(() => Math.random() * max + min)

import { ref, computed, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { useRoute } from 'vue-router'

import { Edit, Delete, Refresh } from '@element-plus/icons-vue'



// 路由

const route = useRoute()



// 当前模块

const currentModule = computed(() => {

  return route.path.split('/').pop() || 'strategy'

})



// 分页相关变量 - 分页相关变量
const pagination = reactive({
  strategy: {
    pageSize: 10,
    currentPage: 1
  },
  endpoint: {
    pageSize: 10,
    currentPage: 1
  },
  event: {
    pageSize: 10,
    currentPage: 1
  }
})

// 数据源 - 存储CPU、内存、网络等历史数据
const alertEventChartData = ref([])

onMounted(() => {
  alertEventChartData.value = generateMockData(80, 20, 24)
})



// 搜索表单

const searchForm = ref({

  keyword: '',

  timeRange: '1d',

  dateRange: []

})



// 对话框状态

const dialogVisible = ref({

  email: false,

  http: false,

  kafka: false,

  pcap: false,

  syslog: false,

  eventDetail: false,

  columnSelect: false

})



// Email推送表
const emailForm = ref({

  name: '',

  team: 'Default团队',

  description: '',

  email: '',

  subject: '',

  level: 'fatal,error,warning,recovery,no_data',

  cycle: '15min',

  frequencyEnabled: false,

  frequency: 0

})



// HTTP推送表
const httpForm = ref({

  name: '',

  team: 'Default团队',

  description: '',

  method: 'POST',

  url: '',

  headerKey: '',

  headerValue: '',

  content: '',

  level: 'fatal,error,warning,recovery,no_data',

  cycle: '15min',

  frequencyEnabled: false,

  frequency: 0

})



// Kafka推送表
const kafkaForm = ref({

  name: '',

  team: 'Default团队',

  description: '',

  broker: '',

  topic: '',

  sasl: 'none',

  content: '',

  level: 'fatal,error,warning,recovery,no_data',

  cycle: '15min',

  frequencyEnabled: false,

  frequency: 0

})



// PCAP事件名称解析

const pcapForm = ref({

  name: '',

  team: 'Default团队',

  description: '',

  account: '',

  pcapPolicy: '',

  enablePcap: 'fatal,error,warning',

  disablePcap: 'recovery',

  cycle: '15min',

  frequencyEnabled: false,

  frequency: 0

})



// Syslog推送表
const syslogForm = ref({

  name: '',

  team: 'Default团队',

  description: '',

  destination: '',

  message: '',

  level: 'fatal,error,warning,recovery,no_data',

  cycle: '15min',

  frequencyEnabled: false,

  frequency: 0

})



// 告警统计概览

const alertStrategies = ref([

  {

    id: '1',

    name: 'test33333333',

    team: 'Default团队',

    monitor: '指标',

    rule: '过滤器 N/A | 分组: * | 致命: Avg...',

    tags: [],

    level: '高',

    alertCount: 1397,

    createTime: '2024-05-17 15:52:54',

    status: true,

    endpoint: '--'

  },

  {

    id: '2',

    name: '【告警】系统告警',

    team: 'Default团队',

    monitor: '指标',

    rule: '过滤器 policy.app_type = 系统, event_level = 告警',

    tags: ['liqian'],

    level: '高',

    alertCount: 0,

    createTime: '2024-04-18 16:07:23',

    status: true,

    endpoint: 'Email1'

  },

  {

    id: '3',

    name: '【警告】系统警告',

    team: 'Default团队',

    monitor: '指标',

    rule: '过滤器 policy.app_type = 系统, event_level = 警告',

    tags: ['liqian'],

    level: '中',

    alertCount: 1361,

    createTime: '2024-04-18 16:07:11',

    status: true,

    endpoint: 'Email1'

  },

  {

    id: '4',

    name: '【致命】系统告警',

    team: 'Default团队',

    monitor: '指标',

    rule: '过滤器 policy.app_type = 系统, event_level = 致命',

    tags: ['liqian'],

    level: '高',

    alertCount: 218,

    createTime: '2024-04-18 16:07:06',

    status: true,

    endpoint: 'Email1'

  },

  {

    id: '5',

    name: 'SandBox_请求检测告警',

    team: 'Default团队',

    monitor: '指标',

    rule: '过滤器 pod.cluster = SandBox...',

    tags: [],

    level: '高',

    alertCount: 171,

    createTime: '2024-04-18 14:40:50',

    status: true,

    endpoint: 'HTTP1'

  },

  {

    id: '6',

    name: '数据库节点连接异常 (ingester.chir...',

    team: 'Default团队',

    monitor: '系统',

    rule: '过滤器 N/A | 分组: tag.host: ...',

    tags: [],

    level: '高',

    alertCount: 0,

    createTime: '2024-04-11 07:26:38',

    status: true,

    endpoint: '--'

  },

  {

    id: '7',

    name: '数据库节点连接异常 (ingester.queue...',

    team: 'Default团队',

    monitor: '系统',

    rule: '过滤器 N/A | 分组: tag.host: ...',

    tags: [],

    level: '高',

    alertCount: 0,

    createTime: '2024-04-11 07:26:38',

    status: true,

    endpoint: '--'

  },

  {

    id: '8',

    name: '数据库节点连接异常 (ingester.recv...',

    team: 'Default团队',

    monitor: '系统',

    rule: '过滤器 N/A | 分组: tag.host: ...',

    tags: [],

    level: '高',

    alertCount: 2869,

    createTime: '2024-04-11 07:26:38',

    status: true,

    endpoint: '--'

  },

  {

    id: '9',

    name: '事件通知发送方式 (collect.sender.me...',

    team: 'Default团队',

    monitor: '系统',

    rule: '过滤器 N/A | 分组: tag.host: ...',

    tags: [],

    level: '高',

    alertCount: 15,

    createTime: '2024-04-11 07:26:38',

    status: true,

    endpoint: '--'

  }

])



const alertStrategyTotal = ref(55)



// 当前选中的推送端点标签页

const activeEndpointTab = ref('email')



// Email 推送数据

const emailEndpoints = ref([

  {

    id: '1',

    name: '测试',

    team: '--',

    email: 'zhui@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'zhui@example.com',

    updateTime: '2023-09-04 21:30:14'

  },

  {

    id: '2',

    name: '测试',

    team: '--',

    email: 'chyi@example.com',

    alertType: '告警开启',

    alertCount: 1,

    sourceAccount: 'chyi@example.com',

    updateTime: '2023-02-21 10:17:50'

  },

  {

    id: '3',

    name: 'zhan',

    team: '--',

    email: 'zhan@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'ye@example.com',

    updateTime: '2023-01-04 17:19:51'

  },

  {

    id: '4',

    name: 'min',

    team: '--',

    email: 'min@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 1,

    sourceAccount: '17@example.com',

    updateTime: '2022-12-07 15:37:09'

  },

  {

    id: '5',

    name: '1',

    team: '--',

    email: 'chong@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'chong@example.com',

    updateTime: '2022-07-04 10:46:33'

  },

  {

    id: '6',

    name: 'test',

    team: '--',

    email: 'teq@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'xc@example.com',

    updateTime: '2022-06-09 10:44:43'

  },

  {

    id: '7',

    name: 'liug',

    team: '--',

    email: 'liug@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'xc@example.com',

    updateTime: '2022-06-09 10:43:40'

  },

  {

    id: '8',

    name: '1',

    team: '--',

    email: 'wei@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'wei@example.com',

    updateTime: '2022-05-24 14:33:09'

  },

  {

    id: '9',

    name: '测试',

    team: '--',

    email: 'he@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 1,

    sourceAccount: 'xc@example.com',

    updateTime: '2022-03-15 16:36:12'

  },

  {

    id: '10',

    name: 'Meil',

    team: '--',

    email: 'chyi@example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'chyi@example.com',

    updateTime: '2022-03-02 16:20:13'

  }

])



const emailEndpointTotal = ref(18)



// HTTP 推送数据

const httpEndpoints = ref([

  {

    id: '1',

    name: '云原生电商应用2',

    team: '--',

    method: 'POST',

    header: 'Content-Type:application/json',

    url: 'https://example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 1,

    sourceAccount: 'xc@example.com',

    updateTime: '2023-09-28 09:59:16'

  },

  {

    id: '2',

    name: '飞书推送',

    team: '--',

    method: 'POST',

    header: 'Content-Type:application/json',

    url: 'https://example.com',

    alertType: '告警开启 告警聚合',

    alertCount: 2,

    sourceAccount: 'yile@example.com',

    updateTime: '2022-01-06 15:35:08'

  },

  {

    id: '3',

    name: 'qa-survey',

    team: '内部测试',

    method: 'POST',

    header: '--',

    url: 'http://11',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'pm@example.com',

    updateTime: '2021-11-02 16:20:19'

  }

])



const httpEndpointTotal = ref(3)



// Kafka 推送数据

const kafkaEndpoints = ref([

  {

    id: '1',

    name: '测试',

    team: 'Default团队',

    broker: '192.168.1.1:9092, 192.168.1.2:9092',

    topic: 'alert-topic',

    sasl: 'Plain',

    alertCount: 0,

    sourceAccount: 'test@example.com',

    updateTime: '2023-01-01 00:00:00'

  }

])



const kafkaEndpointTotal = ref(6)



// PCAP 统计概览

const pcapEndpoints = ref([

  {

    id: '1',

    name: '测试PCAP策略',

    team: 'Default团队',

    pcapPolicy: 'PCAP策略1',

    alertCount: 0,

    sourceAccount: 'test@example.com',

    updateTime: '2023-01-01 00:00:00'

  }

])



const pcapEndpointTotal = ref(5)



// Syslog 相关变量

const syslogEndpoints = ref([

  {

    id: '1',

    name: '测试Syslog推送',

    team: 'Default团队',

    destination: 'udp://192.168.1.1:514',

    alertType: '告警开启 告警聚合',

    alertCount: 0,

    sourceAccount: 'test@example.com',

    updateTime: '2023-01-01 00:00:00'

  }

])



const syslogEndpointTotal = ref(4)



// 搜索快照管理

const timeRange = ref('1d')

const dateRange = ref([])



// 搜索处理函数

const searchKeyword = ref('')



// 数据源配置

const chartType = ref('hour')

const chartRange = ref('all')



// 杩囨护表单

const filterForm = ref({

  strategyLevel: [],

  eventLevel: [],

  monitorObject: [],

  region: [],

  creator: []

})



// 选中的列

const selectedColumns = ref(['事件名称', '事件级别', '事件状态', '触发条件', '通知方式', '存储分析'])



// 时间范围相关变量

const alertEvents = ref([

  {

    id: '1',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:53:00',

    endTime: '2023-05-18 10:53:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '2',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:52:00',

    endTime: '2023-05-18 10:52:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '3',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:51:00',

    endTime: '2023-05-18 10:51:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '4',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:49:00',

    endTime: '2023-05-18 10:49:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '5',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:48:00',

    endTime: '2023-05-18 10:48:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '6',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:47:00',

    endTime: '2023-05-18 10:47:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '7',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:46:00',

    endTime: '2023-05-18 10:46:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '8',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:45:00',

    endTime: '2023-05-18 10:45:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '9',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:44:00',

    endTime: '2023-05-18 10:44:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  },

  {

    id: '10',

    name: '数据库节点连接异常 (ingester.receiver.event)',

    level: '警告',

    monitorObject: '系统',

    eventInfo: 'queries: region=华中-上海, tag.host=警告: drop_packets(16) > 1. 触发阈值 1.000000',

    creator: 'admin',

    startTime: '2023-05-18 10:43:00',

    endTime: '2023-05-18 10:43:00',

    region: '华中-上海',

    triggerCondition: 'drop_packets(16) > 1',

    suggestion: '检查数据库节点网络连接和接收能力'

  }

])



const alertEventTotal = ref(227)



// 选中的事
const selectedEvent = ref(null)



// 分页处理函数

const handleSearch = () => {
  ElMessage.info('功能开发中...')
  }



// 分页流程处理

const handleCurrentChange = (page: number, module: string) => {
  pagination[module as keyof typeof pagination].currentPage = page
}



// 告警统计详情

const createAlertStrategy = () => {
  ElMessage.info('功能开发中...')
  }



const viewAlertEvents = (strategy: any) => {
  ElMessage.info('功能开发中...')
  }



const toggleStatus = (strategy: any) => {

  }



const editAlertStrategy = (strategy: any) => {

  }



const deleteAlertStrategy = (strategy: any) => {

  }



// 推送端点
const viewAlertStrategies = (endpoint: any) => {

  }



// Email 推送配置

const createEmailEndpoint = () => {
  ElMessage.info('功能开发中...')
  }



const editEmailEndpoint = (endpoint: any) => {
  ElMessage.info('功能开发中...')
  }



const deleteEmailEndpoint = (endpoint: any) => {

  }



// HTTP 推送配置

const createHttpEndpoint = () => {
  ElMessage.info('功能开发中...')
  }



const editHttpEndpoint = (endpoint: any) => {
  ElMessage.info('功能开发中...')
  }



const deleteHttpEndpoint = (endpoint: any) => {

  }



// Kafka 推送配置

const createKafkaEndpoint = () => {
  ElMessage.info('功能开发中...')
  }



const editKafkaEndpoint = (endpoint: any) => {
  ElMessage.info('功能开发中...')
  }



const deleteKafkaEndpoint = (endpoint: any) => {

  }



// PCAP 统计详情

const createPcapEndpoint = () => {
  ElMessage.info('功能开发中...')
  }



const editPcapEndpoint = (endpoint: any) => {
  ElMessage.info('功能开发中...')
  }



const deletePcapEndpoint = (endpoint: any) => {

  }



// Syslog 推送配置

const createSyslogEndpoint = () => {
  ElMessage.info('功能开发中...')
  }



const editSyslogEndpoint = (endpoint: any) => {
  ElMessage.info('功能开发中...')
  }



const deleteSyslogEndpoint = (endpoint: any) => {

  }



// 窗口流程参数《

const confirmPcapForm = () => {

  dialogVisible.value.pcap = false

 // 处理函数

  pcapForm.value = {

    name: '',

    team: 'Default团队',

    description: '',

    account: '',

    pcapPolicy: '',

    enablePcap: 'fatal,error,warning',

    disablePcap: 'recovery',

    cycle: '15min',

    frequencyEnabled: false,

    frequency: 0

  }

}



const confirmSyslogForm = () => {

  dialogVisible.value.syslog = false

 // 处理函数

  syslogForm.value = {

    name: '',

    team: 'Default团队',

    description: '',

    destination: '',

    message: '',

    level: 'fatal,error,warning,recovery,no_data',

    cycle: '15min',

    frequencyEnabled: false,

    frequency: 0

  }

}



const showSyslogHelp = () => {
  ElMessage.info('功能开发中...')
  }



const previewSyslogMessage = () => {
  ElMessage.info('功能开发中...')
  }



// Email推送操作方
const testEmailForm = () => {
  ElMessage.info('功能开发中...')
  }



const confirmEmailForm = () => {

  dialogVisible.value.email = false

 // 处理函数

  emailForm.value = {

    name: '',

    team: 'Default团队',

    description: '',

    email: '',

    subject: '',

    level: 'fatal,error,warning,recovery,no_data',

    cycle: '15min',

    frequencyEnabled: false,

    frequency: 0

  }

}



// HTTP推送操作方
const showHttpHelp = () => {
  ElMessage.info('功能开发中...')
  }



const previewHttpContent = () => {
  ElMessage.info('功能开发中...')
  }



const testHttpForm = () => {
  ElMessage.info('功能开发中...')
  }



const confirmHttpForm = () => {

  dialogVisible.value.http = false

 // 处理函数

  httpForm.value = {

    name: '',

    team: 'Default团队',

    description: '',

    method: 'POST',

    url: '',

    headerKey: '',

    headerValue: '',

    content: '',

    level: 'fatal,error,warning,recovery,no_data',

    cycle: '15min',

    frequencyEnabled: false,

    frequency: 0

  }

}



// Kafka推送操作方
const showKafkaHelp = () => {
  ElMessage.info('功能开发中...')
  }



const previewKafkaContent = () => {
  ElMessage.info('功能开发中...')
  }



const testKafkaForm = () => {
  ElMessage.info('功能开发中...')
  }



const confirmKafkaForm = () => {

  dialogVisible.value.kafka = false

 // 处理函数

  kafkaForm.value = {

    name: '',

    team: 'Default团队',

    description: '',

    broker: '',

    topic: '',

    sasl: 'none',

    content: '',

    level: 'fatal,error,warning,recovery,no_data',

    cycle: '15min',

    frequencyEnabled: false,

    frequency: 0

  }

}



// 告警事件列表

const refreshAlertEvents = () => {
  ElMessage.info('功能开发中...')
  }



const exportEvents = () => {
  ElMessage.info('功能开发中...')
  }



const toggleColumns = () => {

  dialogVisible.value.columnSelect = true

}



const viewEventDetail = (event: any) => {

  selectedEvent.value = event

  dialogVisible.value.eventDetail = true

  }



const confirmColumnSelect = () => {

  dialogVisible.value.columnSelect = false

}



// 获取等级类型

const getLevelType = (level: string) => {

  switch (level) {

    case '高':

    case '致命':

      return 'danger'

    case '中':

    case '错误':

      return 'warning'

    case '低':

    case '警告':

      return 'info'

    default:

      return ''

  }

}

</script>



<style scoped>

.alert {

  padding: 20px;

}



.card-header {

  display: flex;

  justify-content: space-between;

  align-items: center;

}



.search-filter {

  margin-bottom: 20px;

}



.pagination {

  margin-top: 20px;

  display: flex;

  justify-content: space-between;

  align-items: center;

}



.pagination-info {

  color: #909399;

  font-size: 14px;

}



.header-actions {

  display: flex;

  gap: 10px;

}



.frequency-control {

  display: flex;

  align-items: center;

}



.form-help {

  display: flex;

  gap: 10px;

  margin-top: 5px;

}



.header-control {

  display: flex;

  align-items: center;

}



/* 告警事件页面样式 */

.time-range-select {

  display: flex;

  align-items: center;

  margin-bottom: 20px;

}



.filter-panel {

  background-color: #f5f7fa;

  padding: 15px;

  border-radius: 4px;

  margin-bottom: 20px;

}



.filter-section h3 {

  margin-top: 0;

  margin-bottom: 15px;

  font-size: 16px;

  font-weight: bold;

}



.filter-content {

  display: grid;

  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));

  gap: 20px;

}



.filter-item h4 {

  margin-top: 0;

  margin-bottom: 10px;

  font-size: 14px;

  font-weight: bold;

}



.filter-item .el-checkbox-group {

  display: flex;

  flex-direction: column;

  gap: 5px;

}



.search-box {

  margin-bottom: 20px;

}



.chart-container {

  background-color: #f5f7fa;

  padding: 15px;

  border-radius: 4px;

  margin-bottom: 20px;

}



.chart-header {

  display: flex;

  justify-content: space-between;

  align-items: center;

  margin-bottom: 15px;

}



.chart-header h3 {

  margin: 0;

  font-size: 16px;

  font-weight: bold;

}



.chart-controls {

  display: flex;

  align-items: center;

}



.mock-chart {

  background-color: white;

  padding: 20px;

  border-radius: 4px;

  height: 200px;

  display: flex;

  flex-direction: column;

}



.chart-title {

  margin-bottom: 10px;

  font-size: 14px;

  font-weight: bold;

}



.chart-bars {

  flex: 1;

  display: flex;

  align-items: flex-end;

  gap: 5px;

  margin-bottom: 10px;

}



.chart-bar {

  flex: 1;

  background-color: #409eff;

  border-radius: 4px 4px 0 0;

  min-height: 20px;

}



.chart-x-axis {

  display: flex;

  justify-content: space-between;

  font-size: 12px;

  color: #909399;

}



.event-table {

  background-color: white;

  border-radius: 4px;

  padding: 15px;

}



.table-header {

  display: flex;

  justify-content: space-between;

  align-items: center;

  margin-bottom: 15px;

}



.table-title {

  font-size: 16px;

  font-weight: bold;

}



.table-controls {

  display: flex;

  gap: 10px;

}



.event-detail-content {

  padding: 10px;

}



.detail-section {

  margin-bottom: 20px;

}



.detail-section h3 {

  margin-top: 0;

  margin-bottom: 15px;

  font-size: 16px;

  font-weight: bold;

  border-bottom: 1px solid #ebeef5;

  padding-bottom: 10px;

}



</style>