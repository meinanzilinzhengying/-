// SPDX-License-Identifier: GPL-2.0
#ifndef __COMMON_H__
#define __COMMON_H__

#include "vmlinux.h"
#include <bpf/bpf_endian.h>
#include <bpf/bpf_helpers.h>

// Protocol numbers
#define PROTO_ICMP 1
#define PROTO_TCP  6
#define PROTO_UDP  17

// Hash function for flow key
static __always_inline __u32 hash_flow(__u32 src_ip, __u32 dst_ip, 
                                       __u16 src_port, __u16 dst_port,
                                       __u8 proto)
{
    __u32 hash = src_ip ^ dst_ip ^ ((__u32)src_port << 16 | dst_port) ^ proto;
    return hash;
}

#endif
