package pool

import (
	"sync"

	edge "cloud-flow/proto"
)

// MetricDataPool pools MetricData objects to reduce GC pressure
var MetricDataPool = sync.Pool{
	New: func() interface{} {
		return &edge.MetricData{
			Tags: make(map[string]string, 8),
		}
	},
}

// GetMetricData retrieves a MetricData from the pool
func GetMetricData() *edge.MetricData {
	return MetricDataPool.Get().(*edge.MetricData)
}

// PutMetricData returns a MetricData to the pool after resetting
func PutMetricData(m *edge.MetricData) {
	// Reset fields
	m.ProbeId = ""
	m.Timestamp = 0
	m.SrcIp = ""
	m.DstIp = ""
	m.SrcPort = 0
	m.DstPort = 0
	m.Protocol = ""
	m.Bytes = 0
	m.Packets = 0
	m.Latency = 0
	m.CpuUsage = 0
	m.MemoryUsage = 0
	m.DiskUsage = 0
	// Clear tags
	for k := range m.Tags {
		delete(m.Tags, k)
	}
	MetricDataPool.Put(m)
}

// ByteSlicePool pools byte slices for network I/O
var ByteSlicePool = sync.Pool{
	New: func() interface{} {
		b := make([]byte, 4096)
		return &b
	},
}

// GetByteSlice retrieves a byte slice from the pool
func GetByteSlice() *[]byte {
	return ByteSlicePool.Get().(*[]byte)
}

// PutByteSlice returns a byte slice to the pool
func PutByteSlice(b *[]byte) {
	ByteSlicePool.Put(b)
}
