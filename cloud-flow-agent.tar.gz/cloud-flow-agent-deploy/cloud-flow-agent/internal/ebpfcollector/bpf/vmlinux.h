// SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause)
// Copyright (c) 2024 Cloud Flow Agent Contributors
//
// Minimal vmlinux.h for CO-RE support
// Full vmlinux.h can be generated with: bpftool btf dump file /sys/kernel/btf/vmlinux format c > vmlinux.h

#ifndef __VMLINUX_H__
#define __VMLINUX_H__

// Define BPF target types
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef unsigned long long __u64;
typedef __u32 __be32;
typedef __u16 __be16;
typedef int __s32;
typedef long __s64;
typedef __u32 __wsum;

// Ethernet header
struct ethhdr {
    __u8 h_dest[6];
    __u8 h_source[6];
    __be16 h_proto;
} __attribute__((packed));

// IPv4 header
struct iphdr {
    __u8 ihl:4;
    __u8 version:4;
    __u8 tos;
    __be16 tot_len;
    __be16 id;
    __be16 frag_off;
    __u8 ttl;
    __u8 protocol;
    __be16 check;
    __be32 saddr;
    __be32 daddr;
} __attribute__((packed));

// TCP header
struct tcphdr {
    __be16 source;
    __be16 dest;
    __be32 seq;
    __be32 ack_seq;
    __u16 res1:4;
    __u16 doff:4;
    __u16 fin:1;
    __u16 syn:1;
    __u16 rst:1;
    __u16 psh:1;
    __u16 ack:1;
    __u16 urg:1;
    __u16 res2:2;
    __be16 window;
    __be16 check;
    __be16 urg_ptr;
} __attribute__((packed));

// UDP header
struct udphdr {
    __be16 source;
    __be16 dest;
    __be16 len;
    __be16 check;
} __attribute__((packed));

// ICMP header
struct icmphdr {
    __u8 type;
    __u8 code;
    __be16 checksum;
    union {
        struct {
            __be16 id;
            __be16 sequence;
        } echo;
        __be32 gateway;
        struct {
            __be16 __unused;
            __be16 mtu;
        } frag;
        __u8 reserved[4];
    } un;
} __attribute__((packed));

// Ethernet protocol numbers
#define ETH_P_IP   0x0800
#define ETH_P_IPV6 0x86DD
#define ETH_P_ARP  0x0806

// TC action codes
#define TC_ACT_OK       0
#define TC_ACT_SHOT     2
#define TC_ACT_REDIRECT 7

// XDP action codes
#define XDP_PASS     2
#define XDP_DROP     1
#define XDP_TX       3
#define XDP_REDIRECT 4

// SKB metadata structure for TC programs
struct __sk_buff {
    __u32 len;
    __u32 pkt_type;
    __u32 mark;
    __u32 queue_mapping;
    __u32 protocol;
    __u32 vlan_present;
    __u32 vlan_tci;
    __u32 vlan_proto;
    __u16 priority;
    __u16 ingress_ifindex;
    __u32 ifindex;
    __u32 tc_index;
    __u32 cb[5];
    __u32 hash;
    __u32 tc_classid;
    __u32 data;
    __u32 data_end;
    __u32 napi_id;
    __u32 family;
    __u32 remote_ip4;
    __u32 local_ip4;
    __u32 remote_ip6[4];
    __u32 local_ip6[4];
    __u32 remote_port;
    __u32 local_port;
    __u32 data_meta;
    __u32 flow_keys;
    __u64 tstamp;
    __u32 wire_len;
    __u32 gso_segs;
    __u8 gso_size;
    __u8 hwtstamp;
    __u64 hwtstamp_data;
};

// XDP metadata structure
struct xdp_md {
    __u32 data;
    __u32 data_end;
    __u32 data_meta;
    __u32 ingress_ifindex;
    __u32 rx_queue_index;
    __u32 egress_ifindex;
};

// BPF map types
#define BPF_MAP_TYPE_UNSPEC           0
#define BPF_MAP_TYPE_HASH             1
#define BPF_MAP_TYPE_ARRAY            2
#define BPF_MAP_TYPE_PROG_ARRAY       3
#define BPF_MAP_TYPE_PERF_EVENT_ARRAY 4
#define BPF_MAP_TYPE_PERCPU_HASH      5
#define BPF_MAP_TYPE_PERCPU_ARRAY     6
#define BPF_MAP_TYPE_LRU_HASH         10
#define BPF_MAP_TYPE_LRU_PERCPU_HASH  11
#define BPF_MAP_TYPE_RINGBUF          27

// BPF map flags
#define BPF_ANY     0
#define BPF_NOEXIST 1
#define BPF_EXIST   2

// Map definition macros
#define __uint(name, val) int (*name)[val]
#define __type(name, val) typeof(val) *name
#define __array(name, val) typeof(val) *name[]

#endif /* __VMLINUX_H__ */
