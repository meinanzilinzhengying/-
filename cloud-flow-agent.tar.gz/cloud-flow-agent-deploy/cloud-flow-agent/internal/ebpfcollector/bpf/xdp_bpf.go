package bpf

import (
	"bytes"
	_ "embed"
	"fmt"

	"github.com/cilium/ebpf"
)

//go:generate go tool bpf2go -cc clang -cflags "-O2 -g -Wall -Werror -target bpf" xdp xdp.bpf.c

// XDP mode constants
const (
	XDPModeUnset = iota
	XDPModeDriver   // Native driver mode
	XDPModeSKB      // Generic SKB mode (works on all NICs)
	XDPModeOffload  // Hardware offload
)

// XDPObjects contains XDP eBPF objects
type XDPObjects struct {
	PktCountMap  *ebpf.Map     `ebpf:"pkt_count_map"`
	ByteCountMap *ebpf.Map     `ebpf:"byte_count_map"`
	XDPProg      *ebpf.Program `ebpf:"xdp_prog"`
	XDPDDoSProg  *ebpf.Program `ebpf:"xdp_ddos_prog"`
}

// LoadXDP loads XDP eBPF objects
func LoadXDP(opts *ebpf.CollectionOptions) (*XDPObjects, error) {
	spec, err := ebpf.LoadCollectionSpecFromReader(bytes.NewReader(BuiltInXDP))
	if err != nil {
		return nil, fmt.Errorf("parse XDP collection spec: %w", err)
	}

	var objs XDPObjects
	if err := spec.LoadAndAssign(&objs, opts); err != nil {
		return nil, fmt.Errorf("load XDP objects: %w", err)
	}

	return &objs, nil
}

func (o *XDPObjects) Close() {
	if o.PktCountMap != nil {
		o.PktCountMap.Close()
	}
	if o.ByteCountMap != nil {
		o.ByteCountMap.Close()
	}
	if o.XDPProg != nil {
		o.XDPProg.Close()
	}
	if o.XDPDDoSProg != nil {
		o.XDPDDoSProg.Close()
	}
}
