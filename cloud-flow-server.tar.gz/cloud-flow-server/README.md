# 云内流量监测系统 - Server 端（离线部署）

## 部署流程

### 第一步：在有网络的机器上准备离线镜像

```bash
cd cloud-flow-server
chmod +x prepare.sh start.sh stop.sh
./prepare.sh
```

此脚本会：
1. 拉取所有基础镜像（MySQL、Redis、Nginx、Node、Golang、Alpine）
2. 构建项目镜像（Center、Edge、Frontend）
3. 导出所有镜像为 tar 文件到 `images/` 目录

### 第二步：传输到离线服务器

将整个 `cloud-flow-server/` 目录传输到离线服务器（U盘、scp、内网传输等）

### 第三步：在离线服务器上一键启动

```bash
cd cloud-flow-server

# 修改配置（必须修改密钥和密码）
vi .env

# 一键启动（自动导入镜像 + 启动服务）
./start.sh
```

## 访问地址

| 服务 | 地址 |
|------|------|
| 前端页面 | http://<服务器IP>:8888 |
| Center API | http://<服务器IP>:9090 |
| Edge API | http://<服务器IP>:9091 |
| TiDB | <服务器IP>:4000（仅本地） |
| Redis | <服务器IP>:6379（仅本地） |

## 端口说明

| 端口 | 服务 |
|------|------|
| 8888 | 前端 (Nginx) |
| 9090 | Center HTTP API |
| 9999 | Center gRPC |
| 10001 | Edge gRPC (Agent 连接) |
| 10002 | Edge gRPC (Center 连接) |
| 9091 | Edge Health |
| 4000 | TiDB（仅本地） |
| 6379 | Redis（仅本地） |

## 常用命令

```bash
./start.sh                        # 启动服务
./stop.sh                         # 停止服务
docker compose logs -f center     # 查看 Center 日志
docker compose logs -f edge       # 查看 Edge 日志
docker compose logs -f frontend   # 查看前端日志
docker compose ps                  # 查看服务状态
```

## 前置要求

- Docker 20.10+
- Docker Compose v2+
- 至少 4GB 可用内存
- 至少 10GB 可用磁盘空间（含镜像）

## 离线安装 Docker（如目标机器无 Docker）

如果目标服务器完全没有 Docker，需要预先安装：

1. 下载 Docker 离线安装包：
   - https://download.docker.com/linux/static/stable/x86_64/
   - 下载 `docker-XX.XX.X-ce.tgz`

2. 传输到目标服务器后安装：
   ```bash
   tar xzf docker-XX.XX.X-ce.tgz
   sudo cp docker/* /usr/bin/
   sudo dockerd &
   ```

3. Docker Compose 插件：
   - 下载 `docker-compose-linux-x86_64`
   - `sudo cp docker-compose-linux-x86_64 /usr/local/bin/docker-compose`
   - `sudo chmod +x /usr/local/bin/docker-compose`
