package grpcserver

import (
	"context"
	"testing"
	"time"

	"cloud-flow-center/pkg/logger"
	edge "cloud-flow/proto"
)

// mockStorage 模拟存储引擎
type mockStorage struct {
}

func (m *mockStorage) SaveMetrics(probeID string, metrics interface{}) error {
	return nil
}

func (m *mockStorage) SaveTraces(probeID string, spans interface{}) error {
	return nil
}

func (m *mockStorage) SaveProfiling(probeID string, profiles interface{}) error {
	return nil
}

func (m *mockStorage) SaveProbeInfo(edgeNodeID string, data interface{}) error {
	return nil
}

func (m *mockStorage) QueryMetrics(day string, probeID string, limit int) ([]map[string]interface{}, error) {
	return []map[string]interface{}{}, nil
}

func (m *mockStorage) QueryMetricsByAlert(day string, metricName string, operator string, threshold float64, limit int) ([]map[string]interface{}, error) {
	return []map[string]interface{}{}, nil
}

func (m *mockStorage) QueryTraces(day string, probeID string, limit int) ([]map[string]interface{}, error) {
	return []map[string]interface{}{}, nil
}

func (m *mockStorage) GetRecentMetrics(metricType string, limit int, timeWindow time.Duration) ([]*edge.MetricData, error) {
	return []*edge.MetricData{}, nil
}

func (m *mockStorage) GetOverview() (map[string]interface{}, error) {
	return map[string]interface{}{}, nil
}

func (m *mockStorage) GetNodes() ([]map[string]interface{}, error) {
	return []map[string]interface{}{}, nil
}

func (m *mockStorage) CreateUser(username, password, role string) error {
	return nil
}

func (m *mockStorage) GetUser(username string) (map[string]interface{}, error) {
	return map[string]interface{}{}, nil
}

func (m *mockStorage) UpdateUser(username, password, role string) error {
	return nil
}

func (m *mockStorage) DeleteUser(username string) error {
	return nil
}

func (m *mockStorage) UpdateUserRole(username, role string) error {
	return nil
}

func (m *mockStorage) ListUsers() ([]map[string]interface{}, error) {
	return []map[string]interface{}{}, nil
}

func (m *mockStorage) VerifyUser(username, password string) (bool, string, error) {
	return true, "admin", nil
}

func (m *mockStorage) StartCleanup() {}

func (m *mockStorage) Stop() {}

func (m *mockStorage) DB() interface{} {
	return nil
}

func TestServerReportProbes(t *testing.T) {
	// 创建测试日志器
	log := logger.New(logger.Config{Level: "error", Format: "console"})

	// 创建存储引擎
	store := &mockStorage{}

	// 创建服务器
	srv := NewServer(store, log, "test-api-key")

	// 创建请求
	req := &edge.ReportProbesRequest{
		EdgeNodeId:    "test-edge",
		CloudPlatform: "aws",
		Region:        "us-west-2",
		Probes: []*edge.ProbeInfo{
			{
				ProbeId:       "probe-1",
				HostIp:        "10.0.0.1",
				Hostname:      "host-1",
				Status:        "online",
				Version:       "1.0.0",
				LastHeartbeat: time.Now().Unix(),
			},
		},
	}

	// 测试报告探针
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	resp, err := srv.ReportProbes(ctx, req)
	if err != nil {
		t.Errorf("报告探针失败: %v", err)
	}

	if !resp.Success {
		t.Errorf("报告探针失败，响应: %v", resp)
	}
}

func TestServerForwardMetrics(t *testing.T) {
	// 创建测试日志器
	log := logger.New(logger.Config{Level: "error", Format: "console"})

	// 创建存储引擎
	store := &mockStorage{}

	// 创建服务器
	srv := NewServer(store, log, "test-api-key")

	// 创建请求
	batch := &edge.MetricsBatch{
		ProbeId: "test-probe",
		Metrics: []*edge.MetricData{
			{
				Timestamp: time.Now().Unix(),
				SrcIp:     "10.0.0.1",
				DstIp:     "10.0.0.2",
				Protocol:  "tcp",
				Bytes:     1024,
				Packets:   10,
			},
		},
	}

	// 测试转发指标
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	resp, err := srv.ForwardMetrics(ctx, batch)
	if err != nil {
		t.Errorf("转发指标失败: %v", err)
	}

	if !resp.Success {
		t.Errorf("转发指标失败，响应: %v", resp)
	}
}

func TestServerHeartbeat(t *testing.T) {
	// 创建测试日志器
	log := logger.New(logger.Config{Level: "error", Format: "console"})

	// 创建存储引擎
	store := &mockStorage{}

	// 创建服务器
	srv := NewServer(store, log, "test-api-key")

	// 创建请求
	req := &edge.EdgeHeartbeatRequest{
		EdgeNodeId:    "test-edge",
		CloudPlatform: "aws",
		Region:        "us-west-2",
		Timestamp:     time.Now().Unix(),
		ProbeCount:    1,
	}

	// 测试心跳
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	resp, err := srv.Heartbeat(ctx, req)
	if err != nil {
		t.Errorf("心跳失败: %v", err)
	}

	if !resp.Success {
		t.Errorf("心跳失败，响应: %v", resp)
	}
}
