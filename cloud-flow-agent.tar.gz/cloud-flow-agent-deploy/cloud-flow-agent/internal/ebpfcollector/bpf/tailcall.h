// SPDX-License-Identifier: GPL-2.0
#ifndef __TAILCALL_H__
#define __TAILCALL_H__

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>

// Tail call indices
#define TAIL_CALL_IPV4_PROCESS    0
#define TAIL_CALL_IPV6_PROCESS    1
#define TAIL_CALL_TCP_PROCESS     2
#define TAIL_CALL_UDP_PROCESS     3
#define TAIL_CALL_ICMP_PROCESS    4
#define TAIL_CALL_CT_LOOKUP       5
#define TAIL_CALL_POLICY_CHECK    6
#define TAIL_CALL_MAX             16

// Tail call map - programs can call each other
struct {
    __uint(type, BPF_MAP_TYPE_PROG_ARRAY);
    __uint(max_entries, TAIL_CALL_MAX);
    __type(key, __u32);
    __type(value, __u32);
} tail_calls SEC(".maps");

// Tail call helper
#define tail_call_ipv4(ctx)  bpf_tail_call(ctx, &tail_calls, TAIL_CALL_IPV4_PROCESS)
#define tail_call_tcp(ctx)   bpf_tail_call(ctx, &tail_calls, TAIL_CALL_TCP_PROCESS)
#define tail_call_udp(ctx)   bpf_tail_call(ctx, &tail_calls, TAIL_CALL_UDP_PROCESS)
#define tail_call_icmp(ctx)  bpf_tail_call(ctx, &tail_calls, TAIL_CALL_ICMP_PROCESS)
#define tail_call_ct(ctx)    bpf_tail_call(ctx, &tail_calls, TAIL_CALL_CT_LOOKUP)

#endif
