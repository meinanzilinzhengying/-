package ebpfcollector

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/cilium/ebpf"
)

const (
	// DefaultBPFFSPath is the default mount point for bpffs
	DefaultBPFFSPath = "/sys/fs/bpf"
	// MapSubdir is the subdirectory for cloud-flow maps
	MapSubdir = "cloud-flow"
)

// PinManager handles eBPF map pinning operations
type PinManager struct {
	basePath string
	pinned   map[string]string // map name -> pin path
}

// NewPinManager creates a new pin manager
func NewPinManager(basePath string) *PinManager {
	if basePath == "" {
		basePath = DefaultBPFFSPath
	}
	return &PinManager{
		basePath: filepath.Join(basePath, MapSubdir),
		pinned:   make(map[string]string),
	}
}

// EnsureDir creates the pin directory if it doesn't exist
func (pm *PinManager) EnsureDir() error {
	if err := os.MkdirAll(pm.basePath, 0755); err != nil {
		return fmt.Errorf("create pin directory: %w", err)
	}
	return nil
}

// PinMap pins a map to bpffs
func (pm *PinManager) PinMap(name string, m *ebpf.Map) error {
	if err := pm.EnsureDir(); err != nil {
		return err
	}

	pinPath := filepath.Join(pm.basePath, name)

	// Check if already pinned
	if _, err := os.Stat(pinPath); err == nil {
		// Load existing pinned map
		existing, err := ebpf.LoadPinnedMap(pinPath, nil)
		if err != nil {
			// Remove stale pin
			os.Remove(pinPath)
		} else {
			existing.Close()
			// Unpin and re-pin with new map
			if err := m.Pin(pinPath); err != nil {
				return fmt.Errorf("pin map %s: %w", name, err)
			}
		}
	} else {
		// New pin
		if err := m.Pin(pinPath); err != nil {
			return fmt.Errorf("pin map %s: %w", name, err)
		}
	}

	pm.pinned[name] = pinPath
	return nil
}

// UnpinMap removes a map pin
func (pm *PinManager) UnpinMap(name string) error {
	pinPath, ok := pm.pinned[name]
	if !ok {
		pinPath = filepath.Join(pm.basePath, name)
	}

	if _, err := os.Stat(pinPath); err != nil {
		return nil // Not pinned
	}

	if err := os.Remove(pinPath); err != nil {
		return fmt.Errorf("unpin map %s: %w", name, err)
	}

	delete(pm.pinned, name)
	return nil
}

// UnpinAll removes all pinned maps
func (pm *PinManager) UnpinAll() error {
	for name := range pm.pinned {
		if err := pm.UnpinMap(name); err != nil {
			return err
		}
	}
	return nil
}

// LoadPinnedMap loads a previously pinned map
func (pm *PinManager) LoadPinnedMap(name string) (*ebpf.Map, error) {
	pinPath := filepath.Join(pm.basePath, name)

	m, err := ebpf.LoadPinnedMap(pinPath, nil)
	if err != nil {
		return nil, fmt.Errorf("load pinned map %s: %w", name, err)
	}

	pm.pinned[name] = pinPath
	return m, nil
}

// GetPinPath returns the pin path for a map
func (pm *PinManager) GetPinPath(name string) string {
	return filepath.Join(pm.basePath, name)
}

// IsPinned checks if a map is pinned
func (pm *PinManager) IsPinned(name string) bool {
	pinPath := filepath.Join(pm.basePath, name)
	_, err := os.Stat(pinPath)
	return err == nil
}

// Cleanup removes all cloud-flow pins (use with caution!)
func (pm *PinManager) Cleanup() error {
	return os.RemoveAll(pm.basePath)
}
