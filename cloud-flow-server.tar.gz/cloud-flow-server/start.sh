#!/bin/bash
set -e

# =============================================================================
# 云内流量监测系统 - Server 端离线一键启动脚本
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo "============================================"
echo "  云内流量监测系统 - Server 端（离线部署）"
echo "============================================"
echo ""

# ── 1. 检查 Docker ──
echo -e "${YELLOW}[1/6] 检查 Docker 环境...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}错误: 未安装 Docker${NC}"
    echo "  离线安装 Docker 请参考: https://docs.docker.com/engine/install/#server"
    exit 1
fi
if ! docker info &> /dev/null; then
    echo -e "${RED}错误: Docker 服务未运行${NC}"
    exit 1
fi
if ! docker compose version &> /dev/null 2>&1; then
    if ! command -v docker-compose &> /dev/null; then
        echo -e "${RED}错误: 未安装 Docker Compose${NC}"
        exit 1
    fi
fi
echo -e "${GREEN}  ✓ Docker 环境正常${NC}"

# ── 2. 检查配置 ──
echo -e "${YELLOW}[2/6] 检查配置文件...${NC}"
if [ ! -f .env ]; then
    echo -e "${RED}错误: 缺少 .env 配置文件${NC}"
    echo "  请执行: cp .env.example .env 并修改配置"
    exit 1
fi
if grep -q "change-me\|change_in_production" .env 2>/dev/null; then
    echo -e "${YELLOW}  ⚠ 警告: 检测到默认密钥，请在 .env 中修改${NC}"
fi
echo -e "${GREEN}  ✓ 配置文件就绪${NC}"

# ── 3. 导入离线镜像 ──
echo -e "${YELLOW}[3/6] 导入离线 Docker 镜像...${NC}"
IMAGES_DIR="$SCRIPT_DIR/images"
LOADED=0
OFFLINE_MODE=false
if [ -d "$IMAGES_DIR" ] && ls "$IMAGES_DIR"/*.tar 1> /dev/null 2>&1; then
    OFFLINE_MODE=true
    for img_tar in "$IMAGES_DIR"/*.tar; do
        img_name=$(basename "$img_tar" .tar)
        echo -e "  ${CYAN}导入: $img_name${NC}"
        docker load -i "$img_tar" 2>&1 || true
        LOADED=$((LOADED + 1))
    done
    echo -e "${GREEN}  ✓ 已导入 $LOADED 个镜像（离线模式）${NC}"
else
    echo -e "${YELLOW}  ⚠ 未找到离线镜像文件（images/*.tar）${NC}"
    echo -e "${YELLOW}    将尝试在线构建，如果服务器无网络则会失败${NC}"
    echo -e "${YELLOW}    建议在有网络的机器上先运行 prepare.sh 生成离线镜像${NC}"
fi

# ── 4. 检查端口 ──
echo -e "${YELLOW}[4/6] 检查端口...${NC}"
PORTS=(8888 9090 9999 10001 10002)
for port in "${PORTS[@]}"; do
    if command -v ss &> /dev/null; then
        if ss -tlnp 2>/dev/null | grep -q ":${port} "; then
            echo -e "${YELLOW}  ⚠ 端口 $port 已被占用${NC}"
        fi
    elif command -v netstat &> /dev/null; then
        if netstat -tlnp 2>/dev/null | grep -q ":${port} "; then
            echo -e "${YELLOW}  ⚠ 端口 $port 已被占用${NC}"
        fi
    fi
done
echo -e "${GREEN}  ✓ 端口检查完成${NC}"

# ── 5. 启动服务 ──
echo -e "${YELLOW}[5/6] 启动服务...${NC}"
COMPOSE_CMD="docker compose"
if ! docker compose version &> /dev/null 2>&1; then
    COMPOSE_CMD="docker-compose"
fi

if [ "$OFFLINE_MODE" = true ]; then
    echo -e "  ${CYAN}离线模式: 跳过构建，直接使用预构建镜像${NC}"
    $COMPOSE_CMD up -d --no-build 2>&1
else
    $COMPOSE_CMD up -d --build 2>&1
fi
echo -e "${GREEN}  ✓ 服务启动完成${NC}"

# ── 6. 等待就绪 ──
echo -e "${YELLOW}[6/6] 等待服务就绪...${NC}"
sleep 8

echo ""
$COMPOSE_CMD ps 2>&1

echo ""
echo "============================================"
echo -e "  ${GREEN}部署完成！${NC}"
echo "============================================"
echo ""
echo -e "  前端页面:    ${GREEN}http://<服务器IP>:8888${NC}"
echo -e "  Center API:  ${GREEN}http://<服务器IP>:9090${NC}"
echo -e "  Edge API:    ${GREEN}http://<服务器IP>:9091${NC}"
echo ""
echo "  默认管理员: admin / (见 .env 中 CLOUD_FLOW_ADMIN_PASSWORD)"
echo ""
echo "  查看日志: $COMPOSE_CMD logs -f"
echo "  停止服务: ./stop.sh"
echo "============================================"
