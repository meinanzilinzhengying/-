package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

// CollectorMetrics holds all metrics for the collector
type CollectorMetrics struct {
	// Collection metrics
	CollectTotal    prometheus.Counter
	CollectErrors   prometheus.Counter
	CollectDuration prometheus.Histogram
	CollectBytes    prometheus.Counter
	CollectPackets  prometheus.Counter

	// eBPF metrics
	EBPFCollectTotal  prometheus.Counter
	EBPFCollectErrors prometheus.Counter
	EBPFMapSize       prometheus.Gauge
	EBPFEventsTotal   prometheus.Counter
	EBPFEventsDropped prometheus.Counter

	// gRPC metrics
	GRPCRequestsTotal    *prometheus.CounterVec
	GRPCRequestDuration  *prometheus.HistogramVec
	GRPCConnections      prometheus.Gauge
	GRPCConnectionErrors prometheus.Counter

	// System metrics
	Goroutines    prometheus.Gauge
	MemoryAllocMB prometheus.Gauge
	MemorySysMB   prometheus.Gauge
	CPUPercent    prometheus.Gauge
}

// NewCollectorMetrics creates new metrics
func NewCollectorMetrics(namespace string) *CollectorMetrics {
	return &CollectorMetrics{
		CollectTotal: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "collect_total",
			Help:      "Total number of collection cycles",
		}),
		CollectErrors: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "collect_errors_total",
			Help:      "Total number of collection errors",
		}),
		CollectDuration: promauto.NewHistogram(prometheus.HistogramOpts{
			Namespace: namespace,
			Name:      "collect_duration_seconds",
			Help:      "Duration of collection cycles",
			Buckets:   prometheus.ExponentialBuckets(0.001, 2, 15),
		}),
		CollectBytes: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "collect_bytes_total",
			Help:      "Total bytes collected",
		}),
		CollectPackets: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "collect_packets_total",
			Help:      "Total packets collected",
		}),
		EBPFCollectTotal: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "ebpf_collect_total",
			Help:      "Total eBPF collection cycles",
		}),
		EBPFCollectErrors: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "ebpf_collect_errors_total",
			Help:      "Total eBPF collection errors",
		}),
		EBPFMapSize: promauto.NewGauge(prometheus.GaugeOpts{
			Namespace: namespace,
			Name:      "ebpf_map_size",
			Help:      "Current size of eBPF maps",
		}),
		EBPFEventsTotal: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "ebpf_events_total",
			Help:      "Total eBPF events processed",
		}),
		EBPFEventsDropped: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "ebpf_events_dropped_total",
			Help:      "Total eBPF events dropped",
		}),
		GRPCRequestsTotal: promauto.NewCounterVec(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "grpc_requests_total",
			Help:      "Total gRPC requests",
		}, []string{"method", "status"}),
		GRPCRequestDuration: promauto.NewHistogramVec(prometheus.HistogramOpts{
			Namespace: namespace,
			Name:      "grpc_request_duration_seconds",
			Help:      "Duration of gRPC requests",
			Buckets:   prometheus.ExponentialBuckets(0.001, 2, 15),
		}, []string{"method"}),
		GRPCConnections: promauto.NewGauge(prometheus.GaugeOpts{
			Namespace: namespace,
			Name:      "grpc_connections",
			Help:      "Current number of gRPC connections",
		}),
		GRPCConnectionErrors: promauto.NewCounter(prometheus.CounterOpts{
			Namespace: namespace,
			Name:      "grpc_connection_errors_total",
			Help:      "Total gRPC connection errors",
		}),
		Goroutines: promauto.NewGauge(prometheus.GaugeOpts{
			Namespace: namespace,
			Name:      "goroutines",
			Help:      "Current number of goroutines",
		}),
		MemoryAllocMB: promauto.NewGauge(prometheus.GaugeOpts{
			Namespace: namespace,
			Name:      "memory_alloc_mb",
			Help:      "Currently allocated memory in MB",
		}),
		MemorySysMB: promauto.NewGauge(prometheus.GaugeOpts{
			Namespace: namespace,
			Name:      "memory_sys_mb",
			Help:      "Total memory obtained from OS in MB",
		}),
		CPUPercent: promauto.NewGauge(prometheus.GaugeOpts{
			Namespace: namespace,
			Name:      "cpu_percent",
			Help:      "CPU usage percentage",
		}),
	}
}

// RecordCollect records a collection cycle
func (m *CollectorMetrics) RecordCollect(err error, duration float64, bytes, packets int64) {
	m.CollectTotal.Inc()
	m.CollectDuration.Observe(duration)
	m.CollectBytes.Add(float64(bytes))
	m.CollectPackets.Add(float64(packets))
	if err != nil {
		m.CollectErrors.Inc()
	}
}

// RecordEBPF records eBPF collection
func (m *CollectorMetrics) RecordEBPF(err error) {
	m.EBPFCollectTotal.Inc()
	if err != nil {
		m.EBPFCollectErrors.Inc()
	}
}

// RecordGRPC records a gRPC request
func (m *CollectorMetrics) RecordGRPC(method string, status string, duration float64) {
	m.GRPCRequestsTotal.WithLabelValues(method, status).Inc()
	m.GRPCRequestDuration.WithLabelValues(method).Observe(duration)
}
