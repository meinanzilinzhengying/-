import { apiRequest } from './index';

export const businessApi = {
  getBusinesses: (params?: {
    page?: number;
    pageSize?: number;
    status?: string;
  }) => {
    const queryParams = new URLSearchParams();
    if (params) {
      if (params.page) queryParams.append('page', params.page.toString());
      if (params.pageSize) queryParams.append('page_size', params.pageSize.toString());
      if (params.status) queryParams.append('status', params.status);
    }
    const query = queryParams.toString();
    return apiRequest(`/business${query ? `?${query}` : ''}`);
  },

  getBusinessDetail: (id: string) => apiRequest(`/business/${id}`),

  createBusiness: (data: Record<string, unknown>) => apiRequest('/business', {
    method: 'POST',
    body: data,
  }),

  updateBusiness: (id: string, data: Record<string, unknown>) => apiRequest(`/business/${id}`, {
    method: 'PUT',
    body: data,
  }),

  deleteBusiness: (id: string) => apiRequest(`/business/${id}`, {
    method: 'DELETE',
  }),
};

export const serviceApi = {
  getServices: (params?: {
    page?: number;
    pageSize?: number;
    businessId?: string;
    status?: string;
  }) => {
    const queryParams = new URLSearchParams();
    if (params) {
      if (params.page) queryParams.append('page', params.page.toString());
      if (params.pageSize) queryParams.append('page_size', params.pageSize.toString());
      if (params.businessId) queryParams.append('business_id', params.businessId);
      if (params.status) queryParams.append('status', params.status);
    }
    const query = queryParams.toString();
    return apiRequest(`/service${query ? `?${query}` : ''}`);
  },

  getServiceDetail: (id: string) => apiRequest(`/service/${id}`),

  createService: (data: Record<string, unknown>) => apiRequest('/service', {
    method: 'POST',
    body: data,
  }),

  updateService: (id: string, data: Record<string, unknown>) => apiRequest(`/service/${id}`, {
    method: 'PUT',
    body: data,
  }),

  deleteService: (id: string) => apiRequest(`/service/${id}`, {
    method: 'DELETE',
  }),
};
