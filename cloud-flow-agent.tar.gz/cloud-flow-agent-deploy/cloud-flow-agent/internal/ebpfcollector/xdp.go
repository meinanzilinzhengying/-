package ebpfcollector

import (
	"fmt"
	"log"
	"net"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"

	"cloud-flow-agent/internal/ebpfcollector/bpf"
)

// XDPCollector manages XDP program attachment
type XDPCollector struct {
	objs   *bpf.XDPObjects
	links  []link.Link
	ifaces []string
}

// NewXDP creates an XDP collector
func NewXDP(ifaces []string, mode int) (*XDPCollector, error) {
	objs, err := bpf.LoadXDP(nil)
	if err != nil {
		return nil, fmt.Errorf("load XDP objects: %w", err)
	}

	links := make([]link.Link, 0)
	attached := make([]string, 0)

	for _, ifaceName := range ifaces {
		iface, err := net.InterfaceByName(ifaceName)
		if err != nil {
			log.Printf("Warning: interface %s not found: %v", ifaceName, err)
			continue
		}

		// Determine XDP flags based on mode
		var flags link.XDPFlags
		switch mode {
		case bpf.XDPModeDriver:
			flags = link.XDPDriverMode
		case bpf.XDPModeSKB:
			flags = link.XDPGenericMode
		case bpf.XDPModeOffload:
			flags = link.XDPOffloadMode
		default:
			// Auto-detect: try driver mode first, fall back to SKB
			flags = link.XDPDriverMode
		}

		l, err := link.AttachXDP(link.XDPOptions{
			Program:   objs.XDPProg,
			Interface: iface.Index,
			Flags:     flags,
		})
		if err != nil {
			if flags == link.XDPDriverMode {
				// Fall back to SKB mode
				log.Printf("XDP driver mode failed for %s, trying SKB mode: %v", ifaceName, err)
				l, err = link.AttachXDP(link.XDPOptions{
					Program:   objs.XDPProg,
					Interface: iface.Index,
					Flags:     link.XDPGenericMode,
				})
			}
			if err != nil {
				log.Printf("Warning: failed to attach XDP to %s: %v", ifaceName, err)
				continue
			}
		}

		links = append(links, l)
		attached = append(attached, ifaceName)
		log.Printf("XDP program attached to %s", ifaceName)
	}

	if len(links) == 0 {
		objs.Close()
		return nil, fmt.Errorf("failed to attach XDP to any interface")
	}

	return &XDPCollector{
		objs:   objs,
		links:  links,
		ifaces: attached,
	}, nil
}

// Stop detaches XDP programs
func (x *XDPCollector) Stop() {
	for _, l := range x.links {
		if l != nil {
			l.Close()
		}
	}
	x.objs.Close()
}

// GetInterfaces returns attached interfaces
func (x *XDPCollector) GetInterfaces() []string {
	return x.ifaces
}

// GetMaps returns XDP maps for external access
func (x *XDPCollector) GetMaps() (pktCount, byteCount *ebpf.Map) {
	return x.objs.PktCountMap, x.objs.ByteCountMap
}
