// SPDX-License-Identifier: GPL-2.0
// Copyright (c) 2024 Cloud Flow Agent Contributors
//
// XDP program for high-performance packet filtering and early drop
// Runs at network driver level before skb allocation

#include "vmlinux.h"
#include "common.h"
#include "maps.h"
#include "core.h"

// XDP program for early packet processing
// Returns XDP_PASS to allow packet, XDP_DROP to block
SEC("xdp")
int xdp_prog(struct xdp_md *ctx) {
    void *data = (void *)(unsigned long)ctx->data;
    void *data_end = (void *)(unsigned long)ctx->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip;
    
    // Ethernet header check
    if (data + sizeof(*eth) > data_end)
        return XDP_PASS;  // Malformed, let kernel handle
    
    // Only process IPv4
    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return XDP_PASS;
    
    // IP header check
    ip = data + sizeof(*eth);
    if ((void *)ip + sizeof(*ip) > data_end)
        return XDP_PASS;
    
    // Skip fragments (only handle first fragment)
    if (ip->frag_off & bpf_htons(0x1FFF))
        return XDP_PASS;
    
    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u8 protocol = ip->protocol;
    __u32 data_len = bpf_ntohs(ip->tot_len);
    
    // Calculate flow hash for statistics
    __u32 flow_hash = hash_flow(src_ip, dst_ip, 0, 0, protocol);
    
    // Update PERCPU counters (no lock contention)
    __u64 *pkt_count = bpf_map_lookup_elem(&pkt_count_map, &flow_hash);
    if (pkt_count) {
        (*pkt_count)++;
    } else {
        __u64 init_count = 1;
        bpf_map_update_elem(&pkt_count_map, &flow_hash, &init_count, BPF_ANY);
    }
    
    __u64 *byte_count = bpf_map_lookup_elem(&byte_count_map, &flow_hash);
    if (byte_count) {
        (*byte_count) += data_len;
    } else {
        bpf_map_update_elem(&byte_count_map, &flow_hash, &data_len, BPF_ANY);
    }
    
    // All packets pass through - XDP is for fast statistics only
    // Actual filtering/CT happens in TC layer
    return XDP_PASS;
}

// XDP program with DDoS protection capability
SEC("xdp/ddos")
int xdp_ddos_prog(struct xdp_md *ctx) {
    void *data = (void *)(unsigned long)ctx->data;
    void *data_end = (void *)(unsigned long)ctx->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip;
    
    if (data + sizeof(*eth) > data_end)
        return XDP_PASS;
    
    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return XDP_PASS;
    
    ip = data + sizeof(*eth);
    if ((void *)ip + sizeof(*ip) > data_end)
        return XDP_PASS;
    
    // Check if source IP is in blocklist (could be implemented with LPM trie)
    // For now, just pass through
    __u32 src_ip = ip->saddr;
    
    // Rate limiting per source IP (simple token bucket)
    __u64 now = bpf_ktime_get_ns();
    __u64 *last_seen = bpf_map_lookup_elem(&pkt_count_map, &src_ip);
    
    if (last_seen) {
        // Check rate (simplified - should use proper token bucket)
        __u64 elapsed = now - *last_seen;
        if (elapsed < 1000000) {  // Less than 1ms between packets
            // Potential flood - could drop here
            // For now, just count
        }
    }
    
    // Update last seen
    bpf_map_update_elem(&pkt_count_map, &src_ip, &now, BPF_ANY);
    
    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
