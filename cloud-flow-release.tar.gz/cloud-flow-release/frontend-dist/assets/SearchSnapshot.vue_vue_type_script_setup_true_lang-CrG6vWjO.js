import{B as e}from"./vue-vendor-D1ZgoZLN.js";const p=e({__name:"SearchSnapshot",setup(n){return()=>{}}});export{p as _};
