package ebpfcollector

import (
	"os"
	"path/filepath"
	"testing"
)

func TestPinManager_EnsureDir(t *testing.T) {
	// Use temp directory for testing
	tmpDir := t.TempDir()
	pm := NewPinManager(tmpDir)

	if err := pm.EnsureDir(); err != nil {
		t.Fatalf("EnsureDir failed: %v", err)
	}

	// Check directory exists
	expectedPath := filepath.Join(tmpDir, MapSubdir)
	if _, err := os.Stat(expectedPath); os.IsNotExist(err) {
		t.Errorf("Directory %s was not created", expectedPath)
	}
}

func TestPinManager_GetPinPath(t *testing.T) {
	pm := NewPinManager("/sys/fs/bpf")
	expected := "/sys/fs/bpf/cloud-flow/test_map"

	if path := pm.GetPinPath("test_map"); path != expected {
		t.Errorf("GetPinPath = %q, want %q", path, expected)
	}
}

func TestPinManager_IsPinned(t *testing.T) {
	tmpDir := t.TempDir()
	pm := NewPinManager(tmpDir)

	// Should not be pinned initially
	if pm.IsPinned("nonexistent") {
		t.Error("IsPinned should return false for nonexistent map")
	}

	// Create a fake pin file
	pm.EnsureDir()
	pinPath := pm.GetPinPath("test_map")
	if err := os.WriteFile(pinPath, []byte{}, 0644); err != nil {
		t.Fatalf("Failed to create fake pin file: %v", err)
	}

	if !pm.IsPinned("test_map") {
		t.Error("IsPinned should return true for existing pin")
	}
}

func TestPinManager_NewPinManager(t *testing.T) {
	// Test with empty path (should use default)
	pm := NewPinManager("")
	if pm.basePath != "/sys/fs/bpf/cloud-flow" {
		t.Errorf("basePath = %q, want %q", pm.basePath, "/sys/fs/bpf/cloud-flow")
	}

	// Test with custom path
	pm = NewPinManager("/custom/path")
	if pm.basePath != "/custom/path/cloud-flow" {
		t.Errorf("basePath = %q, want %q", pm.basePath, "/custom/path/cloud-flow")
	}
}

func TestPinManager_UnpinMap(t *testing.T) {
	tmpDir := t.TempDir()
	pm := NewPinManager(tmpDir)
	pm.EnsureDir()

	// Create a fake pin file
	pinPath := pm.GetPinPath("test_map")
	if err := os.WriteFile(pinPath, []byte{}, 0644); err != nil {
		t.Fatalf("Failed to create fake pin file: %v", err)
	}

	// Unpin should remove the file
	if err := pm.UnpinMap("test_map"); err != nil {
		t.Fatalf("UnpinMap failed: %v", err)
	}

	if pm.IsPinned("test_map") {
		t.Error("Map should not be pinned after UnpinMap")
	}

	// Unpinning non-existent map should not error
	if err := pm.UnpinMap("nonexistent"); err != nil {
		t.Errorf("UnpinMap on nonexistent map should not error: %v", err)
	}
}

func TestPinManager_Cleanup(t *testing.T) {
	tmpDir := t.TempDir()
	pm := NewPinManager(tmpDir)
	pm.EnsureDir()

	// Create some fake pin files
	for _, name := range []string{"map1", "map2", "map3"} {
		pinPath := pm.GetPinPath(name)
		if err := os.WriteFile(pinPath, []byte{}, 0644); err != nil {
			t.Fatalf("Failed to create fake pin file %s: %v", name, err)
		}
	}

	// Cleanup should remove all
	if err := pm.Cleanup(); err != nil {
		t.Fatalf("Cleanup failed: %v", err)
	}

	if _, err := os.Stat(pm.basePath); !os.IsNotExist(err) {
		t.Error("Cleanup should remove the base directory")
	}
}
