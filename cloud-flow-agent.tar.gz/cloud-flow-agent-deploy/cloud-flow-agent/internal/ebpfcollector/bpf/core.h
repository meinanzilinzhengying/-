// SPDX-License-Identifier: GPL-2.0
#ifndef __CORE_H__
#define __CORE_H__

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>

// CO-RE feature detection macros

// Feature detection helpers
struct feature_flags {
    __u8 has_ringbuf;      // BPF_MAP_TYPE_RINGBUF supported
    __u8 has_percpu_hash;  // BPF_MAP_TYPE_PERCPU_HASH supported
    __u8 has_lru_hash;     // BPF_MAP_TYPE_LRU_HASH supported
    __u8 has_xdp;          // XDP supported
    __u8 has_tc;           // TC BPF supported
    __u8 has_sockops;      // BPF_PROG_TYPE_SOCK_OPS supported
    __u8 has_cgroup_skb;   // BPF_PROG_TYPE_CGROUP_SKB supported
    __u8 has_btf;          // BTF available
};

// Direct field access for minimal vmlinux.h
// In production, use BPF_CORE_READ for CO-RE compatibility
static __always_inline __u32 core_skb_len(struct __sk_buff *skb)
{
    return skb->len;
}

static __always_inline void *core_skb_data(struct __sk_buff *skb)
{
    return (void *)(unsigned long)skb->data;
}

static __always_inline void *core_skb_data_end(struct __sk_buff *skb)
{
    return (void *)(unsigned long)skb->data_end;
}

// XDP equivalents
static __always_inline void *core_xdp_data(struct xdp_md *ctx)
{
    return (void *)(unsigned long)ctx->data;
}

static __always_inline void *core_xdp_data_end(struct xdp_md *ctx)
{
    return (void *)(unsigned long)ctx->data_end;
}

#endif /* __CORE_H__ */
