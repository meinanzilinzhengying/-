package bpf

import (
	"bytes"
	_ "embed"
	"fmt"

	"github.com/cilium/ebpf"
)

//go:generate go tool bpf2go -cc clang -cflags "-O2 -g -Wall -Werror -target bpf" tc tc.bpf.c

// CT state constants
const (
	CTNew         = 0
	CTEstablished = 1
	CTRelated     = 2
	CTReply       = 3
	CTInvalid     = 4
)

// TCP state constants
const (
	TCPStateNone         = 0
	TCPStateSynSent      = 1
	TCPStateSynRecv      = 2
	TCPStateEstablished  = 3
	TCPStateFinWait      = 4
	TCPStateCloseWait    = 5
	TCPStateLastAck      = 6
	TCPStateTimeWait     = 7
	TCPStateClose        = 8
)

// FlowEvent represents a flow event from Ring Buffer
type FlowEvent struct {
	SrcIP     uint32 `json:"src_ip"`
	DstIP     uint32 `json:"dst_ip"`
	SrcPort   uint16 `json:"src_port"`
	DstPort   uint16 `json:"dst_port"`
	Protocol  uint8  `json:"protocol"`
	EventType uint8  `json:"event_type"`
	CTState   uint8  `json:"ct_state"`
	TCPState  uint8  `json:"tcp_state"`
	Bytes     uint64 `json:"bytes"`
	Packets   uint64 `json:"packets"`
	Timestamp uint64 `json:"timestamp"`
	CpuID     uint32 `json:"cpu_id"`
	Lifetime  uint32 `json:"lifetime"`
}

// CTKey represents a connection tracking lookup key
type CTKey struct {
	Saddr    uint32 `json:"saddr"`
	Daddr    uint32 `json:"daddr"`
	Sport    uint16 `json:"sport"`
	Dport    uint16 `json:"dport"`
	Protocol uint8  `json:"protocol"`
	Pad      [3]uint8 `json:"-"`
}

// CTEntry represents a connection tracking entry
type CTEntry struct {
	RxPackets uint64 `json:"rx_packets"`
	TxPackets uint64 `json:"tx_packets"`
	RxBytes   uint64 `json:"rx_bytes"`
	TxBytes   uint64 `json:"tx_bytes"`
	LastSeen  uint64 `json:"last_seen"`
	Lifetime  uint32 `json:"lifetime"`
	State     uint8  `json:"state"`
	TCPState  uint8  `json:"tcp_state"`
	SeenFlags uint8  `json:"seen_flags"`
	Pad       uint8  `json:"-"`
}

// Config represents eBPF configuration
type Config struct {
	SamplingRate  uint32 `json:"sampling_rate"`
	MaxFlows      uint32 `json:"max_flows"`
	EnableRingbuf uint32 `json:"enable_ringbuf"`
	TCPTimeout    uint32 `json:"tcp_timeout"`
	UDPTimeout    uint32 `json:"udp_timeout"`
	ICMPTimeout   uint32 `json:"icmp_timeout"`
}

// Objects contains all eBPF objects
type Objects struct {
	Events       *ebpf.Map     `ebpf:"events"`
	CtMap        *ebpf.Map     `ebpf:"ct_map"`
	CtReverseMap *ebpf.Map     `ebpf:"ct_reverse_map"`
	PktCountMap  *ebpf.Map     `ebpf:"pkt_count_map"`
	ByteCountMap *ebpf.Map     `ebpf:"byte_count_map"`
	ConfigMap    *ebpf.Map     `ebpf:"config_map"`
	TCProg       *ebpf.Program `ebpf:"tc_prog"`
}

// Load loads embedded eBPF ELF and creates all objects
func Load(opts *ebpf.CollectionOptions) (*Objects, error) {
	spec, err := ebpf.LoadCollectionSpecFromReader(bytes.NewReader(BuiltInBPF))
	if err != nil {
		return nil, fmt.Errorf("parse eBPF collection spec: %w", err)
	}

	// Default options if none provided
	if opts == nil {
		opts = &ebpf.CollectionOptions{
			Maps: ebpf.MapOptions{
				// PinPath will be set by the pin manager
			},
		}
	}

	var objs Objects
	if err := spec.LoadAndAssign(&objs, opts); err != nil {
		return nil, fmt.Errorf("load and assign: %w", err)
	}

	return &objs, nil
}

func (o *Objects) Close() {
	if o.Events != nil {
		o.Events.Close()
	}
	if o.CtMap != nil {
		o.CtMap.Close()
	}
	if o.CtReverseMap != nil {
		o.CtReverseMap.Close()
	}
	if o.PktCountMap != nil {
		o.PktCountMap.Close()
	}
	if o.ByteCountMap != nil {
		o.ByteCountMap.Close()
	}
	if o.ConfigMap != nil {
		o.ConfigMap.Close()
	}
	if o.TCProg != nil {
		o.TCProg.Close()
	}
}
