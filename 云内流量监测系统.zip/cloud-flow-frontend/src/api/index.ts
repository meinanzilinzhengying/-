import { ElMessage } from 'element-plus';
import router, { clearAuthCache } from '../router';

// ============================================================
// API 基础配置
// ============================================================

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

const TOKEN_KEY = 'cf_token';

// =============================================================================
// [安全警告] Token 存储安全说明
// =============================================================================
// 当前实现使用 localStorage 存储 JWT Token，这在开发环境中可以接受，
// 但在生产环境中存在以下安全风险：
//
// 1. XSS 攻击风险：localStorage 可被 JavaScript 访问，如果应用存在 XSS 漏洞，
//    攻击者可以通过恶意脚本读取 Token。
// 2. Token 无法自动过期：localStorage 中的数据不会自动过期，需要手动清理。
// 3. 敏感信息暴露：Token 会一直保留在浏览器中，即使用户关闭了标签页。
//
// 【生产环境建议】：
// - 使用 httpOnly Cookie 存储 Token，防止 JavaScript 访问
// - 配合 SameSite=Strict/Lax 属性防止 CSRF 攻击
// - 在 HTTPS 环境下设置 Secure 属性
// - 后端应在 Set-Cookie 响应头中设置合理的 Max-Age 和 Path
//
// 如需改造，建议方案：
//   1. 后端登录接口改为 Set-Cookie 方式返回 Token
//   2. 前端移除 localStorage 存取 Token 的逻辑
//   3. Cookie 设置 httpOnly=true; Secure=true; SameSite=Lax; Path=/
// =============================================================================

// Token 编解码工具函数（生产环境应使用 httpOnly cookie 替代 localStorage）
function encodeToken(token: string): string { return btoa(unescape(encodeURIComponent(token))); }
function decodeToken(encoded: string): string { return decodeURIComponent(escape(atob(encoded))); }

// 401 并发请求去重标志位
let isRedirecting = false;

// 创建 AbortController 工具函数（供组件在卸载时取消请求）
export const createAbortController = (): AbortController => new AbortController();

// 重置 isRedirecting 标志位（登录成功后调用）
export const resetRedirect = () => {
  isRedirecting = false;
};

export const getToken = (): string | null => {
  const encoded = localStorage.getItem(TOKEN_KEY);
  if (!encoded) return null;
  try {
    return decodeToken(encoded);
  } catch {
    return null;
  }
};

export const setToken = (token: string, rememberMe: boolean = false): void => {
  localStorage.setItem(TOKEN_KEY, encodeToken(token));
  // 记住我：将记住状态存储到 localStorage，供后续判断 token 过期策略使用
  if (rememberMe) {
    localStorage.setItem('cf_remember_me', 'true');
  } else {
    localStorage.removeItem('cf_remember_me');
  }
};

export const removeToken = (): void => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem('cf_remember_me');
};

// ============================================================
// 通用响应包装类型
// ============================================================

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

// ============================================================
// 通用请求函数
// ============================================================

interface ApiRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: Record<string, unknown>;
  signal?: AbortSignal;
}

export async function apiRequest<T>(
  endpoint: string,
  options: ApiRequestOptions = {},
  retryCount: number | null = null,
  retryDelay: number = 1000
): Promise<ApiResponse<T>> {
  const { method = 'GET', headers = {}, body, signal } = options;

  if (retryCount === null) {
    if (method === 'GET') {
      retryCount = 3;
    } else {
      retryCount = 0;
    }
  }

  const token = getToken();

  const config: RequestInit = {
    method,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...headers,
    },
    ...(signal ? { signal } : {}),
  };

  if (body && method !== 'GET') {
    config.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);

    if (!response.ok) {
      switch (response.status) {
        case 401:
          if (isRedirecting) return Promise.reject(new Error('Unauthorized'));
          isRedirecting = true;
          ElMessage.error('登录已过期，请重新登录');
          removeToken();
          clearAuthCache();
          router.push('/login');
          break;
        case 403:
          ElMessage.error('没有权限访问此资源');
          break;
        case 404:
          ElMessage.error('请求的资源不存在');
          break;
        case 500:
          ElMessage.error('服务器内部错误，请稍后重试');
          break;
        default:
          ElMessage.error(`请求失败 (${response.status})`);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const jsonData = await response.json();
    // 如果后端返回的已经是 ApiResponse 格式（包含 success 字段），直接返回
    if (jsonData && typeof jsonData === 'object' && 'success' in jsonData) {
      return jsonData as ApiResponse<T>;
    }
    // 否则包装为统一的 ApiResponse 格式
    return { success: true, data: jsonData as T };
  } catch (e) {
    if (retryCount > 0 && (e instanceof TypeError || (e as Error).message?.includes('Network'))) {
      await new Promise(resolve => setTimeout(resolve, retryDelay));
      return apiRequest<T>(endpoint, options, retryCount - 1, retryDelay * 2);
    }

    throw e;
  }
}

// ============================================================
// 统一导出兼容旧 api 对象（保持向后兼容）
// ============================================================

export { API_BASE_URL };

// 导出各模块 API
export { authApi, userApi } from './auth';
export { metricsApi } from './metrics';
export { alertsApi } from './alerts';
export { assetsApi } from './assets';
export { networkApi } from './network';
export { businessApi, serviceApi } from './business';
export { systemApi, reportApi } from './system';

// 兼容旧的 api 对象导出，确保现有引用无需修改
import { authApi, userApi } from './auth';
import { metricsApi } from './metrics';
import { alertsApi } from './alerts';
import { assetsApi } from './assets';
import { networkApi } from './network';
import { businessApi, serviceApi } from './business';
import { systemApi, reportApi } from './system';

export const api = {
  // 仪表盘概览
  getOverview: metricsApi.getOverview,
  getNodes: metricsApi.getNodes,
  getTraffic: metricsApi.getTraffic,
  getProtocol: metricsApi.getProtocol,
  getCpu: metricsApi.getCpu,
  getMemory: metricsApi.getMemory,
  getMetrics: metricsApi.getMetrics,
  getAlerts: alertsApi.getAlerts,
  getRules: alertsApi.getRules,

  // 链路追踪 & 拓扑
  getTracing: networkApi.getTracing,
  getTopology: networkApi.getTopology,

  // 认证
  login: authApi.login,
  logout: authApi.logout,
  isAuthenticated: authApi.isAuthenticated,

  // 资产管理
  asset: assetsApi,

  // 系统管理
  system: systemApi,

  // 网络分析
  network: networkApi,

  // 指标数据
  metrics: {
    getMetricList: metricsApi.getMetricList,
    getMetricDetail: metricsApi.getMetricDetail,
    getMetricTrend: metricsApi.getMetricTrend,
    getMetricAggregation: metricsApi.getMetricAggregation,
  },

  // 报告
  report: reportApi,

  // 告警
  alert: alertsApi,

  // 用户管理
  user: userApi,

  // 业务观测
  business: businessApi,

  // 服务管理
  service: serviceApi,
};
