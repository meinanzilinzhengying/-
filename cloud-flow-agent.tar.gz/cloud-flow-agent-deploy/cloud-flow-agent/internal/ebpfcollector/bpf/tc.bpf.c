// SPDX-License-Identifier: GPL-2.0
// Copyright (c) 2024 Cloud Flow Agent Contributors

#include "common.h"
#include "maps.h"
#include "conntrack.h"

// TC program for network traffic collection with Connection Tracking
SEC("tc")
int tc_prog(struct __sk_buff *skb) {
    void *data = (void *)(long)skb->data;
    void *data_end = (void *)(long)skb->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip;
    struct tcphdr *tcp = NULL;
    struct udphdr *udp = NULL;
    
    // Ethernet header check
    if (data + sizeof(*eth) > data_end)
        return TC_ACT_OK;
    
    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return TC_ACT_OK;
    
    // IP header check
    ip = data + sizeof(*eth);
    if ((void *)ip + sizeof(*ip) > data_end)
        return TC_ACT_OK;
    
    // Skip fragments (only handle first fragment)
    if (ip->frag_off & bpf_htons(0x1FFF))
        return TC_ACT_OK;
    
    __u32 src_ip = ip->saddr;
    __u32 dst_ip = ip->daddr;
    __u8 protocol = ip->protocol;
    __u32 data_len = bpf_ntohs(ip->tot_len) - (ip->ihl * 4);
    __u16 src_port = 0, dst_port = 0;
    __u8 tcp_flags = 0;
    
    // Parse transport layer
    if (protocol == PROTO_TCP) {
        tcp = (void *)ip + (ip->ihl * 4);
        if ((void *)tcp + sizeof(*tcp) > data_end)
            return TC_ACT_OK;
        src_port = tcp->source;
        dst_port = tcp->dest;
        tcp_flags = tcp->fin | (tcp->syn << 1) | (tcp->rst << 2) |
                    (tcp->psh << 3) | (tcp->ack << 4) | (tcp->urg << 5);
    } else if (protocol == PROTO_UDP) {
        udp = (void *)ip + (ip->ihl * 4);
        if ((void *)udp + sizeof(*udp) > data_end)
            return TC_ACT_OK;
        src_port = udp->source;
        dst_port = udp->dest;
    } else if (protocol == PROTO_ICMP) {
        src_port = dst_port = 0;
    } else {
        return TC_ACT_OK;
    }
    
    // Build CT key
    ct_key_t key = {
        .saddr = src_ip,
        .daddr = dst_ip,
        .sport = src_port,
        .dport = dst_port,
        .protocol = protocol,
        .pad = {0, 0, 0},
    };
    
    // Connection tracking lookup/create
    int is_new = 0;
    ct_entry_t *entry = ct_lookup(skb, &key, tcp_flags, &is_new);
    if (!entry) {
        return TC_ACT_OK;  // Map full or error
    }
    
    // Update statistics
    int is_reply = (entry->state == CT_REPLY);
    ct_update_stats(entry, data_len, is_reply);
    
    // Calculate flow hash for PERCPU maps
    __u32 flow_hash = hash_flow(src_ip, dst_ip, src_port, dst_port, protocol);
    
    // Update PERCPU counters (no lock contention)
    __u64 *pkt_count = bpf_map_lookup_elem(&pkt_count_map, &flow_hash);
    if (pkt_count) {
        (*pkt_count)++;
    } else {
        __u64 init_count = 1;
        bpf_map_update_elem(&pkt_count_map, &flow_hash, &init_count, BPF_ANY);
    }
    
    __u64 *byte_count = bpf_map_lookup_elem(&byte_count_map, &flow_hash);
    if (byte_count) {
        (*byte_count) += data_len;
    } else {
        bpf_map_update_elem(&byte_count_map, &flow_hash, &data_len, BPF_ANY);
    }
    
    // Send event to Ring Buffer
    flow_event_t *event = bpf_ringbuf_reserve(&events, sizeof(*event), 0);
    if (event) {
        event->src_ip = src_ip;
        event->dst_ip = dst_ip;
        event->src_port = src_port;
        event->dst_port = dst_port;
        event->protocol = protocol;
        event->event_type = is_new ? EVENT_TYPE_FLOW_NEW : 
                           (entry->state == CT_ESTABLISHED ? EVENT_TYPE_FLOW_ESTABLISHED : EVENT_TYPE_FLOW_UPDATE);
        event->ct_state = entry->state;
        event->tcp_state = entry->tcp_state;
        event->bytes = data_len;
        event->packets = 1;
        event->timestamp = bpf_ktime_get_ns();
        event->cpu_id = bpf_get_smp_processor_id();
        event->lifetime = entry->lifetime;
        bpf_ringbuf_submit(event, 0);
    }
    
    return TC_ACT_OK;
}

char _license[] SEC("license") = "GPL";
