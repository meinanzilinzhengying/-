// Package storage 提供基于 TiDB 的数据持久化
package storage

import (
	"time"

	edge "cloud-flow/proto"
)

// StorageEngine 统一存储接口
type StorageEngine interface {
	SaveMetrics(probeID string, metrics interface{}) error
	SaveTraces(probeID string, spans interface{}) error
	SaveProfiling(probeID string, profiles interface{}) error
	SaveProbeInfo(edgeNodeID string, data interface{}) error
	QueryMetrics(day string, probeID string, limit int) ([]map[string]interface{}, error)
	QueryMetricsByAlert(day string, metricName string, operator string, threshold float64, limit int) ([]map[string]interface{}, error)
	QueryTraces(day string, probeID string, limit int) ([]map[string]interface{}, error)
	GetRecentMetrics(metricType string, limit int, timeWindow time.Duration) ([]*edge.MetricData, error)
	GetOverview() (map[string]interface{}, error)
	GetNodes() ([]map[string]interface{}, error)
	// 用户管理
	CreateUser(username, password, role string) error
	GetUser(username string) (map[string]interface{}, error)
	UpdateUser(username, password, role string) error
	UpdateUserRole(username, role string) error
	DeleteUser(username string) error
	ListUsers() ([]map[string]interface{}, error)
	VerifyUser(username, password string) (bool, string, error)
	StartCleanup()
	Stop()
	DB() interface{}
}
