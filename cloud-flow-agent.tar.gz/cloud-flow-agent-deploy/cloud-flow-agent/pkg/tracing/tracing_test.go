package tracing

import (
	"context"
	"testing"

	"go.opentelemetry.io/otel/attribute"
)

func TestNoOpTracer(t *testing.T) {
	tracer := NoOpTracer()
	if tracer == nil {
		t.Fatal("NoOpTracer returned nil")
	}

	ctx, span := tracer.StartSpan(context.Background(), "test")
	defer span.End()

	// Should not panic
	tracer.RecordError(ctx, nil)
	tracer.SetAttributes(ctx, attribute.String("test", "value"))
}

func TestAttributes(t *testing.T) {
	// Test that attribute keys are defined correctly
	tests := []struct {
		name string
		key  attribute.Key
		want string
	}{
		{"ProbeID", AttrProbeID, "probe.id"},
		{"SrcIP", AttrSrcIP, "net.src.ip"},
		{"DstIP", AttrDstIP, "net.dst.ip"},
		{"Protocol", AttrProtocol, "net.protocol"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if string(tt.key) != tt.want {
				t.Errorf("Attr%s = %q, want %q", tt.name, string(tt.key), tt.want)
			}
		})
	}
}
