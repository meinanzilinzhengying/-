package http

import (
	"context"
	"encoding/json"
	"net/http"
	"runtime"
	"time"

	"go.uber.org/zap"
)

// Version 版本号，由 main 包在启动时设置
var Version string

// GRPCClientProvider 提供获取 gRPC 客户端连接状态的能力
type GRPCClientProvider interface {
	GetConnectionState() string
}

// CollectorHealthChecker 提供采集器健康检查能力
type CollectorHealthChecker interface {
	IsHealthy() bool
}

// EBPFHealthChecker 提供 eBPF 采集器健康检查能力
type EBPFHealthChecker interface {
	IsAvailable() bool
}

// HealthStatus represents health check status
type HealthStatus string

const (
	StatusHealthy   HealthStatus = "healthy"
	StatusUnhealthy HealthStatus = "unhealthy"
	StatusDegraded  HealthStatus = "degraded"
)

// ComponentHealth represents health of a component
type ComponentHealth struct {
	Status    HealthStatus `json:"status"`
	Message   string       `json:"message,omitempty"`
	LatencyMs int64        `json:"latency_ms,omitempty"`
}

// HealthResponse is the detailed health response
type HealthResponse struct {
	Status     HealthStatus               `json:"status"`
	Timestamp  time.Time                  `json:"timestamp"`
	Version    string                     `json:"version"`
	Uptime     time.Duration              `json:"uptime"`
	Components map[string]ComponentHealth `json:"components"`
	System     SystemInfo                 `json:"system"`
}

// SystemInfo contains system metrics
type SystemInfo struct {
	GoVersion    string `json:"go_version"`
	NumGoroutine int    `json:"num_goroutine"`
	NumCPU       int    `json:"num_cpu"`
	MemAllocMB   uint64 `json:"mem_alloc_mb"`
	MemSysMB     uint64 `json:"mem_sys_mb"`
}

// HealthChecker performs health checks
type HealthChecker struct {
	startTime time.Time
	version   string
	checks    map[string]func() ComponentHealth
	logger    *zap.Logger
}

// NewHealthChecker creates a health checker
func NewHealthChecker(version string, logger *zap.Logger) *HealthChecker {
	return &HealthChecker{
		startTime: time.Now(),
		version:   version,
		checks:    make(map[string]func() ComponentHealth),
		logger:    logger,
	}
}

// RegisterCheck registers a health check function
func (h *HealthChecker) RegisterCheck(name string, check func() ComponentHealth) {
	h.checks[name] = check
}

// Check performs all health checks
func (h *HealthChecker) Check(ctx context.Context) *HealthResponse {
	response := &HealthResponse{
		Status:     StatusHealthy,
		Timestamp:  time.Now(),
		Version:    h.version,
		Uptime:     time.Since(h.startTime),
		Components: make(map[string]ComponentHealth),
	}

	// Run all checks
	for name, check := range h.checks {
		health := check()
		response.Components[name] = health

		if health.Status == StatusUnhealthy {
			response.Status = StatusUnhealthy
		} else if health.Status == StatusDegraded && response.Status != StatusUnhealthy {
			response.Status = StatusDegraded
		}
	}

	// Add system info
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	response.System = SystemInfo{
		GoVersion:    runtime.Version(),
		NumGoroutine: runtime.NumGoroutine(),
		NumCPU:       runtime.NumCPU(),
		MemAllocMB:   m.Alloc / 1024 / 1024,
		MemSysMB:     m.Sys / 1024 / 1024,
	}

	return response
}

// Handler returns HTTP handler for health endpoint
func (h *HealthChecker) Handler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		response := h.Check(ctx)

		status := http.StatusOK
		if response.Status == StatusUnhealthy {
			status = http.StatusServiceUnavailable
		} else if response.Status == StatusDegraded {
			status = http.StatusOK // Still serve traffic
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(status)
		json.NewEncoder(w).Encode(response)
	}
}

// LivezHandler returns simple liveness probe
func (h *HealthChecker) LivezHandler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ok"))
	}
}

// ReadyzHandler returns readiness probe
func (h *HealthChecker) ReadyzHandler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		response := h.Check(ctx)

		if response.Status == StatusUnhealthy {
			w.WriteHeader(http.StatusServiceUnavailable)
			w.Write([]byte("not ready"))
			return
		}

		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ready"))
	}
}

// NewHealthHandler creates a health handler with the given dependencies
func NewHealthHandler(grpcProvider GRPCClientProvider, collectorHealth CollectorHealthChecker, ebpfHealth EBPFHealthChecker, log *zap.Logger) *HealthChecker {
	hc := NewHealthChecker(Version, log)

	// Register gRPC connection check
	if grpcProvider != nil {
		hc.RegisterCheck("grpc", func() ComponentHealth {
			state := grpcProvider.GetConnectionState()
			if state == "" || state == "TRANSIENT_FAILURE" || state == "SHUTDOWN" {
				return ComponentHealth{Status: StatusUnhealthy, Message: "gRPC not connected, state: " + state}
			}
			return ComponentHealth{Status: StatusHealthy, Message: "state: " + state}
		})
	}

	// Register collector check
	if collectorHealth != nil {
		hc.RegisterCheck("collector", func() ComponentHealth {
			if collectorHealth.IsHealthy() {
				return ComponentHealth{Status: StatusHealthy}
			}
			return ComponentHealth{Status: StatusDegraded, Message: "collector unhealthy"}
		})
	}

	// Register eBPF check
	if ebpfHealth != nil {
		hc.RegisterCheck("ebpf", func() ComponentHealth {
			if ebpfHealth.IsAvailable() {
				return ComponentHealth{Status: StatusHealthy}
			}
			return ComponentHealth{Status: StatusDegraded, Message: "eBPF not available"}
		})
	}

	return hc
}

// StartHealthServer starts the health check HTTP server
func StartHealthServer(addr string, handler *HealthChecker) *http.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", handler.Handler())
	mux.HandleFunc("/livez", handler.LivezHandler())
	mux.HandleFunc("/readyz", handler.ReadyzHandler())

	server := &http.Server{
		Addr:    addr,
		Handler: mux,
	}

	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			// 使用全局 zap logger 记录错误（因为此处没有注入 logger）
			zap.L().Error("health server error", zap.Error(err))
		}
	}()

	return server
}
