package retry

import (
	"context"
	"errors"
	"math/rand"
	"time"
)

// Config holds retry configuration
type Config struct {
	MaxAttempts     int           // Maximum retry attempts
	InitialDelay    time.Duration // Initial delay
	MaxDelay        time.Duration // Maximum delay
	Multiplier      float64       // Delay multiplier
	Jitter          float64       // Random jitter factor (0-1)
	RetryableErrors []error       // Errors that should trigger retry
}

// DefaultConfig returns default configuration
func DefaultConfig() Config {
	return Config{
		MaxAttempts:  3,
		InitialDelay: 100 * time.Millisecond,
		MaxDelay:     5 * time.Second,
		Multiplier:   2.0,
		Jitter:       0.1,
	}
}

// Retryable checks if error is retryable
type Retryable func(error) bool

// Retry executes function with retry logic
func Retry(ctx context.Context, config Config, isRetryable Retryable, fn func() error) error {
	var lastErr error
	delay := config.InitialDelay

	for attempt := 1; attempt <= config.MaxAttempts; attempt++ {
		err := fn()
		if err == nil {
			return nil
		}

		lastErr = err

		// Check if we should retry
		if attempt == config.MaxAttempts {
			break
		}

		if isRetryable != nil && !isRetryable(err) {
			return err
		}

		// Calculate delay with jitter
		actualDelay := delay
		if config.Jitter > 0 {
			jitter := time.Duration(float64(delay) * config.Jitter * rand.Float64())
			actualDelay = delay + jitter
		}

		// Wait or context cancellation
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(actualDelay):
		}

		// Increase delay
		delay = time.Duration(float64(delay) * config.Multiplier)
		if delay > config.MaxDelay {
			delay = config.MaxDelay
		}
	}

	return lastErr
}

// IsRetryableError checks if error is in the retryable list
func IsRetryableError(err error, retryableErrors []error) bool {
	for _, e := range retryableErrors {
		if errors.Is(err, e) {
			return true
		}
		// Check error string for network errors
		if err.Error() == e.Error() {
			return true
		}
	}
	return false
}

// DefaultRetryable returns default retryable error checker
func DefaultRetryable(err error) bool {
	// Retry on context deadline exceeded, connection errors, etc.
	if errors.Is(err, context.DeadlineExceeded) {
		return true
	}
	if errors.Is(err, context.Canceled) {
		return false // Don't retry on explicit cancellation
	}

	// Check for transient network errors
	errStr := err.Error()
	retryablePatterns := []string{
		"connection refused",
		"connection reset",
		"timeout",
		"temporary failure",
		"unavailable",
	}

	for _, pattern := range retryablePatterns {
		if contains(errStr, pattern) {
			return true
		}
	}

	return false
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (s == substr || len(s) > 0 && containsHelper(s, substr))
}

func containsHelper(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}
