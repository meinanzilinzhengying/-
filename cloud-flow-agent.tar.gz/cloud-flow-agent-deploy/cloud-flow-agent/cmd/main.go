package main

import (
	"context"
	"fmt"
	"net"
	"net/http"
	_ "net/http/pprof"
	"os"
	"sync"
	"time"

	"cloud-flow-agent/internal/collector"
	"cloud-flow-agent/internal/config"
	"cloud-flow-agent/internal/ebpfcollector"
	"cloud-flow-agent/internal/grpcclient"
	healthhttp "cloud-flow-agent/internal/http"
	"cloud-flow-agent/pkg/audit"
	"cloud-flow-agent/pkg/logger"
	"cloud-flow-agent/pkg/metrics"
	"cloud-flow-agent/pkg/pool"
	"cloud-flow-agent/pkg/retry"
	"cloud-flow-agent/pkg/shutdown"
	"cloud-flow-agent/pkg/tracing"
	"cloud-flow-agent/pkg/validator"
	edge "cloud-flow/proto"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
	"go.uber.org/zap"
)

// safeClient 线程安全的客户端包装器
type safeClient struct {
	mu     sync.RWMutex
	client *grpcclient.Client
}

// Get 安全地获取客户端
func (sc *safeClient) Get() *grpcclient.Client {
	sc.mu.RLock()
	defer sc.mu.RUnlock()
	return sc.client
}

// Set 安全地设置客户端
func (sc *safeClient) Set(c *grpcclient.Client) {
	sc.mu.Lock()
	defer sc.mu.Unlock()
	sc.client = c
}

// GetConnectionState 实现 healthhttp.GRPCClientProvider 接口
func (sc *safeClient) GetConnectionState() string {
	c := sc.Get()
	if c == nil {
		return "SHUTDOWN"
	}
	return c.GetState().String()
}

// Version 版本号，可在编译时通过 -ldflags "-X main.Version=x.y.z" 注入
var Version = "dev"

func main() {
	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "加载配置失败: %v\n", err)
		os.Exit(1)
	}

	log := logger.New(logger.Config{Level: cfg.Log.Level, Format: cfg.Log.Format})
	defer log.Sync()

	// 创建 zap.Logger 用于需要结构化日志的组件
	zapLog, _ := zap.NewProduction()

	// 使用 validator 验证关键配置
	if err := validator.ValidateID(cfg.ProbeID, 128); err != nil {
		log.Errorf("无效的探针 ID 格式: %v", err)
		os.Exit(1)
	}
	if cfg.EdgeAddr == "" {
		log.Error("Edge 地址不能为空")
		os.Exit(1)
	}
	if cfg.ConnectTimeout <= 0 {
		log.Errorf("ConnectTimeout 必须为正数，当前值: %d", cfg.ConnectTimeout)
		os.Exit(1)
	}

	// 初始化审计日志
	auditLogger, err := audit.NewLogger("")
	if err != nil {
		log.Warnf("初始化审计日志失败: %v", err)
	}

	// 启动 pprof 性能分析服务器（生产环境调试用）
	go func() {
		log.Infof("Starting pprof server on :6060")
		if err := http.ListenAndServe(":6060", nil); err != nil {
			log.Warnf("pprof server error: %v", err)
		}
	}()

	// 初始化指标收集器
	metricCollector := metrics.New()

	// 启动 Prometheus 指标服务器
	metricsAddr := fmt.Sprintf(":%s", cfg.MetricsPort)
	metricsServer, metricsErrCh := metricCollector.StartServer(metricsAddr)
	go func() {
		if err := <-metricsErrCh; err != nil {
			log.Warnf("启动 Prometheus 指标服务器失败: %v", err)
		}
	}()

	log.Infof("探针启动中... 配置: %s", cfg.Summary())

	// 初始化分布式追踪
	var tracer *tracing.Tracer
	otlpEndpoint := os.Getenv("OTLP_ENDPOINT")
	if otlpEndpoint != "" {
		tracerCtx, tracerCancel := context.WithTimeout(context.Background(), 10*time.Second)
		tracer, err = tracing.NewTracer(tracerCtx, tracing.Config{
			ServiceName:    "cloud-flow-agent",
			ServiceVersion: Version,
			Environment:    os.Getenv("CLOUD_FLOW_ENV"),
			OTLPEndpoint:   otlpEndpoint,
			SampleRate:     0.1,
		})
		tracerCancel()
		if err != nil {
			log.Warnf("初始化追踪失败: %v，使用 NoOp 追踪器", err)
			tracer = tracing.NoOpTracer()
		} else {
			log.Infof("分布式追踪已启用，OTLP endpoint: %s", otlpEndpoint)
		}
	} else {
		tracer = tracing.NoOpTracer()
		log.Info("未配置 OTLP_ENDPOINT，使用 NoOp 追踪器")
	}

	// 初始化优雅关闭处理器
	shutdownHandler := shutdown.NewHandler(30*time.Second, zapLog)
	if metricsServer != nil {
		shutdownHandler.Register(func(ctx context.Context) error {
			return metricsServer.Shutdown(ctx)
		})
	}
	shutdownHandler.Register(func(ctx context.Context) error {
		log.Sync()
		return nil
	})
	if tracer != nil {
		shutdownHandler.Register(func(ctx context.Context) error {
			return tracer.Shutdown(ctx)
		})
	}
	if auditLogger != nil {
		shutdownHandler.Register(func(ctx context.Context) error {
			return auditLogger.Close()
		})
	}

	// 连接边缘节点（使用 pkg/retry 替代手动重试）
	connectTimeout := time.Duration(cfg.ConnectTimeout) * time.Second
	var client *grpcclient.Client

	retryCfg := retry.DefaultConfig()
	retryCfg.MaxAttempts = 5
	retryCfg.InitialDelay = 2 * time.Second
	retryCfg.MaxDelay = 30 * time.Second

	retryErr := retry.Retry(context.Background(), retryCfg, retry.DefaultRetryable, func() error {
		var err error
		client, err = grpcclient.NewClient(cfg.EdgeAddr, cfg.APIKey, grpcclient.TLSConfig{
			Enabled:    cfg.TLS.Enabled,
			ServerName: cfg.TLS.ServerName,
			CACert:     cfg.TLS.CACert,
			ClientCert: cfg.TLS.ClientCert,
			ClientKey:  cfg.TLS.ClientKey,
		}, connectTimeout, log)
		return err
	})
	if retryErr != nil {
		log.Errorf("连接边缘节点失败: %v", retryErr)
		return
	}

	// 创建线程安全的客户端包装器
	safeClient := &safeClient{client: client}

	// 注册探针（带追踪和审计）
	hostname, _ := os.Hostname()
	hostIP := getLocalIP()
	regCtx, regCancel := context.WithTimeout(context.Background(), 30*time.Second)
	regCtx, regSpan := tracer.StartSpan(regCtx, "probe.register",
		trace.WithAttributes(
			tracing.AttrProbeID.String(cfg.ProbeID),
			attribute.String("host_ip", hostIP),
			attribute.String("hostname", hostname),
		),
	)
	defer regCancel()
	resp, err := safeClient.Get().Register(regCtx, cfg.ProbeID, hostIP, hostname, Version)
	if err != nil {
		log.Errorf("注册探针失败: %v", err)
		tracer.RecordError(regCtx, err)
		regSpan.End()
		safeClient.Get().Close()
		os.Exit(1)
	}
	regSpan.End()

	// 审计日志：记录探针注册事件
	if auditLogger != nil {
		auditLogger.LogAuth(regCtx, cfg.ProbeID, "register", hostIP, true, nil)
	}
	log.Infof("注册成功: %s, 心跳间隔=%ds", resp.GetMessage(), resp.GetHeartbeatInterval())

	// 初始化传统采集器
	c := collector.New(collector.CollectConfig{
		CPU:     cfg.Collect.CPU,
		Memory:  cfg.Collect.Memory,
		Network: cfg.Collect.Network,
		Disk:    cfg.Collect.Disk,
	})

	// 初始化 EBPF 采集器（如果可用）
	ebpfCollector, err := ebpfcollector.NewWithFallback()
	if err != nil {
		log.Warnf("EBPF 采集器不可用: %v，将只使用传统采集器", err)
	} else {
		log.Info("EBPF 采集器初始化成功，开始采集网络流量")
		ebpfCollector.Start()
		defer ebpfCollector.Stop()
	}

	stopCh := make(chan struct{})
	var wg sync.WaitGroup
	var stopOnce sync.Once

	// 心跳协程
	heartbeatInterval := time.Duration(resp.GetHeartbeatInterval()) * time.Second
	wg.Add(1)
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(heartbeatInterval)
		defer ticker.Stop()
		failureCount := 0
		const maxFailures = 3 // 连续失败3次触发重连
		const reconnectDelay = 5 * time.Second

		for {
			select {
			case <-ticker.C:
				// 创建心跳追踪 span
				hbCtx, hbSpan := tracer.StartSpan(context.Background(), "probe.heartbeat",
					trace.WithAttributes(
						tracing.AttrProbeID.String(cfg.ProbeID),
					),
				)
				heartbeatCtx, heartbeatCancel := context.WithTimeout(hbCtx, 5*time.Second)
				if err := safeClient.Get().Heartbeat(heartbeatCtx, cfg.ProbeID); err != nil {
					failureCount++
					log.Warnf("心跳失败 (第 %d/%d 次): %v", failureCount, maxFailures, err)
					metricCollector.HeartbeatSent(err)
					tracer.RecordError(hbCtx, err)

					// 审计日志：心跳失败
					if auditLogger != nil {
						auditLogger.LogAuth(hbCtx, cfg.ProbeID, "heartbeat", getLocalIP(), false, err)
					}

					// 连续失败达到阈值，触发重连
					if failureCount >= maxFailures {
						log.Warnf("连续心跳失败 %d 次，开始重连 Edge 节点...", maxFailures)

						// 关闭当前客户端
						safeClient.Get().Close()

						// 使用 pkg/retry 重新连接 Edge 节点
						reconnectCfg := retry.DefaultConfig()
						reconnectCfg.MaxAttempts = 5
						reconnectCfg.InitialDelay = 2 * time.Second
						reconnectCfg.MaxDelay = 30 * time.Second

						var newClient *grpcclient.Client
						reconnectErr := retry.Retry(context.Background(), reconnectCfg, retry.DefaultRetryable, func() error {
							var err error
							newClient, err = grpcclient.NewClient(cfg.EdgeAddr, cfg.APIKey, grpcclient.TLSConfig{
								Enabled:    cfg.TLS.Enabled,
								ServerName: cfg.TLS.ServerName,
								CACert:     cfg.TLS.CACert,
								ClientCert: cfg.TLS.ClientCert,
								ClientKey:  cfg.TLS.ClientKey,
							}, connectTimeout, log)
							return err
						})
						if reconnectErr != nil {
							log.Errorf("重连 Edge 节点失败: %v", reconnectErr)
							failureCount = 0
							continue
						}

						// 重新注册
						hostname, _ = os.Hostname()
						agentIP := getLocalIP()
						regCtx, regCancel := context.WithTimeout(context.Background(), 10*time.Second)
						newResp, err := newClient.Register(regCtx, cfg.ProbeID, agentIP, hostname, Version)
						regCancel()
						if err != nil {
							log.Errorf("重新注册失败: %v", err)
							failureCount = 0
							continue
						}
						// 检查注册是否成功
						if !newResp.GetSuccess() {
							log.Errorf("重新注册被拒绝: %s，请检查 API Key 配置", newResp.GetMessage())
							failureCount = 0
							// API Key 不匹配时停止重试，避免无限循环
							log.Errorf("API Key 配置错误，探针将停止运行，请修改配置后重启")
							stopOnce.Do(func() {
								close(stopCh)
							})
							return
						}

						// 重连成功，更新客户端和心跳间隔
						safeClient.Set(newClient)
						heartbeatInterval = time.Duration(newResp.GetHeartbeatInterval()) * time.Second
						ticker.Reset(heartbeatInterval)
						failureCount = 0
						log.Infof("重连成功: %s, 心跳间隔=%ds", newResp.GetMessage(), newResp.GetHeartbeatInterval())
					}
				} else {
					// 心跳成功，重置失败计数
					failureCount = 0
					metricCollector.HeartbeatSent(nil)

					// 审计日志：心跳成功
					if auditLogger != nil {
						auditLogger.LogAuth(hbCtx, cfg.ProbeID, "heartbeat", getLocalIP(), true, nil)
					}
				}
				hbSpan.End()
				heartbeatCancel() // 直接调用而非 defer，因为 defer 在 for 循环内会延迟到函数退出才执行
			case <-stopCh:
				return
			}
		}
	}()

	// 指标采集 + 发送协程
	wg.Add(1)
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(time.Duration(cfg.CollectInterval) * time.Second)
		defer ticker.Stop()
		flushTicker := time.NewTicker(30 * time.Second) // 每30秒flush一次日志
		defer flushTicker.Stop()
		var buf []*edge.MetricData

		for {
			select {
			case <-ticker.C:
				// 创建采集追踪 span
				collectCtx, collectSpan := tracer.StartSpan(context.Background(), "collect.cycle",
					trace.WithAttributes(
						tracing.AttrProbeID.String(cfg.ProbeID),
					),
				)

				// 采集传统指标
				start := metricCollector.CollectStarted()
				metricsData, collectErr := c.Collect()
				metricCollector.CollectFinished(start, collectErr)
				if collectErr != nil {
					log.Warnf("采集传统指标失败: %v", collectErr)
					tracer.RecordError(collectCtx, collectErr)
				} else {
					buf = append(buf, metricsData...)
				}

				// 采集 EBPF 网络流量数据
				if ebpfCollector != nil {
					ebpfMetrics := ebpfCollector.Collect()
					metricCollector.EBPFCollect(nil)
					buf = append(buf, ebpfMetrics...)
				}

				if len(buf) >= cfg.BatchSize {
					batch := &edge.MetricsBatch{
						ProbeId: cfg.ProbeID,
						Metrics: buf,
					}

					// 创建发送追踪 span
					sendCtx, sendSpan := tracer.StartSpan(collectCtx, "metrics.send",
						trace.WithAttributes(
							attribute.Int("batch_size", len(buf)),
						),
					)

					// 发送指标
					sendStart := metricCollector.SendStarted()
					sendCtxTimeout, sendCancel := context.WithTimeout(sendCtx, 10*time.Second)
					err := safeClient.Get().SendMetrics(sendCtxTimeout, batch)
					sendCancel()
					if err != nil {
						log.Errorf("发送指标数据失败: %v", err)
						metricCollector.SendFinished(sendStart, 0, err)
						tracer.RecordError(sendCtx, err)
						// 保留数据下次重试（简单丢弃超出阈值的部分避免内存溢出）
						if len(buf) > cfg.BatchSize*2 {
							buf = buf[len(buf)-cfg.BatchSize:]
						}
					} else {
						log.Debugf("发送 %d 条指标数据", len(buf))
						sentLen := len(buf)
						metricCollector.SendFinished(sendStart, sentLen*100, nil)
						// 将已发送的 MetricData 归还到对象池
						for _, m := range buf {
							pool.PutMetricData(m)
						}
						buf = nil
					}
					sendSpan.End()
				}
				collectSpan.End()
			case <-flushTicker.C:
				// 每30秒flush一次日志
				log.Sync()
			case <-stopCh:
				// 发送剩余数据
				if len(buf) > 0 {
					batch := &edge.MetricsBatch{
						ProbeId: cfg.ProbeID,
						Metrics: buf,
					}
					sendStart := metricCollector.SendStarted()
					sendCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
					if err := safeClient.Get().SendMetrics(sendCtx, batch); err != nil {
						log.Warnf("发送剩余数据失败: %v", err)
						metricCollector.SendFinished(sendStart, 0, err)
					} else {
						metricCollector.SendFinished(sendStart, len(buf)*100, nil) // 估算字节数
					}
					cancel()
				}
				return
			}
		}
	}()

	// 启动 HTTP 健康检查服务器
	healthhttp.Version = Version
	healthHandler := healthhttp.NewHealthHandler(safeClient, c, ebpfCollector, zapLog)
	healthAddr := fmt.Sprintf(":%s", cfg.HealthPort)
	healthServer := healthhttp.StartHealthServer(healthAddr, healthHandler)
	log.Infof("健康检查 HTTP 服务监听: %s/health", healthAddr)

	// 注册健康检查服务器和 gRPC 客户端到关闭处理器
	if healthServer != nil {
		shutdownHandler.Register(func(ctx context.Context) error {
			return healthServer.Shutdown(ctx)
		})
	}
	shutdownHandler.Register(func(ctx context.Context) error {
		safeClient.Get().Close()
		return nil
	})

	log.Info("探针已启动")

	// 当收到关闭信号时，停止所有 goroutine
	go func() {
		<-shutdownHandler.Done()
		stopOnce.Do(func() {
			close(stopCh)
		})
	}()

	// 使用 shutdown handler 等待信号并优雅退出
	shutdownHandler.Wait()
}

func getLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		hostname, _ := os.Hostname()
		if hostname != "" {
			return hostname
		}
		return "0.0.0.0" // 最终兜底值
	}

	// 优先返回 IPv4 地址
	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String()
			}
		}
	}

	// 如果没有 IPv4 地址，返回 IPv6 地址
	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			return ipnet.IP.String()
		}
	}

	hostname, _ := os.Hostname()
	if hostname != "" {
		return hostname
	}
	return "0.0.0.0" // 最终兜底值
}
