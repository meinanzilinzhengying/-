package ebpfcollector

import (
	"testing"
)

func TestDetectKernelVersion(t *testing.T) {
	kf := &KernelFeatures{}
	err := detectKernelVersion(kf)
	if err != nil {
		t.Fatalf("detectKernelVersion failed: %v", err)
	}

	if kf.Major == 0 {
		t.Error("Major version should not be 0")
	}
	t.Logf("Detected kernel version: %d.%d", kf.Major, kf.Minor)
}

func TestDetectKernelFeatures(t *testing.T) {
	kf, err := DetectKernelFeatures()
	if err != nil {
		t.Fatalf("DetectKernelFeatures failed: %v", err)
	}

	t.Logf("Kernel features:\n%s", kf.String())

	// Basic sanity checks
	if !kf.HasTC {
		t.Log("Warning: TC BPF not available")
	}
}

func TestCheckRequirements(t *testing.T) {
	kf, err := DetectKernelFeatures()
	if err != nil {
		t.Fatalf("DetectKernelFeatures failed: %v", err)
	}

	err = kf.CheckRequirements()
	// This may fail on older kernels, which is expected
	if err != nil {
		t.Logf("Requirements check: %v (expected on older kernels)", err)
	}
}
