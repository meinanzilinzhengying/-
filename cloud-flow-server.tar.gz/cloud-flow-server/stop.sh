#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

COMPOSE_CMD="docker compose"
if ! docker compose version &> /dev/null 2>&1; then
    COMPOSE_CMD="docker-compose"
fi

echo "停止云内流量监测系统..."
$COMPOSE_CMD down

echo ""
echo "服务已停止。"
echo "  如需删除数据（数据库数据将丢失）: $COMPOSE_CMD down -v"
echo "  如需删除镜像: docker rmi \$(docker images --format '{{.Repository}}:{{.Tag}}' | grep cloud-flow)"
