package validator

import (
	"testing"
)

func TestValidateIP(t *testing.T) {
	tests := []struct {
		ip   string
		want error
	}{
		{"192.168.1.1", nil},
		{"10.0.0.1", nil},
		{"::1", nil},
		{"2001:db8::1", nil},
		{"invalid", ErrInvalidIP},
		{"", ErrInvalidIP},
		{"256.256.256.256", ErrInvalidIP},
	}

	for _, tt := range tests {
		err := ValidateIP(tt.ip)
		if err != tt.want {
			t.Errorf("ValidateIP(%q) = %v, want %v", tt.ip, err, tt.want)
		}
	}
}

func TestValidatePort(t *testing.T) {
	tests := []struct {
		port int32
		want error
	}{
		{0, nil},
		{80, nil},
		{443, nil},
		{65535, nil},
		{-1, ErrInvalidPort},
		{65536, ErrInvalidPort},
	}

	for _, tt := range tests {
		err := ValidatePort(tt.port)
		if err != tt.want {
			t.Errorf("ValidatePort(%d) = %v, want %v", tt.port, err, tt.want)
		}
	}
}

func TestValidateProtocol(t *testing.T) {
	tests := []struct {
		proto string
		want  error
	}{
		{"tcp", nil},
		{"TCP", nil},
		{"udp", nil},
		{"icmp", nil},
		{"http", nil},
		{"invalid", ErrInvalidProtocol},
		{"", ErrInvalidProtocol},
	}

	for _, tt := range tests {
		err := ValidateProtocol(tt.proto)
		if err != tt.want {
			t.Errorf("ValidateProtocol(%q) = %v, want %v", tt.proto, err, tt.want)
		}
	}
}

func TestSanitizeString(t *testing.T) {
	input := "hello\x00world\x1btest"
	got := SanitizeString(input, 100)
	if got != "helloworldtest" {
		t.Errorf("SanitizeString() = %q, want %q", got, "helloworldtest")
	}
}
