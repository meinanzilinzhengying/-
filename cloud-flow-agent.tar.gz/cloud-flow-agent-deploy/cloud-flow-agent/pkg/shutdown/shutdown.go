package shutdown

import (
	"context"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"go.uber.org/zap"
)

// Handler manages graceful shutdown
type Handler struct {
	mu           sync.Mutex
	shutdownFns  []func(context.Context) error
	timeout      time.Duration
	logger       *zap.Logger
	shutdownChan chan struct{}
	shutdownOnce sync.Once
}

// NewHandler creates a new shutdown handler
func NewHandler(timeout time.Duration, logger *zap.Logger) *Handler {
	return &Handler{
		shutdownFns:  make([]func(context.Context) error, 0),
		timeout:      timeout,
		logger:       logger,
		shutdownChan: make(chan struct{}),
	}
}

// Register registers a shutdown function
func (h *Handler) Register(fn func(context.Context) error) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.shutdownFns = append(h.shutdownFns, fn)
}

// Wait blocks until shutdown signal is received
func (h *Handler) Wait() {
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM, syscall.SIGHUP)

	sig := <-sigChan
	h.logger.Info("received shutdown signal", zap.String("signal", sig.String()))

	h.Shutdown()
}

// Shutdown initiates graceful shutdown
func (h *Handler) Shutdown() {
	h.shutdownOnce.Do(func() {
		close(h.shutdownChan)

		ctx, cancel := context.WithTimeout(context.Background(), h.timeout)
		defer cancel()

		h.mu.Lock()
		fns := make([]func(context.Context) error, len(h.shutdownFns))
		copy(fns, h.shutdownFns)
		h.mu.Unlock()

		// Run shutdown functions in reverse order
		for i := len(fns) - 1; i >= 0; i-- {
			if err := fns[i](ctx); err != nil {
				h.logger.Error("shutdown function failed", zap.Error(err))
			}
		}

		h.logger.Info("graceful shutdown completed")
	})
}

// Done returns a channel that's closed when shutdown is initiated
func (h *Handler) Done() <-chan struct{} {
	return h.shutdownChan
}
