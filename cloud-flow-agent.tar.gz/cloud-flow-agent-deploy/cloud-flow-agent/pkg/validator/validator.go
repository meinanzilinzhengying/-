package validator

import (
	"errors"
	"net"
	"regexp"
	"strings"
)

var (
	ErrInvalidIP       = errors.New("invalid IP address")
	ErrInvalidPort     = errors.New("invalid port number")
	ErrInvalidProtocol = errors.New("invalid protocol")
	ErrInvalidID       = errors.New("invalid ID format")
	ErrInputTooLong    = errors.New("input too long")

	idRegex = regexp.MustCompile(`^[a-zA-Z0-9_-]+$`)
)

// ValidateIP validates an IP address
func ValidateIP(ip string) error {
	if ip == "" {
		return ErrInvalidIP
	}
	if len(ip) > 45 { // IPv6 max length
		return ErrInputTooLong
	}
	if net.ParseIP(ip) == nil {
		return ErrInvalidIP
	}
	return nil
}

// ValidatePort validates a port number
func ValidatePort(port int32) error {
	if port < 0 || port > 65535 {
		return ErrInvalidPort
	}
	return nil
}

// ValidateProtocol validates a network protocol
func ValidateProtocol(protocol string) error {
	switch strings.ToLower(protocol) {
	case "tcp", "udp", "icmp", "http", "https", "dns", "ssh", "ftp", "unknown":
		return nil
	default:
		return ErrInvalidProtocol
	}
}

// ValidateID validates an ID string (alphanumeric, underscore, hyphen)
func ValidateID(id string, maxLength int) error {
	if id == "" {
		return ErrInvalidID
	}
	if len(id) > maxLength {
		return ErrInputTooLong
	}
	if !idRegex.MatchString(id) {
		return ErrInvalidID
	}
	return nil
}

// SanitizeString removes potentially dangerous characters
func SanitizeString(s string, maxLength int) string {
	if len(s) > maxLength {
		s = s[:maxLength]
	}
	// Remove control characters
	s = strings.Map(func(r rune) rune {
		if r < 32 && r != '\t' && r != '\n' && r != '\r' {
			return -1
		}
		return r
	}, s)
	return s
}

// Validator holds validation rules
type Validator struct {
	maxStringLength int
	maxArrayLength  int
}

// NewValidator creates a new validator
func NewValidator() *Validator {
	return &Validator{
		maxStringLength: 1024,
		maxArrayLength:  10000,
	}
}

// ValidateMetricData validates a MetricData struct
func (v *Validator) ValidateMetricData(m interface {
	GetSrcIp() string
	GetDstIp() string
	GetSrcPort() int32
	GetDstPort() int32
	GetProtocol() string
}) error {
	if m.GetSrcIp() != "" {
		if err := ValidateIP(m.GetSrcIp()); err != nil {
			return err
		}
	}
	if m.GetDstIp() != "" {
		if err := ValidateIP(m.GetDstIp()); err != nil {
			return err
		}
	}
	if err := ValidatePort(m.GetSrcPort()); err != nil {
		return err
	}
	if err := ValidatePort(m.GetDstPort()); err != nil {
		return err
	}
	if m.GetProtocol() != "" {
		if err := ValidateProtocol(m.GetProtocol()); err != nil {
			return err
		}
	}
	return nil
}
